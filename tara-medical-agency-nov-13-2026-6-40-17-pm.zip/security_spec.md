# Security Specification — Tara Medical Agency

## 1. Data Invariants
1. **Retailer Approval Gate**: Unauthenticated users and `pending` or `deactivated` retailer accounts cannot read `/companies`, `/products`, `/batches`, or `/enquiries`.
2. **Purchase Rate Isolation**: Internal `purchaseRate` is stored strictly in `/admin_batch_costs/{batchId}`, which only verified administrators (`isAdmin()`) can read or write.
3. **No Self-Privilege Escalation**: Newly registering retailers can only create their `/retailers/{uid}` document with `role == "retailer"`, `status == "pending"`, `priceTier == "standard"`, and `customDiscountBonus == 0`. They cannot modify `role`, `status`, `priceTier`, or `customDiscountBonus` on update.
4. **Enquiry Ownership & Master Gate**: Retailers can only read, create, update, and delete enquiries where `retailerUid == request.auth.uid`. Subcollection `/enquiries/{enquiryId}/items/{itemId}` enforces the Master Gate `get(/databases/$(database)/documents/enquiries/$(enquiryId)).data.retailerUid == request.auth.uid`.
5. **Temporal Integrity**: All `createdAt` and `updatedAt` timestamps must match `request.time`, and `createdAt` is immutable on updates.
6. **Verified Email**: Every authenticated write requires `request.auth.token.email_verified == true`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Product Read**: `GET /products/prod_1` with `auth == null` -> `PERMISSION_DENIED`.
2. **Pending Retailer Reading Catalog**: `GET /batches/batch_1` as signed-in retailer with `status == 'pending'` -> `PERMISSION_DENIED`.
3. **Deactivated Retailer Reading Catalog**: `LIST /products` as signed-in retailer with `status == 'deactivated'` -> `PERMISSION_DENIED`.
4. **Retailer Reading Purchase Rate**: `GET /admin_batch_costs/batch_1` as active approved retailer -> `PERMISSION_DENIED`.
5. **Self-Approval on Signup**: `CREATE /retailers/{uid}` with `status: 'active'` or `role: 'admin'` -> `PERMISSION_DENIED`.
6. **Privilege Escalation on Profile Update**: `UPDATE /retailers/{uid}` changing `status` from `'pending'` to `'active'` or `customDiscountBonus` from `0` to `10` -> `PERMISSION_DENIED`.
7. **Shadow Field Injection**: `CREATE /retailers/{uid}` with extra field `isAdminBypass: true` -> `PERMISSION_DENIED`.
8. **Cross-Retailer PII Snooping**: `GET /retailers/{otherUid}` as active retailer -> `PERMISSION_DENIED`.
9. **Retailer Mutating Product Rate**: `UPDATE /batches/batch_1` setting `wholesaleRate: 1` as active retailer -> `PERMISSION_DENIED`.
10. **Cross-Retailer Enquiry Read**: `GET /enquiries/enq_other` where `retailerUid != auth.uid` -> `PERMISSION_DENIED`.
11. **Spoofed Email Unverified**: `CREATE /retailers/{uid}` with `email: 'BinayRaj61@gmail.com'` and `email_verified: false` -> `PERMISSION_DENIED`.
12. **Resource / ID Poisoning**: `CREATE /enquiries/invalid$id!with*spaces` or 2KB string in `shopName` -> `PERMISSION_DENIED`.
