/**
 * Security Rules Verification Specification (Dirty Dozen Test Matrix)
 * Verifies all 12 adversarial payloads against firestore.rules expectations.
 */

export interface SecurityTestCase {
  id: number;
  name: string;
  collectionPath: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  actor: 'anonymous' | 'pending_retailer' | 'deactivated_retailer' | 'active_retailer' | 'unverified_spoof';
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED';
}

export const dirtyDozenTests: SecurityTestCase[] = [
  {
    id: 1,
    name: 'Unauthenticated Product Read',
    collectionPath: '/products/prod_avomine',
    operation: 'get',
    actor: 'anonymous',
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Pending Retailer Reading Batch Rate',
    collectionPath: '/batches/batch_ava26004',
    operation: 'get',
    actor: 'pending_retailer',
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Deactivated Retailer Listing Products',
    collectionPath: '/products',
    operation: 'list',
    actor: 'deactivated_retailer',
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Approved Retailer Reading Admin Purchase Cost',
    collectionPath: '/admin_batch_costs/batch_ava26004',
    operation: 'get',
    actor: 'active_retailer',
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Self-Approval on Retailer Creation',
    collectionPath: '/retailers/user_123',
    operation: 'create',
    actor: 'pending_retailer',
    payload: {
      uid: 'user_123',
      email: 'retailer@example.com',
      ownerName: 'Test Owner',
      shopName: 'Test Pharma',
      phone: '9876543210',
      drugLicenseNo: 'DL-123',
      city: 'Chatra',
      address: 'Main Road',
      role: 'admin',
      status: 'active',
      priceTier: 'standard',
      customDiscountBonus: 0,
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Privilege Escalation on Retailer Update',
    collectionPath: '/retailers/user_123',
    operation: 'update',
    actor: 'pending_retailer',
    payload: { status: 'active', customDiscountBonus: 15 },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Shadow Field Injection on Retailer Signup',
    collectionPath: '/retailers/user_123',
    operation: 'create',
    actor: 'pending_retailer',
    payload: {
      uid: 'user_123',
      email: 'retailer@example.com',
      ownerName: 'Test Owner',
      shopName: 'Test Pharma',
      phone: '9876543210',
      role: 'retailer',
      status: 'pending',
      priceTier: 'standard',
      customDiscountBonus: 0,
      isAdminBypass: true,
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Cross-Retailer PII Snooping',
    collectionPath: '/retailers/other_retailer_uid',
    operation: 'get',
    actor: 'active_retailer',
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Active Retailer Tampering Batch Wholesale Rate',
    collectionPath: '/batches/batch_ava26004',
    operation: 'update',
    actor: 'active_retailer',
    payload: { wholesaleRate: 1 },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Cross-Retailer Enquiry Access',
    collectionPath: '/enquiries/enq_other_user',
    operation: 'get',
    actor: 'active_retailer',
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Unverified Email Admin Spoof',
    collectionPath: '/products/prod_1',
    operation: 'create',
    actor: 'unverified_spoof',
    payload: { name: 'Spoofed Medicine' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'ID Poisoning on Enquiry Creation',
    collectionPath: '/enquiries/invalid$id!spaces',
    operation: 'create',
    actor: 'active_retailer',
    payload: {
      id: 'invalid$id!spaces',
      retailerUid: 'user_123',
      shopName: 'A'.repeat(2000),
    },
    expectedResult: 'PERMISSION_DENIED',
  },
];
