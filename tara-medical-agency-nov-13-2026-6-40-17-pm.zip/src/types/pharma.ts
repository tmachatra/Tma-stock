import type { Timestamp } from 'firebase/firestore';

export type UserRole = 'retailer' | 'admin';
export type AccountStatus = 'pending' | 'active' | 'deactivated';
export type PriceTier = 'standard' | 'tier_a' | 'tier_b';

export type AvailabilityOverride =
  | 'AUTO'
  | 'IN_STOCK'
  | 'LOW_STOCK'
  | 'OUT_OF_STOCK'
  | 'CONFIRM_AVAILABILITY';

export type AvailabilityStatus =
  | 'IN STOCK'
  | 'LOW STOCK'
  | 'OUT OF STOCK'
  | 'CONFIRM AVAILABILITY';

export interface SessionUser {
  uid: string;
  idCode: string;
  displayName: string;
  role: UserRole;
}

export interface AdminAccount {
  uid: string;
  adminId: string;
  displayName: string;
  passwordSalt: string;
  passwordHash: string;
  mustChangePassword: boolean;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface RetailerAccount {
  uid: string;
  retailerId: string;
  passwordSalt?: string;
  passwordHash?: string;
  email?: string;
  ownerName: string;
  shopName: string;
  phone: string;
  drugLicenseNo: string;
  city: string;
  address: string;
  role: UserRole;
  status: AccountStatus;
  priceTier: PriceTier;
  customDiscountBonus: number;
  mustChangePassword: boolean;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface PharmaCompany {
  id: string;
  name: string;
  shortCode: string;
  active: boolean;
  updatedAt: Timestamp | null;
}

export interface MedicineProduct {
  id: string;
  productCode: string;
  name: string;
  brandName: string;
  genericName: string;
  composition: string;
  companyId: string;
  manufacturer: string;
  category: string;
  packSize: string;
  hsnCode: string;
  minStockLevel: number;
  confirmAvailabilityOnly: boolean;
  imageUrl?: string;
  updatedAt: Timestamp | null;
}

export interface MedicineBatch {
  id: string;
  productId: string;
  batchNumber: string;
  expiryDate: string; // YYYY-MM or ""
  expiryDisplay: string; // MM/YYYY or "Missing"
  mrp: number;
  wholesaleRate: number;
  discountPercent: number;
  schemeDetails: string;
  dealRateAdjustable?: boolean;
  availableQty: number;
  availabilityOverride: AvailabilityOverride;
  isActive: boolean;
  updatedAt: Timestamp | null;
}

export interface AdminBatchCost {
  batchId: string;
  productId: string;
  purchaseRate: number;
  updatedAt: Timestamp | null;
}

export interface ProductWithBatches {
  product: MedicineProduct;
  batches: MedicineBatch[];
  validInStockBatches: MedicineBatch[];
  earliestValidBatch: MedicineBatch | null;
  primaryBatch: MedicineBatch | null;
  totalAvailableQty: number;
  availabilityStatus: AvailabilityStatus;
  effectiveWholesaleRate: number;
  effectiveUnitAfterScheme: number | null;
  mrp: number;
  discountPercent: number;
  schemeDetails: string;
  dealRateAdjustable: boolean;
  earliestExpiryDisplay: string;
  earliestExpiryIso: string;
  hasMissingInfo: boolean;
  missingReasons: string[];
  latestUpdatedAt: Date | null;
}

export interface CartEnquiryItem {
  productId: string;
  batchId: string;
  productName: string;
  brandName: string;
  manufacturer: string;
  packSize: string;
  qty: number;
  wholesaleRate: number;
  mrp: number;
  discountPercent: number;
  schemeDetails: string;
  dealRateAdjustable?: boolean;
  expiryDisplay: string;
  availabilityStatus: AvailabilityStatus;
}

export interface RetailerEnquiry {
  id: string;
  retailerUid: string;
  retailerShopName: string;
  retailerPhone: string;
  notes: string;
  itemCount: number;
  estimatedTotal: number;
  status: 'draft' | 'sent_whatsapp';
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface EnquiryItem {
  id: string;
  productId: string;
  batchId: string;
  productName: string;
  packSize: string;
  qty: number;
  wholesaleRate: number;
  schemeDetails: string;
  expiryDisplay: string;
  lineTotal: number;
}

export interface ExcelImportLog {
  id: string;
  adminUid: string;
  fileName: string;
  totalRows: number;
  createdProducts: number;
  updatedProducts: number;
  addedBatches: number;
  updatedBatches: number;
  skippedRows: number;
  createdAt: Timestamp | null;
}

export type CustomerActivityEventType =
  | 'search'
  | 'zero_result_search'
  | 'product_view'
  | 'compare_add'
  | 'cart_add'
  | 'enquiry_submit'
  | 'deal_filter'
  | 'company_view';

export interface CustomerActivityEvent {
  id: string;
  retailerUid: string;
  retailerId: string;
  shopName: string;
  city: string;
  eventType: CustomerActivityEventType;
  productId?: string;
  productName?: string;
  companyId?: string;
  companyName?: string;
  searchQuery?: string;
  qty?: number;
  estimatedValue?: number;
  resultCount?: number;
  createdAt: Timestamp | null;
}

export type AppScreen =
  | 'home'
  | 'search'
  | 'companies'
  | 'compare'
  | 'enquiry'
  | 'profile'
  | 'analytics'
  | 'products'
  | 'admin';

export type AdminSubTab =
  | 'overview'
  | 'analytics'
  | 'products'
  | 'batches'
  | 'import'
  | 'directory';
