import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  XCircle,
} from 'lucide-react';
import type { AvailabilityStatus } from '../types/pharma';

export const StatusTag: React.FC<{
  status: AvailabilityStatus;
  compact?: boolean;
}> = ({ status, compact = false }) => {
  const styles: Record<
    AvailabilityStatus,
    { bg: string; text: string; border: string; Icon: React.ElementType }
  > = {
    'IN STOCK': {
      bg: 'bg-[#D4FF3F]/35',
      text: 'text-slate-950',
      border: 'border-lime-500/50',
      Icon: CheckCircle2,
    },
    'LOW STOCK': {
      bg: 'bg-[#CBB3E8]/45',
      text: 'text-slate-950',
      border: 'border-[#CBB3E8]',
      Icon: AlertTriangle,
    },
    'OUT OF STOCK': {
      bg: 'bg-[#E34234]/12',
      text: 'text-[#B91C1C]',
      border: 'border-[#E34234]/40',
      Icon: XCircle,
    },
    'CONFIRM AVAILABILITY': {
      bg: 'bg-slate-100',
      text: 'text-slate-800',
      border: 'border-slate-300',
      Icon: HelpCircle,
    },
  };

  const cfg = styles[status];
  const Icon = cfg.Icon;

  return (
    <span
      className={`inline-flex items-center gap-1 rounded-md border ${cfg.bg} ${cfg.text} ${cfg.border} ${
        compact ? 'px-1.5 py-0.5 text-[11px]' : 'px-2 py-0.5 text-xs'
      } font-semibold tracking-tight whitespace-nowrap shrink-0`}
    >
      <Icon className={compact ? 'w-3 h-3 shrink-0' : 'w-3.5 h-3.5 shrink-0'} />
      <span>{status}</span>
    </span>
  );
};
