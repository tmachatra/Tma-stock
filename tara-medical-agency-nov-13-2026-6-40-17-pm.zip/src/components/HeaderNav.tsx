import React from 'react';
import {
  BarChart3,
  Building2,
  ClipboardList,
  Home,
  Package,
  Search,
  User,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import type { AppScreen } from '../types/pharma';

interface HeaderNavProps {
  activeScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  enquiryCount: number;
  compareCount: number;
  compareFlash?: boolean;
  enquiryFlash?: boolean;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  activeScreen,
  onNavigate,
  enquiryCount,
  compareCount,
  compareFlash = false,
  enquiryFlash = false,
}) => {
  const { isAdmin, viewMode, setViewMode } = useAuth();

  const handleNavClick = (screen: AppScreen) => {
    if (isAdmin) {
      setViewMode('admin');
      onNavigate(screen === 'home' ? 'admin' : screen);
      return;
    }
    if (viewMode === 'admin') {
      setViewMode('retailer');
    }
    onNavigate(screen);
  };

  const effectiveActive: AppScreen = isAdmin
    ? activeScreen === 'analytics' ||
      activeScreen === 'enquiry' ||
      activeScreen === 'products' ||
      activeScreen === 'profile'
      ? activeScreen
      : 'home'
    : activeScreen;

  return (
    <>
      {/* Top Bar Contract: Zone 1 (Wordmark) — Zone 2 (4-5 Nav Links) — Zone 3 (Primary Actions) */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 h-14 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => handleNavClick(isAdmin ? 'admin' : 'home')}
          className="font-display text-base sm:text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 flex items-center gap-2.5 cursor-pointer"
        >
          <img
            src="/assets/aistudio/WhatsApp_Image_2026-11-13_at_6.38.31_PM_700b3c79.jpeg"
            alt="Tara Medical Agency"
            className="w-7 h-7 rounded-md object-cover shrink-0"
          />
          <span>Tara Medical Agency</span>
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          {isAdmin ? (
            <>
              <button
                type="button"
                onClick={() => handleNavClick('admin')}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  effectiveActive === 'home'
                    ? 'border-slate-900 text-slate-950 font-semibold'
                    : 'border-transparent hover:text-slate-900'
                }`}
              >
                Home
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('products')}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  effectiveActive === 'products'
                    ? 'border-slate-900 text-slate-950 font-semibold'
                    : 'border-transparent hover:text-slate-900'
                }`}
              >
                Products
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('analytics')}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  effectiveActive === 'analytics'
                    ? 'border-slate-900 text-slate-950 font-semibold'
                    : 'border-transparent hover:text-slate-900'
                }`}
              >
                Analytics
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => handleNavClick('home')}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  effectiveActive === 'home'
                    ? 'border-slate-900 text-slate-950 font-semibold'
                    : 'border-transparent hover:text-slate-900'
                }`}
              >
                Home
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('search')}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  effectiveActive === 'search'
                    ? 'border-slate-900 text-slate-950 font-semibold'
                    : 'border-transparent hover:text-slate-900'
                }`}
              >
                Medicines
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('companies')}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  effectiveActive === 'companies'
                    ? 'border-slate-900 text-slate-950 font-semibold'
                    : 'border-transparent hover:text-slate-900'
                }`}
              >
                Companies
              </button>
              {compareCount > 0 && (
                <button
                  type="button"
                  onClick={() => handleNavClick('compare')}
                  className={`whitespace-nowrap shrink-0 px-2 py-1 rounded-md border-b-2 transition-all cursor-pointer ${
                    compareFlash
                      ? 'bg-[#D4FF3F] text-slate-950 font-bold border-slate-900 animate-pulse'
                      : effectiveActive === 'compare'
                      ? 'border-slate-900 text-slate-950 font-semibold'
                      : 'border-transparent hover:text-slate-900'
                  }`}
                >
                  Compare ({compareCount})
                </button>
              )}
            </>
          )}
        </nav>

        {/* Zone 3: Primary Action + Profile */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => handleNavClick('enquiry')}
            className={`inline-flex items-center gap-2 min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap shrink-0 cursor-pointer ${
              isAdmin && effectiveActive === 'enquiry'
                ? 'bg-slate-900 text-[#D4FF3F] ring-2 ring-slate-900'
                : !isAdmin && enquiryFlash
                ? 'bg-[#D4FF3F] text-slate-950 ring-4 ring-[#CBB3E8] animate-pulse'
                : 'bg-[#D4FF3F] text-slate-950 hover:brightness-95'
            }`}
          >
            <ClipboardList className="w-4 h-4 shrink-0" />
            <span className="tabular-nums">Enquiry ({enquiryCount})</span>
          </button>

          <button
            type="button"
            onClick={() => handleNavClick('profile')}
            aria-label="Profile"
            className={`hidden md:inline-flex items-center gap-1.5 min-h-[40px] px-3 py-1.5 rounded-lg border text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer ${
              effectiveActive === 'profile'
                ? 'bg-slate-900 border-slate-900 text-white'
                : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile</span>
          </button>
        </div>
      </header>

      {/* Mobile Bottom Thumb Navigation Bar (Compact <= 60px, total sticky < 15% viewport) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe"
      >
        <div className="grid grid-cols-5 items-center h-14">
          <button
            type="button"
            onClick={() => handleNavClick(isAdmin ? 'admin' : 'home')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
              effectiveActive === 'home'
                ? 'text-slate-950 font-bold'
                : 'text-slate-500 font-medium'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 tracking-tight">Home</span>
          </button>

          {isAdmin ? (
            <button
              type="button"
              onClick={() => handleNavClick('products')}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
                effectiveActive === 'products'
                  ? 'text-slate-950 font-bold'
                  : 'text-slate-500 font-medium'
              }`}
            >
              <Package className="w-5 h-5" />
              <span className="text-[10px] mt-0.5 tracking-tight">Products</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => handleNavClick('search')}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
                effectiveActive === 'search'
                  ? 'text-slate-950 font-bold'
                  : 'text-slate-500 font-medium'
              }`}
            >
              <Search className="w-5 h-5" />
              <span className="text-[10px] mt-0.5 tracking-tight">Search</span>
            </button>
          )}

          {!isAdmin && (
            <button
              type="button"
              onClick={() => handleNavClick('companies')}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
                effectiveActive === 'companies'
                  ? 'text-slate-950 font-bold'
                  : 'text-slate-500 font-medium'
              }`}
            >
              <Building2 className="w-5 h-5" />
              <span className="text-[10px] mt-0.5 tracking-tight">Companies</span>
            </button>
          )}

          {isAdmin && (
            <button
              type="button"
              onClick={() => handleNavClick('analytics')}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
                effectiveActive === 'analytics'
                  ? 'text-slate-950 font-bold'
                  : 'text-slate-500 font-medium'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span className="text-[10px] mt-0.5 tracking-tight">Analytics</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handleNavClick('enquiry')}
            className={`relative flex flex-col items-center justify-center h-full min-h-[44px] transition-all ${
              !isAdmin && enquiryFlash
                ? 'bg-[#D4FF3F] text-slate-950 font-bold ring-2 ring-inset ring-slate-900 animate-pulse'
                : effectiveActive === 'enquiry'
                ? 'text-slate-950 font-bold'
                : 'text-slate-500 font-medium'
            }`}
          >
            <ClipboardList className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 tracking-tight tabular-nums">
              Enquiry ({enquiryCount})
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleNavClick('profile')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
              effectiveActive === 'profile'
                ? 'text-slate-950 font-bold'
                : 'text-slate-500 font-medium'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 tracking-tight">Profile</span>
          </button>
        </div>
      </nav>
    </>
  );
};
