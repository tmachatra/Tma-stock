import React, { useMemo, useState } from 'react';
import {
  Check,
  ChevronDown,
  ChevronUp,
  ClipboardList,
  Copy,
  Download,
  IndianRupee,
  MessageCircle,
  Package,
  Phone,
  Search,
  Store,
} from 'lucide-react';
import { formatDateTimeIST, formatINR } from '../../lib/pharmaUtils';
import { fetchSingleEnquiryItems } from '../../services/catalogService';
import type {
  EnquiryItem,
  RetailerAccount,
  RetailerEnquiry,
} from '../../types/pharma';

interface AdminEnquiriesViewProps {
  enquiries: RetailerEnquiry[];
  enquiryItems: Array<EnquiryItem & { enquiryId: string }>;
  retailers: RetailerAccount[];
}

type EnquiryTimeframe = 'all' | 'today' | '7d' | '30d';

function toMillis(ts: { toDate?: () => Date } | null | undefined): number {
  if (!ts || typeof ts.toDate !== 'function') return 0;
  try {
    return ts.toDate().getTime();
  } catch {
    return 0;
  }
}

function escapeCsvCell(val: string | number): string {
  const s = String(val ?? '');
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function normalizeWaPhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (!digits) return '';
  if (digits.length === 10) return `91${digits}`;
  return digits;
}

export const AdminEnquiriesView: React.FC<AdminEnquiriesViewProps> = ({
  enquiries,
  enquiryItems,
  retailers,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [timeframe, setTimeframe] = useState<EnquiryTimeframe>('all');
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({});
  const [extraItemsByEnq, setExtraItemsByEnq] = useState<
    Record<string, Array<EnquiryItem & { enquiryId: string }>>
  >({});
  const [loadingItemsId, setLoadingItemsId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const retailerByUid = useMemo(() => {
    const map = new Map<string, RetailerAccount>();
    for (const r of retailers) {
      map.set(r.uid, r);
    }
    return map;
  }, [retailers]);

  const itemsByEnquiryId = useMemo(() => {
    const map = new Map<string, Array<EnquiryItem & { enquiryId: string }>>();
    for (const item of enquiryItems) {
      const list = map.get(item.enquiryId) || [];
      list.push(item);
      map.set(item.enquiryId, list);
    }
    for (const [enqId, list] of Object.entries(extraItemsByEnq)) {
      if (!map.has(enqId)) {
        map.set(enqId, list);
      }
    }
    return map;
  }, [enquiryItems, extraItemsByEnq]);

  const filteredEnquiries = useMemo(() => {
    const now = Date.now();
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);

    let cutoff = 0;
    if (timeframe === 'today') cutoff = startOfToday.getTime();
    else if (timeframe === '7d') cutoff = now - 7 * 24 * 60 * 60 * 1000;
    else if (timeframe === '30d') cutoff = now - 30 * 24 * 60 * 60 * 1000;

    const q = searchQuery.trim().toLowerCase();

    return enquiries.filter((enq) => {
      if (cutoff > 0) {
        const ms = toMillis(enq.createdAt);
        if (ms > 0 && ms < cutoff) return false;
      }
      if (!q) return true;
      const ret = retailerByUid.get(enq.retailerUid);
      const items = itemsByEnquiryId.get(enq.id) || [];
      return (
        enq.retailerShopName.toLowerCase().includes(q) ||
        enq.retailerPhone.toLowerCase().includes(q) ||
        enq.notes.toLowerCase().includes(q) ||
        (ret?.retailerId || '').toLowerCase().includes(q) ||
        (ret?.city || '').toLowerCase().includes(q) ||
        items.some((i) => i.productName.toLowerCase().includes(q))
      );
    });
  }, [enquiries, timeframe, searchQuery, retailerByUid, itemsByEnquiryId]);

  const summary = useMemo(() => {
    let totalValue = 0;
    let totalItems = 0;
    const shops = new Set<string>();

    for (const e of filteredEnquiries) {
      totalValue += e.estimatedTotal || 0;
      totalItems += e.itemCount || 0;
      shops.add(e.retailerUid);
    }

    return {
      count: filteredEnquiries.length,
      totalValue,
      totalItems,
      uniqueShops: shops.size,
    };
  }, [filteredEnquiries]);

  const isExpanded = (enqId: string, idx: number) => {
    if (enqId in expandedIds) return expandedIds[enqId];
    return idx < 3;
  };

  const toggleExpand = async (enqId: string, idx: number) => {
    const next = !isExpanded(enqId, idx);
    setExpandedIds((prev) => ({ ...prev, [enqId]: next }));
    if (next && !itemsByEnquiryId.has(enqId)) {
      setLoadingItemsId(enqId);
      const fetched = await fetchSingleEnquiryItems(enqId);
      setExtraItemsByEnq((prev) => ({ ...prev, [enqId]: fetched }));
      setLoadingItemsId(null);
    }
  };

  const handleCopySummary = async (
    enq: RetailerEnquiry,
    items: Array<EnquiryItem & { enquiryId: string }>,
    ret?: RetailerAccount
  ) => {
    const lines = [
      `Customer Enquiry — ${enq.retailerShopName}${ret?.retailerId ? ` (${ret.retailerId})` : ''}`,
      `Phone: ${enq.retailerPhone || ret?.phone || 'N/A'}${ret?.city ? ` · ${ret.city}` : ''}`,
      `Date: ${formatDateTimeIST(enq.createdAt)}`,
      '',
      ...items.map(
        (item, i) =>
          `${i + 1}. ${item.productName} (${item.packSize}) × ${item.qty} @ ${formatINR(item.wholesaleRate)} = ${formatINR(item.lineTotal)}${
            item.schemeDetails ? ` [${item.schemeDetails}]` : ''
          }`
      ),
      '',
      `Estimated Total: ${formatINR(enq.estimatedTotal)}`,
      ...(enq.notes ? [`Note: ${enq.notes}`] : []),
    ];
    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      setCopiedId(enq.id);
      setTimeout(() => setCopiedId((curr) => (curr === enq.id ? null : curr)), 2000);
    } catch {
      // Ignore clipboard permission failure
    }
  };

  const handleExportCsv = () => {
    const headers = [
      'Enquiry ID',
      'Date',
      'Retailer ID',
      'Shop Name',
      'Phone',
      'City',
      'Status',
      'Notes',
      'Medicine Name',
      'Pack',
      'Qty',
      'Rate (INR)',
      'Scheme',
      'Expiry',
      'Line Total (INR)',
      'Enquiry Total (INR)',
    ];
    const rows = [headers.map(escapeCsvCell).join(',')];

    for (const enq of filteredEnquiries) {
      const ret = retailerByUid.get(enq.retailerUid);
      const items = itemsByEnquiryId.get(enq.id) || [];
      if (items.length === 0) {
        rows.push(
          [
            enq.id,
            formatDateTimeIST(enq.createdAt),
            ret?.retailerId || '',
            enq.retailerShopName,
            enq.retailerPhone,
            ret?.city || '',
            enq.status,
            enq.notes,
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            enq.estimatedTotal.toFixed(2),
          ]
            .map(escapeCsvCell)
            .join(',')
        );
      } else {
        for (const item of items) {
          rows.push(
            [
              enq.id,
              formatDateTimeIST(enq.createdAt),
              ret?.retailerId || '',
              enq.retailerShopName,
              enq.retailerPhone,
              ret?.city || '',
              enq.status,
              enq.notes,
              item.productName,
              item.packSize,
              item.qty,
              item.wholesaleRate.toFixed(2),
              item.schemeDetails,
              item.expiryDisplay,
              item.lineTotal.toFixed(2),
              enq.estimatedTotal.toFixed(2),
            ]
              .map(escapeCsvCell)
              .join(',')
          );
        }
      }
    }

    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `tara-medical-customer-enquiries-${timeframe}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 pb-24 md:pb-12">
      {/* Header */}
      <section className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-[#CBB3E8]">
            Tara Medical Agency · Admin Enquiries Inbox
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold text-white flex items-center gap-2.5">
            <ClipboardList className="w-6 h-6 text-[#D4FF3F]" />
            <span>Customer Enquiries Received</span>
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-300">
            Every medicine shortlist sent by retailers to Agency WhatsApp is automatically logged here with shop details, quantities, and rates.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportCsv}
          className="self-start lg:self-center inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-xl bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>Export Enquiries CSV</span>
        </button>
      </section>

      {/* KPI Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Enquiries</span>
            <ClipboardList className="w-4 h-4 text-slate-500" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {summary.count}
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Submitted by retailers
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Estimated Order Value</span>
            <IndianRupee className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {formatINR(summary.totalValue)}
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Excl. GST subtotal
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Medicine Lines</span>
            <Package className="w-4 h-4 text-slate-500" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {summary.totalItems}
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Products enquired
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Active Customers</span>
            <Store className="w-4 h-4 text-slate-500" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {summary.uniqueShops}
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Unique pharmacies
          </div>
        </div>
      </section>

      {/* Search & Timeframe Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          {(
            [
              { id: 'all', label: 'All Enquiries' },
              { id: 'today', label: 'Today' },
              { id: '7d', label: 'Last 7 Days' },
              { id: '30d', label: 'Last 30 Days' },
            ] as const
          ).map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setTimeframe(opt.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                timeframe === opt.id
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search shop, ID, phone, medicine, note..."
            className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
          />
        </div>
      </div>

      {/* Enquiries Feed */}
      {filteredEnquiries.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-2">
          <ClipboardList className="w-8 h-8 text-slate-400 mx-auto" />
          <div className="font-display text-base font-bold text-slate-900">
            No customer enquiries found
          </div>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
            When a retailer sends an enquiry to Tara Medical Agency on WhatsApp, the shop details, medicines, quantities, and notes appear here automatically.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredEnquiries.map((enq, idx) => {
            const ret = retailerByUid.get(enq.retailerUid);
            const items = itemsByEnquiryId.get(enq.id) || [];
            const expanded = isExpanded(enq.id, idx);
            const waPhone = normalizeWaPhone(enq.retailerPhone || ret?.phone || '');

            return (
              <article
                key={enq.id}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden"
              >
                <div className="p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-display text-base sm:text-lg font-bold text-slate-950">
                        {enq.retailerShopName || ret?.shopName || 'Retailer'}
                      </h2>
                      {ret?.retailerId && (
                        <span className="px-2 py-0.5 rounded-md bg-[#CBB3E8]/45 text-slate-950 font-mono text-[11px] font-bold">
                          {ret.retailerId}
                        </span>
                      )}
                      <span
                        className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                          enq.status === 'sent_whatsapp'
                            ? 'bg-[#D4FF3F] text-slate-950'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {enq.status === 'sent_whatsapp' ? 'Sent on WhatsApp' : 'Draft'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600">
                      <span className="font-mono">{formatDateTimeIST(enq.createdAt)}</span>
                      {ret?.ownerName && <span>Contact: {ret.ownerName}</span>}
                      {(enq.retailerPhone || ret?.phone) && (
                        <span className="font-mono font-semibold text-slate-800">
                          {enq.retailerPhone || ret?.phone}
                        </span>
                      )}
                      {ret?.city && <span>{ret.city}</span>}
                      {ret?.drugLicenseNo && (
                        <span className="font-mono text-slate-500">
                          DL: {ret.drugLicenseNo}
                        </span>
                      )}
                    </div>

                    {enq.notes && (
                      <div className="mt-1.5 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-800">
                        <span className="font-bold">Customer Note:</span> {enq.notes}
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                    <div className="text-left lg:text-right mr-1">
                      <div className="font-mono text-lg font-extrabold text-slate-950 tabular-nums">
                        {formatINR(enq.estimatedTotal)}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono tabular-nums">
                        {enq.itemCount} {enq.itemCount === 1 ? 'item' : 'items'}
                      </div>
                    </div>

                    {waPhone && (
                      <a
                        href={`https://wa.me/${waPhone}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 min-h-[38px] px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold hover:bg-emerald-100"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Reply</span>
                      </a>
                    )}

                    {(enq.retailerPhone || ret?.phone) && (
                      <a
                        href={`tel:${enq.retailerPhone || ret?.phone}`}
                        className="inline-flex items-center gap-1.5 min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-800 text-xs font-semibold hover:bg-slate-50"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>Call</span>
                      </a>
                    )}

                    <button
                      type="button"
                      onClick={() => handleCopySummary(enq, items, ret)}
                      className="inline-flex items-center gap-1.5 min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-800 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
                    >
                      {copiedId === enq.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => void toggleExpand(enq.id, idx)}
                      className="inline-flex items-center gap-1 min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 cursor-pointer"
                    >
                      <span>{expanded ? 'Hide Items' : 'View Items'}</span>
                      {expanded ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {expanded && (
                  <div className="border-t border-slate-200 bg-slate-50/70">
                    {loadingItemsId === enq.id ? (
                      <div className="p-4 text-xs text-slate-500">
                        Loading enquired medicines...
                      </div>
                    ) : items.length === 0 ? (
                      <div className="p-4 text-xs text-slate-500">
                        No line-item details found for this enquiry.
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs sm:text-sm">
                          <thead>
                            <tr className="border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-500 bg-slate-100/70">
                              <th className="py-2.5 px-4">Medicine</th>
                              <th className="py-2.5 px-3">Pack</th>
                              <th className="py-2.5 px-3 text-right">Qty</th>
                              <th className="py-2.5 px-3 text-right">Rate</th>
                              <th className="py-2.5 px-3">Deal / Scheme</th>
                              <th className="py-2.5 px-3">Expiry</th>
                              <th className="py-2.5 px-4 text-right">Line Total</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200/70 bg-white">
                            {items.map((item) => (
                              <tr key={item.id}>
                                <td className="py-2.5 px-4 font-bold text-slate-950">
                                  {item.productName}
                                </td>
                                <td className="py-2.5 px-3 font-mono text-xs text-slate-600">
                                  {item.packSize}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-950 tabular-nums">
                                  {item.qty}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-800">
                                  {formatINR(item.wholesaleRate)}
                                </td>
                                <td className="py-2.5 px-3 text-xs">
                                  {item.schemeDetails ? (
                                    <span className="px-1.5 py-0.5 rounded bg-[#CBB3E8]/45 font-mono font-semibold text-slate-950">
                                      {item.schemeDetails}
                                    </span>
                                  ) : (
                                    <span className="text-slate-400">—</span>
                                  )}
                                </td>
                                <td className="py-2.5 px-3 font-mono text-xs text-slate-600">
                                  {item.expiryDisplay || '—'}
                                </td>
                                <td className="py-2.5 px-4 text-right font-mono font-bold tabular-nums text-slate-950">
                                  {formatINR(item.lineTotal)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
