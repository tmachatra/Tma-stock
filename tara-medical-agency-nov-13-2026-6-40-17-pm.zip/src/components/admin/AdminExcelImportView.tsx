import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Upload,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { useAuth } from '../../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { formatDateTimeIST, parseExpiryToIso, slugId } from '../../lib/pharmaUtils';
import { recordImportLog } from '../../services/catalogService';
import type {
  ExcelImportLog,
  MedicineBatch,
  MedicineProduct,
  PharmaCompany,
} from '../../types/pharma';

type AppFieldKey =
  | 'ignore'
  | 'productCode'
  | 'productName'
  | 'brandName'
  | 'genericName'
  | 'composition'
  | 'manufacturer'
  | 'category'
  | 'packSize'
  | 'hsnCode'
  | 'imageUrl'
  | 'mrp'
  | 'wholesaleRate'
  | 'purchaseRate'
  | 'discountPercent'
  | 'schemeDetails'
  | 'dealRateAdjustable'
  | 'availableQty'
  | 'batchNumber'
  | 'expiryDate';

const APP_FIELD_OPTIONS: { key: AppFieldKey; label: string }[] = [
  { key: 'ignore', label: '— Ignore Column —' },
  { key: 'productName', label: 'Product Name *' },
  { key: 'brandName', label: 'Brand Name' },
  { key: 'genericName', label: 'Generic / Salt Name' },
  { key: 'composition', label: 'Composition' },
  { key: 'manufacturer', label: 'Manufacturer / Company' },
  { key: 'packSize', label: 'Pack Size' },
  { key: 'category', label: 'Category' },
  { key: 'productCode', label: 'Product Code' },
  { key: 'hsnCode', label: 'HSN Code' },
  { key: 'imageUrl', label: 'Product Image URL' },
  { key: 'batchNumber', label: 'Batch Number' },
  { key: 'expiryDate', label: 'Expiry Date' },
  { key: 'mrp', label: 'Retail MRP' },
  { key: 'wholesaleRate', label: 'Wholesale Selling Rate' },
  { key: 'purchaseRate', label: 'Purchase Rate (Admin Only)' },
  { key: 'discountPercent', label: 'Discount %' },
  { key: 'schemeDetails', label: 'Scheme / Deal' },
  { key: 'dealRateAdjustable', label: 'Deal Rate Adjustable (Yes/No)' },
  { key: 'availableQty', label: 'Available Stock Quantity' },
];

function guessColumnMapping(header: string): AppFieldKey {
  const h = header.trim().toLowerCase().replace(/[^a-z0-9%]+/g, ' ');
  if (/(product description|product name|item name|medicine|particular)/.test(h))
    return 'productName';
  if (/brand/.test(h)) return 'brandName';
  if (/(generic|salt)/.test(h)) return 'genericName';
  if (/composition|formula/.test(h)) return 'composition';
  if (/(mfd|mkt|manufacturer|company|mfg)/.test(h)) return 'manufacturer';
  if (/^pack/.test(h) || /packing/.test(h)) return 'packSize';
  if (/category|type/.test(h)) return 'category';
  if (/(product code|item code|sku)/.test(h)) return 'productCode';
  if (/hsn/.test(h)) return 'hsnCode';
  if (/(image|photo|img|picture)/.test(h)) return 'imageUrl';
  if (/batch/.test(h)) return 'batchNumber';
  if (/(exp|expiry)/.test(h)) return 'expiryDate';
  if (/m\s*r\s*p|mrp/.test(h)) return 'mrp';
  if (/(purchase|cost|pts|buying)/.test(h)) return 'purchaseRate';
  if (/(wholesale|ptr|selling|rate)/.test(h)) return 'wholesaleRate';
  if (/disc/.test(h)) return 'discountPercent';
  if (/(adjust|rate.?adj)/.test(h)) return 'dealRateAdjustable';
  if (/(schm|scheme|deal|free)/.test(h)) return 'schemeDetails';
  if (/(qty|quantity|stock|avail)/.test(h)) return 'availableQty';
  return 'ignore';
}

interface ParsedPreviewRow {
  rowIndex: number;
  productCode: string;
  productName: string;
  brandName: string;
  genericName: string;
  composition: string;
  manufacturer: string;
  category: string;
  packSize: string;
  hsnCode: string;
  imageUrl: string;
  batchNumber: string;
  expiryRaw: unknown;
  expiryIso: string;
  expiryDisplay: string;
  mrp: number;
  wholesaleRate: number;
  purchaseRate: number;
  discountPercent: number;
  schemeDetails: string;
  dealRateAdjustable: boolean;
  availableQty: number;
  matchedProductId: string | null;
  matchedBatchId: string | null;
  isDuplicateInFile: boolean;
  errors: string[];
  warnings: string[];
}

interface AdminExcelImportViewProps {
  existingProducts: MedicineProduct[];
  existingBatches: MedicineBatch[];
  companies: PharmaCompany[];
  importLogs: ExcelImportLog[];
}

export const AdminExcelImportView: React.FC<AdminExcelImportViewProps> = ({
  existingProducts,
  existingBatches,
  companies,
  importLogs,
}) => {
  const { user } = useAuth();
  const [fileName, setFileName] = useState<string>('');
  const [workbook, setWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [activeSheet, setActiveSheet] = useState<string>('');
  const [headers, setHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<Record<string, unknown>[]>([]);
  const [mapping, setMapping] = useState<Record<string, AppFieldKey>>({});
  const [conflictMode, setConflictMode] = useState<'update' | 'skip'>('update');
  const [importing, setImporting] = useState(false);
  const [importSummary, setImportSummary] = useState<{
    totalRows: number;
    createdProducts: number;
    updatedProducts: number;
    addedBatches: number;
    updatedBatches: number;
    skippedRows: number;
  } | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);

  const loadSheet = (wb: XLSX.WorkBook, sheetName: string) => {
    const sheet = wb.Sheets[sheetName];
    if (!sheet) return;
    const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
      defval: '',
    });
    if (json.length === 0) {
      setHeaders([]);
      setRawRows([]);
      setFileError('Selected sheet has no rows.');
      return;
    }
    const cols = Object.keys(json[0]);
    const initialMap: Record<string, AppFieldKey> = {};
    for (const c of cols) {
      initialMap[c] = guessColumnMapping(c);
    }
    setActiveSheet(sheetName);
    setHeaders(cols);
    setRawRows(json);
    setMapping(initialMap);
    setFileError(null);
    setImportSummary(null);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileError(null);
    setImportSummary(null);
    try {
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: 'array' });
      if (!wb.SheetNames.length) {
        setFileError('No worksheets found in this file.');
        return;
      }
      setFileName(file.name);
      setWorkbook(wb);
      setSheetNames(wb.SheetNames);
      loadSheet(wb, wb.SheetNames[0]);
    } catch (err) {
      setFileError(
        err instanceof Error ? err.message : 'Unable to parse Excel/CSV file.'
      );
    }
  };

  const handleDownloadSampleTemplate = () => {
    const sampleRows = [
      {
        'Product Code': 'ABT-AVO-10',
        'Product Description': 'AVOMINE TAB',
        'Generic Salt': 'Promethazine Theoclate',
        Composition: 'Promethazine Theoclate IP 25 mg',
        'Mfd/Mkt By': 'Abbott India',
        Pack: '1*10',
        'HSN Code': '30049021',
        'Batch No.': 'AVA26004',
        'Exp Date': '1/29',
        'M.R.P.': 69.83,
        'Wholesale Rate': 56.5,
        'Purchase Rate': 53.2,
        'Disc %': 8,
        Schm: '9+1',
        Quantity: 45,
      },
      {
        'Product Code': 'ARS-FLX-15',
        'Product Description': 'FLEXON TAB',
        'Generic Salt': 'Ibuprofen + Paracetamol',
        Composition: 'Ibuprofen 400mg + Paracetamol 325mg',
        'Mfd/Mkt By': 'Aristo Pharmaceuticals',
        Pack: '1*15',
        'HSN Code': '30049061',
        'Batch No.': 'DPD260613',
        'Exp Date': '03/2029',
        'M.R.P.': 35.25,
        'Wholesale Rate': 28.9,
        'Purchase Rate': 26.86,
        'Disc %': 8,
        Schm: '24+1',
        Quantity: 60,
      },
    ];
    const ws = XLSX.utils.json_to_sheet(sampleRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'InvoiceImportTemplate');
    XLSX.writeFile(wb, 'Tara_Medical_Import_Template.xlsx');
  };

  const previewRows = useMemo<ParsedPreviewRow[]>(() => {
    if (rawRows.length === 0) return [];

    const seenKeysInFile = new Set<string>();

    return rawRows.map((row, idx) => {
      const getVal = (field: AppFieldKey): unknown => {
        const col = Object.keys(mapping).find((k) => mapping[k] === field);
        return col ? row[col] : '';
      };

      const rawName = String(getVal('productName') || '').trim();
      const rawBrand = String(getVal('brandName') || '').trim() || rawName;
      const rawCode = String(getVal('productCode') || '').trim();
      const rawGeneric = String(getVal('genericName') || '').trim();
      const rawComp = String(getVal('composition') || '').trim();
      const rawMfg = String(getVal('manufacturer') || '').trim() || 'General Pharma';
      const rawCat = String(getVal('category') || '').trim() || 'Tablets';
      const rawPack = String(getVal('packSize') || '').trim() || '1*10';
      const rawHsn = String(getVal('hsnCode') || '').trim();
      const rawImageUrl = String(getVal('imageUrl') || '').trim();
      const rawBatch = String(getVal('batchNumber') || '').trim();
      const rawExp = getVal('expiryDate');
      const rawScheme = String(getVal('schemeDetails') || '').trim();
      const rawAdj = String(getVal('dealRateAdjustable') || '')
        .trim()
        .toLowerCase();
      const dealRateAdjustable =
        !!rawScheme &&
        /^(yes|y|true|1|adj|adjustable)$/.test(rawAdj);

      const parseNum = (v: unknown, label: string, errs: string[]): number => {
        if (v === '' || v === null || v === undefined) return 0;
        const n = Number(String(v).replace(/[^0-9.-]/g, ''));
        if (!Number.isFinite(n) || n < 0) {
          errs.push(`Invalid ${label}`);
          return 0;
        }
        return n;
      };

      const errors: string[] = [];
      const warnings: string[] = [];

      if (!rawName) errors.push('Missing product name');

      const mrp = parseNum(getVal('mrp'), 'MRP', errors);
      const wholesaleRate = parseNum(
        getVal('wholesaleRate'),
        'Wholesale Rate',
        errors
      );
      const purchaseRate = parseNum(
        getVal('purchaseRate'),
        'Purchase Rate',
        errors
      );
      const discountPercent = parseNum(
        getVal('discountPercent'),
        'Discount %',
        errors
      );
      const availableQty = parseNum(getVal('availableQty'), 'Stock Qty', errors);

      if (wholesaleRate <= 0) warnings.push('Missing wholesale rate');
      const parsedExp = parseExpiryToIso(rawExp);
      if (!parsedExp.expiryDate) {
        warnings.push('Missing/invalid expiry date');
      }

      // Match existing product by productCode or normalized (name + packSize)
      const matchedProduct = existingProducts.find((p) => {
        if (rawCode && p.productCode && p.productCode.toLowerCase() === rawCode.toLowerCase()) {
          return true;
        }
        return (
          p.name.toLowerCase() === rawName.toLowerCase() &&
          p.packSize.toLowerCase() === rawPack.toLowerCase()
        );
      });

      const batchNumNormalized = rawBatch || 'DEFAULT';
      const matchedBatch = matchedProduct
        ? existingBatches.find(
            (b) =>
              b.productId === matchedProduct.id &&
              b.batchNumber.toLowerCase() === batchNumNormalized.toLowerCase()
          )
        : undefined;

      const fileKey = `${rawName.toLowerCase()}|${rawPack.toLowerCase()}|${batchNumNormalized.toLowerCase()}`;
      const isDuplicateInFile = seenKeysInFile.has(fileKey);
      if (rawName) seenKeysInFile.add(fileKey);
      if (isDuplicateInFile) warnings.push('Duplicate row in file');

      return {
        rowIndex: idx + 1,
        productCode: rawCode,
        productName: rawName,
        brandName: rawBrand,
        genericName: rawGeneric,
        composition: rawComp,
        manufacturer: rawMfg,
        category: rawCat,
        packSize: rawPack,
        hsnCode: rawHsn,
        imageUrl: rawImageUrl || matchedProduct?.imageUrl || '',
        batchNumber: batchNumNormalized,
        expiryRaw: rawExp,
        expiryIso: parsedExp.expiryDate,
        expiryDisplay: parsedExp.expiryDisplay,
        mrp,
        wholesaleRate,
        purchaseRate,
        discountPercent: Math.min(100, discountPercent),
        schemeDetails: rawScheme,
        dealRateAdjustable,
        availableQty,
        matchedProductId: matchedProduct?.id || null,
        matchedBatchId: matchedBatch?.id || null,
        isDuplicateInFile,
        errors,
        warnings,
      };
    });
  }, [rawRows, mapping, existingProducts, existingBatches]);

  const validationStats = useMemo(() => {
    let errorCount = 0;
    let warningCount = 0;
    let existingCount = 0;
    let newCount = 0;
    let duplicateInFileCount = 0;
    for (const r of previewRows) {
      if (r.errors.length > 0) errorCount += 1;
      if (r.warnings.length > 0) warningCount += 1;
      if (r.matchedProductId) existingCount += 1;
      else if (r.errors.length === 0) newCount += 1;
      if (r.isDuplicateInFile) duplicateInFileCount += 1;
    }
    return {
      errorCount,
      warningCount,
      existingCount,
      newCount,
      duplicateInFileCount,
    };
  }, [previewRows]);

  const handleExecuteImport = async () => {
    if (previewRows.length === 0 || !user) return;
    setImporting(true);
    let createdProducts = 0;
    let updatedProducts = 0;
    let addedBatches = 0;
    let updatedBatches = 0;
    let skippedRows = 0;

    try {
      const companyByName: Record<string, string> = {};
      for (const c of companies) {
        companyByName[c.name.toLowerCase()] = c.id;
      }

      // Process in chunks to respect Firestore 500-op writeBatch limit
      const validRows = previewRows.filter((r) => {
        if (r.errors.length > 0 || r.isDuplicateInFile) {
          skippedRows += 1;
          return false;
        }
        if (r.matchedProductId && conflictMode === 'skip') {
          skippedRows += 1;
          return false;
        }
        return true;
      });

      const chunkSize = 100;
      for (let i = 0; i < validRows.length; i += chunkSize) {
        const chunk = validRows.slice(i, i + chunkSize);
        const wb = writeBatch(db);

        for (const r of chunk) {
          const compKey = r.manufacturer.toLowerCase();
          let companyId = companyByName[compKey];
          if (!companyId) {
            companyId = slugId('comp', r.manufacturer);
            companyByName[compKey] = companyId;
            wb.set(doc(db, 'companies', companyId), {
              id: companyId,
              name: r.manufacturer.slice(0, 120),
              shortCode: r.manufacturer.slice(0, 8).toUpperCase(),
              active: true,
              updatedAt: serverTimestamp(),
            });
          }

          const productId =
            r.matchedProductId ||
            slugId('prod', `${r.productName}_${r.packSize}`);

          if (r.matchedProductId) {
            updatedProducts += 1;
          } else {
            createdProducts += 1;
          }

          wb.set(doc(db, 'products', productId), {
            id: productId,
            productCode: r.productCode.slice(0, 64),
            name: r.productName.slice(0, 180),
            brandName: r.brandName.slice(0, 140),
            genericName: r.genericName.slice(0, 200),
            composition: r.composition.slice(0, 300),
            companyId,
            manufacturer: r.manufacturer.slice(0, 120),
            category: r.category.slice(0, 60),
            packSize: r.packSize.slice(0, 40),
            hsnCode: r.hsnCode.slice(0, 20),
            imageUrl: r.imageUrl.slice(0, 150000),
            minStockLevel: 5,
            confirmAvailabilityOnly: false,
            updatedAt: serverTimestamp(),
          });

          const batchId =
            r.matchedBatchId || slugId('bat', `${productId}_${r.batchNumber}`);
          if (r.matchedBatchId) {
            updatedBatches += 1;
          } else {
            addedBatches += 1;
          }

          wb.set(doc(db, 'batches', batchId), {
            id: batchId,
            productId,
            batchNumber: r.batchNumber.slice(0, 64),
            expiryDate: r.expiryIso,
            expiryDisplay: r.expiryDisplay,
            mrp: r.mrp,
            wholesaleRate: r.wholesaleRate,
            discountPercent: r.discountPercent,
            schemeDetails: r.schemeDetails.slice(0, 80),
            dealRateAdjustable: r.dealRateAdjustable,
            availableQty: r.availableQty,
            availabilityOverride: 'AUTO',
            isActive: true,
            updatedAt: serverTimestamp(),
          });

          wb.set(doc(db, 'admin_batch_costs', batchId), {
            batchId,
            productId,
            purchaseRate: r.purchaseRate,
            updatedAt: serverTimestamp(),
          });
        }

        try {
          await wb.commit();
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, 'products');
        }
      }

      const summary = {
        totalRows: previewRows.length,
        createdProducts,
        updatedProducts,
        addedBatches,
        updatedBatches,
        skippedRows,
      };
      setImportSummary(summary);

      await recordImportLog({
        id: `imp_${Date.now()}`,
        adminUid: user.uid,
        fileName: fileName || 'upload.xlsx',
        ...summary,
      });
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Step 1: Upload & Template */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-950 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5" />
            <span>Flexible Excel &amp; CSV Importer</span>
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-slate-600">
            Upload `.xlsx`, `.xls`, or `.csv` from desktop or mobile. Preview, map columns, catch missing rates/expiry, and update existing stock without duplicates.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleDownloadSampleTemplate}
            className="inline-flex items-center gap-1.5 min-h-[42px] px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-800 hover:bg-slate-50 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Sample Template</span>
          </button>

          <label className="inline-flex items-center gap-2 min-h-[42px] px-4 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer">
            <Upload className="w-4 h-4" />
            <span>{fileName ? 'Upload Another File' : 'Choose Excel / CSV'}</span>
            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={handleFileUpload}
              className="sr-only"
            />
          </label>
        </div>
      </div>

      {fileError && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-xs font-semibold text-[#B91C1C]">
          {fileError}
        </div>
      )}

      {importSummary && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5">
          <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
            <CheckCircle2 className="w-5 h-5" />
            <span>Import Completed Successfully ({fileName})</span>
          </div>
          <div className="mt-3 grid grid-cols-2 sm:grid-cols-6 gap-3 text-xs">
            <div>
              <div className="text-emerald-700">Total Rows</div>
              <div className="font-mono font-bold text-base tabular-nums">
                {importSummary.totalRows}
              </div>
            </div>
            <div>
              <div className="text-emerald-700">New Products</div>
              <div className="font-mono font-bold text-base tabular-nums">
                {importSummary.createdProducts}
              </div>
            </div>
            <div>
              <div className="text-emerald-700">Updated Products</div>
              <div className="font-mono font-bold text-base tabular-nums">
                {importSummary.updatedProducts}
              </div>
            </div>
            <div>
              <div className="text-emerald-700">Added Batches</div>
              <div className="font-mono font-bold text-base tabular-nums">
                {importSummary.addedBatches}
              </div>
            </div>
            <div>
              <div className="text-emerald-700">Updated Batches</div>
              <div className="font-mono font-bold text-base tabular-nums">
                {importSummary.updatedBatches}
              </div>
            </div>
            <div>
              <div className="text-emerald-700">Skipped / Errors</div>
              <div className="font-mono font-bold text-base tabular-nums">
                {importSummary.skippedRows}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 2: Column Mapping & Validation Preview */}
      {headers.length > 0 && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-950">
                  1. Map Excel Columns ({fileName} · {rawRows.length} rows)
                </h3>
                <p className="text-xs text-slate-500">
                  Auto-detected headings below. Adjust any column mapping before importing.
                </p>
              </div>

              {sheetNames.length > 1 && workbook && (
                <select
                  value={activeSheet}
                  onChange={(e) => loadSheet(workbook, e.target.value)}
                  className="min-h-[38px] px-3 py-1 rounded-lg border border-slate-300 text-xs font-semibold bg-white"
                >
                  {sheetNames.map((s) => (
                    <option key={s} value={s}>
                      Sheet: {s}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {headers.map((col) => (
                <div
                  key={col}
                  className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between gap-2"
                >
                  <span
                    className="text-xs font-mono font-semibold text-slate-800 truncate"
                    title={col}
                  >
                    {col}
                  </span>
                  <select
                    value={mapping[col] || 'ignore'}
                    onChange={(e) =>
                      setMapping((prev) => ({
                        ...prev,
                        [col]: e.target.value as AppFieldKey,
                      }))
                    }
                    className="min-h-[34px] px-2 py-1 rounded-md border border-slate-300 bg-white text-xs text-slate-900 max-w-[175px]"
                  >
                    {APP_FIELD_OPTIONS.map((opt) => (
                      <option key={opt.key} value={opt.key}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>

          {/* Pre-Import Validation & Conflict Policy */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-950">
                  2. Pre-Import Preview &amp; Conflict Handling
                </h3>
                <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 tabular-nums">
                  <span>
                    New: <strong className="text-slate-950">{validationStats.newCount}</strong>
                  </span>
                  <span>
                    Existing Match:{' '}
                    <strong className="text-slate-950">
                      {validationStats.existingCount}
                    </strong>
                  </span>
                  <span>
                    File Duplicates:{' '}
                    <strong className="text-slate-950">
                      {validationStats.duplicateInFileCount}
                    </strong>
                  </span>
                  <span className="text-amber-700 font-semibold">
                    Warnings: {validationStats.warningCount}
                  </span>
                  <span className="text-[#B91C1C] font-semibold">
                    Blocking Errors: {validationStats.errorCount}
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <select
                  value={conflictMode}
                  onChange={(e) =>
                    setConflictMode(e.target.value as 'update' | 'skip')
                  }
                  className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold bg-white"
                >
                  <option value="update">
                    Update existing products &amp; batches (no duplicates)
                  </option>
                  <option value="skip">
                    Skip existing products (add new only)
                  </option>
                </select>

                <button
                  type="button"
                  disabled={importing || previewRows.length === 0}
                  onClick={handleExecuteImport}
                  className="min-h-[42px] px-5 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 disabled:opacity-50 cursor-pointer whitespace-nowrap"
                >
                  {importing
                    ? 'Importing to Database...'
                    : `Confirm & Import (${previewRows.length - validationStats.errorCount - validationStats.duplicateInFileCount} valid rows)`}
                </button>
              </div>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-96">
              <table className="w-full text-left border-collapse text-xs min-w-[840px]">
                <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <tr>
                    <th className="py-2.5 px-3">#</th>
                    <th className="py-2.5 px-3">Action</th>
                    <th className="py-2.5 px-3">Product Name</th>
                    <th className="py-2.5 px-3">Company / Pack</th>
                    <th className="py-2.5 px-3">Batch / Exp</th>
                    <th className="py-2.5 px-3 text-right">Wholesale</th>
                    <th className="py-2.5 px-3 text-right">MRP</th>
                    <th className="py-2.5 px-3 text-right">Qty</th>
                    <th className="py-2.5 px-3">Validation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {previewRows.slice(0, 100).map((r) => (
                    <tr
                      key={r.rowIndex}
                      className={
                        r.errors.length > 0
                          ? 'bg-red-50/70'
                          : r.warnings.length > 0
                          ? 'bg-amber-50/50'
                          : ''
                      }
                    >
                      <td className="py-2 px-3 font-mono text-slate-500">
                        {r.rowIndex}
                      </td>
                      <td className="py-2 px-3 font-semibold">
                        {r.errors.length > 0 || r.isDuplicateInFile ? (
                          <span className="text-[#B91C1C]">Skip</span>
                        ) : r.matchedProductId ? (
                          <span className="text-slate-900 bg-[#CBB3E8]/50 px-1.5 py-0.5 rounded">
                            {conflictMode === 'update' ? 'Update' : 'Skip Existing'}
                          </span>
                        ) : (
                          <span className="text-emerald-800 bg-[#D4FF3F]/50 px-1.5 py-0.5 rounded">
                            Create
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3 font-bold text-slate-900">
                        {r.productName || <span className="text-[#B91C1C]">Missing</span>}
                      </td>
                      <td className="py-2 px-3 text-slate-600">
                        {r.manufacturer} · {r.packSize}
                      </td>
                      <td className="py-2 px-3 font-mono text-slate-800">
                        {r.batchNumber} · {r.expiryDisplay}
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums">
                        {r.wholesaleRate.toFixed(2)}
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums">
                        {r.mrp.toFixed(2)}
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums">
                        {r.availableQty}
                      </td>
                      <td className="py-2 px-3">
                        {r.errors.length > 0 ? (
                          <span className="inline-flex items-center gap-1 text-[#B91C1C] font-semibold">
                            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                            <span>{r.errors.join('; ')}</span>
                          </span>
                        ) : r.warnings.length > 0 ? (
                          <span className="text-amber-800 font-medium">
                            {r.warnings.join('; ')}
                          </span>
                        ) : (
                          <span className="text-emerald-700 font-medium">Ready</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Import History */}
      {importLogs.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h3 className="text-sm font-bold text-slate-950 mb-3">
            Recent Excel / CSV Imports
          </h3>
          <div className="divide-y divide-slate-100 text-xs">
            {importLogs.slice(0, 6).map((log) => (
              <div
                key={log.id}
                className="py-2.5 flex flex-wrap items-center justify-between gap-3"
              >
                <div>
                  <span className="font-mono font-bold text-slate-900">
                    {log.fileName}
                  </span>
                  <span className="ml-2 text-slate-500 font-mono">
                    {formatDateTimeIST(log.createdAt)}
                  </span>
                </div>
                <div className="font-mono text-slate-700 tabular-nums">
                  +{log.createdProducts} new · {log.updatedProducts} updated ·{' '}
                  {log.addedBatches + log.updatedBatches} batches ·{' '}
                  {log.skippedRows} skipped
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
