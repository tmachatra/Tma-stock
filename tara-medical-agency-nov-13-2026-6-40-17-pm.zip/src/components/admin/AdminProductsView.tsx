import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  Download,
  Edit3,
  ImagePlus,
  Plus,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  compressProductImageFile,
  isValidProductImageUrl,
} from '../../lib/imageUtils';
import {
  formatDateTimeIST,
  formatINR,
  isDealRateAdjustable,
  parseExpiryToIso,
  slugId,
} from '../../lib/pharmaUtils';
import {
  bulkUpdateBatches,
  deleteProductAndBatches,
  upsertBatchWithCost,
  upsertCompany,
  upsertProduct,
} from '../../services/catalogService';
import type {
  AdminBatchCost,
  MedicineBatch,
  MedicineProduct,
  PharmaCompany,
  ProductWithBatches,
} from '../../types/pharma';
import { StatusTag } from '../StatusTag';

interface AdminProductsViewProps {
  products: ProductWithBatches[];
  companies: PharmaCompany[];
  allBatches: MedicineBatch[];
  batchCosts: Record<string, AdminBatchCost>;
}

export const AdminProductsView: React.FC<AdminProductsViewProps> = ({
  products,
  companies,
  allBatches,
  batchCosts,
}) => {
  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState<
    'ALL' | 'MISSING_INFO' | 'LOW_OUT' | 'CONFIRM'
  >('ALL');
  const [companyFilter, setCompanyFilter] = useState('ALL');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Modal state for Add / Edit Product
  const [editingProduct, setEditingProduct] = useState<MedicineProduct | null>(
    null
  );
  const [showProductModal, setShowProductModal] = useState(false);

  // Form fields
  const [fName, setFName] = useState('');
  const [fBrand, setFBrand] = useState('');
  const [fCode, setFCode] = useState('');
  const [fGeneric, setFGeneric] = useState('');
  const [fComposition, setFComposition] = useState('');
  const [fCompanyName, setFCompanyName] = useState('');
  const [fCategory, setFCategory] = useState('Tablets');
  const [fPack, setFPack] = useState('1*10');
  const [fHsn, setFHsn] = useState('');
  const [fMinStock, setFMinStock] = useState('5');
  const [fConfirmOnly, setFConfirmOnly] = useState(false);
  const [fImageUrl, setFImageUrl] = useState('');
  const [imageUploading, setImageUploading] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);

  // Initial batch fields (when creating new product)
  const [fBatchNo, setFBatchNo] = useState('');
  const [fExpiry, setFExpiry] = useState('');
  const [fMrp, setFMrp] = useState('');
  const [fWholesale, setFWholesale] = useState('');
  const [fPurchase, setFPurchase] = useState('');
  const [fDiscount, setFDiscount] = useState('8');
  const [fScheme, setFScheme] = useState('');
  const [fDealAdjustable, setFDealAdjustable] = useState(false);
  const [fQty, setFQty] = useState('10');

  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Bulk Update state
  const [bulkRatePct, setBulkRatePct] = useState('');
  const [bulkDiscount, setBulkDiscount] = useState('');
  const [bulkScheme, setBulkScheme] = useState('');
  const [bulkDealAdjust, setBulkDealAdjust] = useState<'' | 'yes' | 'no'>('');
  const [bulkStockExact, setBulkStockExact] = useState('');
  const [bulkApplying, setBulkApplying] = useState(false);

  const filtered = useMemo(() => {
    return products.filter((item) => {
      if (filterMode === 'MISSING_INFO' && !item.hasMissingInfo) return false;
      if (
        filterMode === 'LOW_OUT' &&
        item.availabilityStatus !== 'LOW STOCK' &&
        item.availabilityStatus !== 'OUT OF STOCK'
      ) {
        return false;
      }
      if (
        filterMode === 'CONFIRM' &&
        item.availabilityStatus !== 'CONFIRM AVAILABILITY'
      ) {
        return false;
      }
      if (
        companyFilter !== 'ALL' &&
        item.product.companyId !== companyFilter
      ) {
        return false;
      }
      if (search.trim()) {
        const q = search.toLowerCase();
        const p = item.product;
        return (
          p.name.toLowerCase().includes(q) ||
          p.brandName.toLowerCase().includes(q) ||
          p.genericName.toLowerCase().includes(q) ||
          p.manufacturer.toLowerCase().includes(q) ||
          p.productCode.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [products, filterMode, companyFilter, search]);

  const openAddModal = () => {
    setEditingProduct(null);
    setFName('');
    setFBrand('');
    setFCode('');
    setFGeneric('');
    setFComposition('');
    setFCompanyName(companies[0]?.name || '');
    setFCategory('Tablets');
    setFPack('1*10');
    setFHsn('');
    setFMinStock('5');
    setFConfirmOnly(false);
    setFImageUrl('');
    setImageError(null);
    setFBatchNo('');
    setFExpiry('');
    setFMrp('');
    setFWholesale('');
    setFPurchase('');
    setFDiscount('8');
    setFScheme('');
    setFDealAdjustable(false);
    setFQty('10');
    setShowProductModal(true);
  };

  const openEditModal = (p: MedicineProduct) => {
    setEditingProduct(p);
    setFName(p.name);
    setFBrand(p.brandName);
    setFCode(p.productCode);
    setFGeneric(p.genericName);
    setFComposition(p.composition);
    setFCompanyName(p.manufacturer);
    setFCategory(p.category);
    setFPack(p.packSize);
    setFHsn(p.hsnCode);
    setFMinStock(String(p.minStockLevel));
    setFConfirmOnly(p.confirmAvailabilityOnly);
    setFImageUrl(p.imageUrl || '');
    setImageError(null);
    setShowProductModal(true);
  };

  const handleImageFileSelect = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setImageError(null);
    setImageUploading(true);
    try {
      const compressed = await compressProductImageFile(file);
      setFImageUrl(compressed);
    } catch (err) {
      setImageError(
        err instanceof Error ? err.message : 'Could not process image file.'
      );
    } finally {
      setImageUploading(false);
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fName.trim() || !fCompanyName.trim()) return;
    setSaving(true);
    setFeedback(null);
    try {
      const existingComp = companies.find(
        (c) => c.name.toLowerCase() === fCompanyName.trim().toLowerCase()
      );
      const companyId = existingComp
        ? existingComp.id
        : await upsertCompany({
            name: fCompanyName.trim(),
            shortCode: fCompanyName.trim().slice(0, 8).toUpperCase(),
            active: true,
          });

      if (!isValidProductImageUrl(fImageUrl)) {
        setImageError(
          'Image URL must start with https://, http://, or be an uploaded photo within size limits.'
        );
        setSaving(false);
        return;
      }

      const productId =
        editingProduct?.id || slugId('prod', `${fName}_${fPack}_${Date.now().toString(36)}`);

      await upsertProduct({
        id: productId,
        productCode: fCode.trim(),
        name: fName.trim(),
        brandName: fBrand.trim() || fName.trim(),
        genericName: fGeneric.trim(),
        composition: fComposition.trim(),
        companyId,
        manufacturer: fCompanyName.trim(),
        category: fCategory.trim() || 'Tablets',
        packSize: fPack.trim() || '1*10',
        hsnCode: fHsn.trim(),
        minStockLevel: Math.max(0, Number(fMinStock) || 0),
        confirmAvailabilityOnly: fConfirmOnly,
        imageUrl: fImageUrl.trim(),
      });

      if (!editingProduct && fBatchNo.trim()) {
        const parsedExp = parseExpiryToIso(fExpiry);
        const batchId = slugId('bat', `${productId}_${fBatchNo.trim()}`);
        await upsertBatchWithCost(
          {
            id: batchId,
            productId,
            batchNumber: fBatchNo.trim(),
            expiryDate: parsedExp.expiryDate,
            expiryDisplay: parsedExp.expiryDisplay,
            mrp: Math.max(0, Number(fMrp) || 0),
            wholesaleRate: Math.max(0, Number(fWholesale) || 0),
            discountPercent: Math.min(100, Math.max(0, Number(fDiscount) || 0)),
            schemeDetails: fScheme.trim(),
            dealRateAdjustable: fScheme.trim() ? fDealAdjustable : false,
            availableQty: Math.max(0, Number(fQty) || 0),
            availabilityOverride: 'AUTO',
            isActive: true,
          },
          Number(fPurchase) || 0
        );
      }

      setShowProductModal(false);
      setFeedback(
        editingProduct
          ? `Updated ${fName.trim()}.`
          : `Added ${fName.trim()} to catalog.`
      );
    } catch (err) {
      setFeedback(
        err instanceof Error ? err.message : 'Failed to save product.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (item: ProductWithBatches) => {
    const batchIds = allBatches
      .filter((b) => b.productId === item.product.id)
      .map((b) => b.id);
    await deleteProductAndBatches(item.product.id, batchIds);
    setSelectedIds((prev) => prev.filter((id) => id !== item.product.id));
    setFeedback(`Deleted ${item.product.name} and ${batchIds.length} batch(es).`);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleSelectAllFiltered = () => {
    const filteredIds = filtered.map((f) => f.product.id);
    const allSelected =
      filteredIds.length > 0 &&
      filteredIds.every((id) => selectedIds.includes(id));
    if (allSelected) {
      setSelectedIds((prev) => prev.filter((id) => !filteredIds.includes(id)));
    } else {
      setSelectedIds(Array.from(new Set([...selectedIds, ...filteredIds])));
    }
  };

  const handleBulkApply = async () => {
    if (selectedIds.length === 0) return;
    const targetBatches = allBatches.filter((b) =>
      selectedIds.includes(b.productId)
    );
    if (targetBatches.length === 0) return;

    setBulkApplying(true);
    try {
      const patch: Parameters<typeof bulkUpdateBatches>[1] = {};
      if (bulkRatePct.trim() !== '') {
        patch.rateDeltaPercent = Number(bulkRatePct);
      }
      if (bulkDiscount.trim() !== '') {
        patch.setDiscountPercent = Number(bulkDiscount);
      }
      if (bulkScheme.trim() !== '') {
        patch.setSchemeDetails = bulkScheme.trim() === '-' ? '' : bulkScheme.trim();
      }
      if (bulkDealAdjust === 'yes') {
        patch.setDealRateAdjustable = true;
      } else if (bulkDealAdjust === 'no') {
        patch.setDealRateAdjustable = false;
      }
      if (bulkStockExact.trim() !== '') {
        patch.setStockExact = Number(bulkStockExact);
      }

      const count = await bulkUpdateBatches(targetBatches, patch);
      setFeedback(`Updated ${count} batch(es) across ${selectedIds.length} selected products.`);
      setBulkRatePct('');
      setBulkDiscount('');
      setBulkScheme('');
      setBulkDealAdjust('');
      setBulkStockExact('');
      setSelectedIds([]);
    } finally {
      setBulkApplying(false);
    }
  };

  const handleExportExcel = () => {
    const rows = products.flatMap((item) => {
      if (item.batches.length === 0) {
        return [
          {
            'Product Code': item.product.productCode,
            'Product Name': item.product.name,
            Brand: item.product.brandName,
            'Generic Salt': item.product.genericName,
            Composition: item.product.composition,
            Manufacturer: item.product.manufacturer,
            Category: item.product.category,
            Pack: item.product.packSize,
            'HSN Code': item.product.hsnCode,
            'Image URL':
              item.product.imageUrl && !item.product.imageUrl.startsWith('data:')
                ? item.product.imageUrl
                : '',
            'Batch No.': '',
            'Exp Date': '',
            MRP: 0,
            'Wholesale Rate': 0,
            'Purchase Rate': 0,
            'Disc %': 0,
            Scheme: '',
            'Deal Rate Adjustable': 'No',
            Quantity: 0,
          },
        ];
      }
      return item.batches.map((b) => ({
        'Product Code': item.product.productCode,
        'Product Name': item.product.name,
        Brand: item.product.brandName,
        'Generic Salt': item.product.genericName,
        Composition: item.product.composition,
        Manufacturer: item.product.manufacturer,
        Category: item.product.category,
        Pack: item.product.packSize,
        'HSN Code': item.product.hsnCode,
        'Image URL':
          item.product.imageUrl && !item.product.imageUrl.startsWith('data:')
            ? item.product.imageUrl
            : '',
        'Batch No.': b.batchNumber,
        'Exp Date': b.expiryDisplay,
        MRP: b.mrp,
        'Wholesale Rate': b.wholesaleRate,
        'Purchase Rate': batchCosts[b.id]?.purchaseRate ?? 0,
        'Disc %': b.discountPercent,
        Scheme: b.schemeDetails,
        'Deal Rate Adjustable': isDealRateAdjustable(b, item.product) ? 'Yes' : 'No',
        Quantity: b.availableQty,
      }));
    });

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'TaraMedicalCatalog');
    XLSX.writeFile(
      wb,
      `Tara_Medical_Catalog_${new Date().toISOString().slice(0, 10)}.xlsx`
    );
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search products, salt, code, company..."
              className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 text-sm text-slate-900"
            />
          </div>

          <select
            value={filterMode}
            onChange={(e) =>
              setFilterMode(
                e.target.value as 'ALL' | 'MISSING_INFO' | 'LOW_OUT' | 'CONFIRM'
              )
            }
            className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-800 bg-white"
          >
            <option value="ALL">All Products ({products.length})</option>
            <option value="MISSING_INFO">
              Missing Info ({products.filter((p) => p.hasMissingInfo).length})
            </option>
            <option value="LOW_OUT">Low / Out of Stock</option>
            <option value="CONFIRM">Confirm Availability</option>
          </select>

          <select
            value={companyFilter}
            onChange={(e) => setCompanyFilter(e.target.value)}
            className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-800 bg-white"
          >
            <option value="ALL">All Companies</option>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-800 hover:bg-slate-50 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Excel</span>
          </button>

          <button
            type="button"
            onClick={openAddModal}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-1.5 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Product</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="px-4 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-medium flex items-center justify-between">
          <span>{feedback}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="p-1 hover:bg-slate-800 rounded cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Bulk Update Bar */}
      {selectedIds.length > 0 && (
        <div className="bg-[#CBB3E8]/35 border border-[#CBB3E8] rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-950">
              Bulk Update {selectedIds.length} Selected Product(s)
            </span>
            <button
              type="button"
              onClick={() => setSelectedIds([])}
              className="text-xs font-semibold text-slate-700 hover:underline cursor-pointer"
            >
              Clear selection
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5">
            <input
              type="number"
              step="0.5"
              value={bulkRatePct}
              onChange={(e) => setBulkRatePct(e.target.value)}
              placeholder="Rate +/- %"
              className="min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono"
            />
            <input
              type="number"
              step="0.5"
              value={bulkDiscount}
              onChange={(e) => setBulkDiscount(e.target.value)}
              placeholder="Set Disc %"
              className="min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono"
            />
            <input
              type="text"
              value={bulkScheme}
              onChange={(e) => setBulkScheme(e.target.value)}
              placeholder="Scheme (or - to clear)"
              className="min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono"
            />
            <select
              value={bulkDealAdjust}
              onChange={(e) =>
                setBulkDealAdjust(e.target.value as '' | 'yes' | 'no')
              }
              className="min-h-[38px] px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium"
            >
              <option value="">Deal Rate Type (Keep)</option>
              <option value="yes">Adjustable in Rate</option>
              <option value="no">Not Adjustable in Rate</option>
            </select>
            <input
              type="number"
              value={bulkStockExact}
              onChange={(e) => setBulkStockExact(e.target.value)}
              placeholder="Set Stock Qty"
              className="min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono"
            />
            <button
              type="button"
              disabled={bulkApplying}
              onClick={handleBulkApply}
              className="min-h-[38px] px-4 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 cursor-pointer"
            >
              {bulkApplying ? 'Applying...' : 'Apply Bulk Update'}
            </button>
          </div>
        </div>
      )}

      {/* Products Data Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs min-w-[920px]">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
              <th className="py-3 px-3 w-10">
                <input
                  type="checkbox"
                  checked={
                    filtered.length > 0 &&
                    filtered.every((f) => selectedIds.includes(f.product.id))
                  }
                  onChange={toggleSelectAllFiltered}
                  aria-label="Select all filtered products"
                />
              </th>
              <th className="py-3 px-3">Product &amp; Salt</th>
              <th className="py-3 px-3">Company / Pack</th>
              <th className="py-3 px-3 text-right">Purchase (Admin)</th>
              <th className="py-3 px-3 text-right">Wholesale</th>
              <th className="py-3 px-3 text-right">MRP / Disc</th>
              <th className="py-3 px-3">Earliest Exp</th>
              <th className="py-3 px-3 text-right">Stock</th>
              <th className="py-3 px-3">Status</th>
              <th className="py-3 px-3">Updated</th>
              <th className="py-3 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map((item) => {
              const b = item.earliestValidBatch;
              const pCost = b ? batchCosts[b.id]?.purchaseRate : undefined;
              return (
                <tr key={item.product.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-3">
                    <input
                      type="checkbox"
                      checked={selectedIds.includes(item.product.id)}
                      onChange={() => toggleSelect(item.product.id)}
                      aria-label={`Select ${item.product.name}`}
                    />
                  </td>
                  <td className="py-3 px-3 max-w-[260px]">
                    <div className="flex items-start gap-2.5">
                      {item.product.imageUrl ? (
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.name}
                          className="w-10 h-10 rounded-lg border border-slate-200 bg-white object-contain shrink-0"
                        />
                      ) : (
                        <div
                          className="w-10 h-10 rounded-lg border border-dashed border-slate-200 bg-slate-50 flex items-center justify-center text-slate-300 shrink-0"
                          title="No image uploaded"
                        >
                          <ImagePlus className="w-4 h-4" />
                        </div>
                      )}
                      <div className="min-w-0">
                        <div className="font-bold text-slate-950">
                          {item.product.name}
                        </div>
                        <div className="text-slate-600 truncate">
                          {item.product.genericName || 'Missing salt'}
                        </div>
                        {item.hasMissingInfo && (
                          <div className="mt-1 inline-flex items-center gap-1 text-[11px] font-semibold text-[#B91C1C]">
                            <AlertCircle className="w-3 h-3 shrink-0" />
                            <span>{item.missingReasons.join(', ')}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-medium text-slate-800">
                      {item.product.manufacturer}
                    </div>
                    <div className="font-mono text-slate-500">
                      {item.product.packSize} · {item.batches.length} batch
                    </div>
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                    {typeof pCost === 'number' ? formatINR(pCost) : '—'}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-slate-950">
                    {item.effectiveWholesaleRate > 0
                      ? formatINR(item.effectiveWholesaleRate)
                      : '—'}
                    {item.schemeDetails && (
                      <div className="text-[10px] font-semibold text-slate-700">
                        Deal: {item.schemeDetails}{' '}
                        <span
                          className={
                            item.dealRateAdjustable
                              ? 'text-emerald-700'
                              : 'text-[#B91C1C]'
                          }
                        >
                          ({item.dealRateAdjustable ? 'Adj. in rate' : 'Not adj.'})
                        </span>
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-600">
                    {item.mrp > 0 ? formatINR(item.mrp) : '—'}
                    <div className="text-[10px]">{item.discountPercent}%</div>
                  </td>
                  <td className="py-3 px-3 font-mono font-semibold tabular-nums text-slate-900">
                    {item.earliestExpiryDisplay}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                    {item.totalAvailableQty}
                  </td>
                  <td className="py-3 px-3">
                    <StatusTag status={item.availabilityStatus} compact />
                  </td>
                  <td className="py-3 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                    {formatDateTimeIST(item.latestUpdatedAt)}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => openEditModal(item.product)}
                        className="p-2 rounded-md text-slate-600 hover:bg-slate-200 hover:text-slate-950 cursor-pointer"
                        title="Edit product"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(item)}
                        className="p-2 rounded-md text-slate-500 hover:bg-red-50 hover:text-[#E34234] cursor-pointer"
                        title="Delete product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Add / Edit Product Modal */}
      {showProductModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white rounded-2xl border border-slate-200 p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="font-display text-lg font-bold text-slate-950">
                {editingProduct ? 'Edit Medicine Product' : 'Add New Medicine & Initial Batch'}
              </h2>
              <button
                type="button"
                onClick={() => setShowProductModal(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="mt-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Product Name *
                  </label>
                  <input
                    required
                    value={fName}
                    onChange={(e) => setFName(e.target.value)}
                    placeholder="e.g. MONOCEF INJ 1GM"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Brand Name
                  </label>
                  <input
                    value={fBrand}
                    onChange={(e) => setFBrand(e.target.value)}
                    placeholder="e.g. Monocef"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Manufacturer / Company *
                  </label>
                  <input
                    required
                    list="admin-company-list"
                    value={fCompanyName}
                    onChange={(e) => setFCompanyName(e.target.value)}
                    placeholder="e.g. Aristo Pharmaceuticals"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                  <datalist id="admin-company-list">
                    {companies.map((c) => (
                      <option key={c.id} value={c.name} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Generic Salt Name
                  </label>
                  <input
                    value={fGeneric}
                    onChange={(e) => setFGeneric(e.target.value)}
                    placeholder="e.g. Ceftriaxone"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Composition
                  </label>
                  <input
                    value={fComposition}
                    onChange={(e) => setFComposition(e.target.value)}
                    placeholder="e.g. Ceftriaxone Sodium IP 1000 mg"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Pack Size
                  </label>
                  <input
                    value={fPack}
                    onChange={(e) => setFPack(e.target.value)}
                    placeholder="1*10, 100ML, 1VIAL"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={fCategory}
                    onChange={(e) => setFCategory(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm bg-white"
                  >
                    <option>Tablets</option>
                    <option>Capsules</option>
                    <option>Syrups &amp; Suspensions</option>
                    <option>Injections</option>
                    <option>Ointments &amp; Creams</option>
                    <option>Drops &amp; Sprays</option>
                    <option>Powders &amp; ORS</option>
                    <option>Ointments &amp; Oral</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Product Code
                  </label>
                  <input
                    value={fCode}
                    onChange={(e) => setFCode(e.target.value)}
                    placeholder="e.g. ARS-MNC-1G"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    HSN Code (Optional)
                  </label>
                  <input
                    value={fHsn}
                    onChange={(e) => setFHsn(e.target.value)}
                    placeholder="e.g. 30042019"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Min Stock Level (Low Stock Threshold)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={fMinStock}
                    onChange={(e) => setFMinStock(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div className="flex items-center gap-2 pt-5">
                  <input
                    id="confirmOnlyCheck"
                    type="checkbox"
                    checked={fConfirmOnly}
                    onChange={(e) => setFConfirmOnly(e.target.checked)}
                  />
                  <label
                    htmlFor="confirmOnlyCheck"
                    className="text-xs font-semibold text-slate-800"
                  >
                    Mark as &ldquo;CONFIRM AVAILABILITY&rdquo;
                  </label>
                </div>

                {/* Product Pack Image Uploader / URL */}
                <div className="sm:col-span-2 pt-3 border-t border-slate-200 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                      <ImagePlus className="w-3.5 h-3.5 text-slate-600" />
                      <span>Product Pack Photo (Optional — helps retailers identify medicine)</span>
                    </label>
                    {fImageUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          setFImageUrl('');
                          setImageError(null);
                        }}
                        className="text-[11px] font-semibold text-[#B91C1C] hover:underline cursor-pointer"
                      >
                        Remove Photo
                      </button>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                    <div className="w-20 h-20 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                      {fImageUrl ? (
                        <img
                          src={fImageUrl}
                          alt={fName || 'Product preview'}
                          className="w-full h-full object-contain bg-white"
                        />
                      ) : (
                        <ImagePlus className="w-6 h-6 text-slate-300" />
                      )}
                    </div>

                    <div className="flex-1 w-full space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <label className="inline-flex items-center gap-1.5 min-h-[38px] px-3.5 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 cursor-pointer">
                          <Upload className="w-3.5 h-3.5 text-[#D4FF3F]" />
                          <span>
                            {imageUploading
                              ? 'Optimizing Photo...'
                              : 'Upload / Take Photo'}
                          </span>
                          <input
                            type="file"
                            accept="image/*"
                            disabled={imageUploading}
                            onChange={handleImageFileSelect}
                            className="sr-only"
                          />
                        </label>
                        <span className="text-[11px] text-slate-500">
                          Auto-compressed for fast loading on mobile
                        </span>
                      </div>

                      <input
                        type="text"
                        value={fImageUrl.startsWith('data:image/') ? '' : fImageUrl}
                        onChange={(e) => {
                          setFImageUrl(e.target.value);
                          setImageError(null);
                        }}
                        placeholder={
                          fImageUrl.startsWith('data:image/')
                            ? 'Uploaded photo attached (or paste an https:// image URL to replace)'
                            : 'Or paste product image URL (https://...)'
                        }
                        className="w-full min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-900"
                      />
                    </div>
                  </div>

                  {imageError && (
                    <div className="text-xs font-semibold text-[#B91C1C]">
                      {imageError}
                    </div>
                  )}
                </div>
              </div>

              {!editingProduct && (
                <div className="pt-4 border-t border-slate-200 space-y-3">
                  <h3 className="text-xs font-bold text-slate-900">
                    Initial Batch Details
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Batch Number *
                      </label>
                      <input
                        required
                        value={fBatchNo}
                        onChange={(e) => setFBatchNo(e.target.value)}
                        placeholder="BPG261906"
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Expiry (MM/YY)
                      </label>
                      <input
                        value={fExpiry}
                        onChange={(e) => setFExpiry(e.target.value)}
                        placeholder="12/28"
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        MRP (₹)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={fMrp}
                        onChange={(e) => setFMrp(e.target.value)}
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Wholesale Rate (₹)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={fWholesale}
                        onChange={(e) => setFWholesale(e.target.value)}
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Purchase Rate (Admin)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={fPurchase}
                        onChange={(e) => setFPurchase(e.target.value)}
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Disc %
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        value={fDiscount}
                        onChange={(e) => setFDiscount(e.target.value)}
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Scheme / Deal
                      </label>
                      <input
                        value={fScheme}
                        onChange={(e) => setFScheme(e.target.value)}
                        placeholder="9+1"
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Stock Qty
                      </label>
                      <input
                        type="number"
                        min={0}
                        value={fQty}
                        onChange={(e) => setFQty(e.target.value)}
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>
                    <div className="col-span-2 sm:col-span-4">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Deal Rate Adjustability
                      </label>
                      <select
                        value={fDealAdjustable ? 'yes' : 'no'}
                        onChange={(e) => setFDealAdjustable(e.target.value === 'yes')}
                        className="w-full min-h-[38px] px-2.5 rounded-lg border border-slate-300 text-xs bg-white"
                      >
                        <option value="no">
                          Not Adjustable in Rate (Fixed slab / free qty only)
                        </option>
                        <option value="yes">
                          Adjustable in Rate (Adjusts into unit wholesale rate)
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-4 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowProductModal(false)}
                  className="min-h-[42px] px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="min-h-[42px] px-5 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer"
                >
                  {saving ? 'Saving...' : 'Save Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
