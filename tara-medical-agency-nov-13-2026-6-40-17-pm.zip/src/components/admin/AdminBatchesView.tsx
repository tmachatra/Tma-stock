import React, { useMemo, useState } from 'react';
import { Edit3, Plus, Search, Trash2, X } from 'lucide-react';
import {
  computeBatchAvailability,
  formatDateTimeIST,
  formatINR,
  isBatchExpired,
  isDealRateAdjustable,
  isExpiringSoon,
  parseExpiryToIso,
  slugId,
} from '../../lib/pharmaUtils';
import {
  deleteBatchAndCost,
  upsertBatchWithCost,
} from '../../services/catalogService';
import type {
  AdminBatchCost,
  AvailabilityOverride,
  MedicineBatch,
  MedicineProduct,
} from '../../types/pharma';
import { StatusTag } from '../StatusTag';

interface AdminBatchesViewProps {
  products: MedicineProduct[];
  batches: MedicineBatch[];
  batchCosts: Record<string, AdminBatchCost>;
}

export const AdminBatchesView: React.FC<AdminBatchesViewProps> = ({
  products,
  batches,
  batchCosts,
}) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<
    'ALL' | 'EXPIRING_SOON' | 'EXPIRED' | 'ZERO_STOCK' | 'MISSING_EXPIRY'
  >('ALL');

  const [showBatchModal, setShowBatchModal] = useState(false);
  const [editingBatch, setEditingBatch] = useState<MedicineBatch | null>(null);

  const [fProductId, setFProductId] = useState('');
  const [fBatchNo, setFBatchNo] = useState('');
  const [fExpiry, setFExpiry] = useState('');
  const [fMrp, setFMrp] = useState('');
  const [fWholesale, setFWholesale] = useState('');
  const [fPurchase, setFPurchase] = useState('');
  const [fDiscount, setFDiscount] = useState('8');
  const [fScheme, setFScheme] = useState('');
  const [fDealAdjustable, setFDealAdjustable] = useState(false);
  const [fQty, setFQty] = useState('10');
  const [fOverride, setFOverride] = useState<AvailabilityOverride>('AUTO');
  const [saving, setSaving] = useState(false);

  const productMap = useMemo(() => {
    const map: Record<string, MedicineProduct> = {};
    for (const p of products) map[p.id] = p;
    return map;
  }, [products]);

  const rows = useMemo(() => {
    return batches
      .map((b) => ({
        batch: b,
        product: productMap[b.productId],
        purchaseRate: batchCosts[b.id]?.purchaseRate ?? 0,
      }))
      .filter((r) => !!r.product)
      .filter((r) => {
        if (filter === 'EXPIRING_SOON') {
          return isExpiringSoon(r.batch.expiryDate, 4);
        }
        if (filter === 'EXPIRED') {
          return isBatchExpired(r.batch.expiryDate);
        }
        if (filter === 'ZERO_STOCK') {
          return r.batch.availableQty <= 0;
        }
        if (filter === 'MISSING_EXPIRY') {
          return !r.batch.expiryDate;
        }
        return true;
      })
      .filter((r) => {
        if (!search.trim()) return true;
        const q = search.toLowerCase();
        return (
          r.product.name.toLowerCase().includes(q) ||
          r.batch.batchNumber.toLowerCase().includes(q) ||
          r.product.manufacturer.toLowerCase().includes(q)
        );
      })
      .sort((a, b) =>
        (a.batch.expiryDate || '9999-99').localeCompare(
          b.batch.expiryDate || '9999-99'
        )
      );
  }, [batches, productMap, batchCosts, filter, search]);

  const openAddBatch = () => {
    setEditingBatch(null);
    setFProductId(products[0]?.id || '');
    setFBatchNo('');
    setFExpiry('');
    setFMrp('');
    setFWholesale('');
    setFPurchase('');
    setFDiscount('8');
    setFScheme('');
    setFDealAdjustable(false);
    setFQty('10');
    setFOverride('AUTO');
    setShowBatchModal(true);
  };

  const openEditBatch = (b: MedicineBatch) => {
    setEditingBatch(b);
    setFProductId(b.productId);
    setFBatchNo(b.batchNumber);
    setFExpiry(b.expiryDisplay === 'Missing' ? '' : b.expiryDisplay);
    setFMrp(String(b.mrp));
    setFWholesale(String(b.wholesaleRate));
    setFPurchase(String(batchCosts[b.id]?.purchaseRate ?? ''));
    setFDiscount(String(b.discountPercent));
    setFScheme(b.schemeDetails);
    setFDealAdjustable(isDealRateAdjustable(b, productMap[b.productId]));
    setFQty(String(b.availableQty));
    setFOverride(b.availabilityOverride);
    setShowBatchModal(true);
  };

  const handleSaveBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fProductId || !fBatchNo.trim()) return;
    setSaving(true);
    try {
      const parsedExp = parseExpiryToIso(fExpiry);
      const batchId =
        editingBatch?.id || slugId('bat', `${fProductId}_${fBatchNo.trim()}`);
      await upsertBatchWithCost(
        {
          id: batchId,
          productId: fProductId,
          batchNumber: fBatchNo.trim(),
          expiryDate: parsedExp.expiryDate,
          expiryDisplay: parsedExp.expiryDisplay,
          mrp: Math.max(0, Number(fMrp) || 0),
          wholesaleRate: Math.max(0, Number(fWholesale) || 0),
          discountPercent: Math.min(100, Math.max(0, Number(fDiscount) || 0)),
          schemeDetails: fScheme.trim(),
          dealRateAdjustable: fScheme.trim() ? fDealAdjustable : false,
          availableQty: Math.max(0, Number(fQty) || 0),
          availabilityOverride: fOverride,
          isActive: true,
        },
        Number(fPurchase) || 0
      );
      setShowBatchModal(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search medicine or batch number..."
              className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <select
            value={filter}
            onChange={(e) =>
              setFilter(
                e.target.value as
                  | 'ALL'
                  | 'EXPIRING_SOON'
                  | 'EXPIRED'
                  | 'ZERO_STOCK'
                  | 'MISSING_EXPIRY'
              )
            }
            className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold bg-white"
          >
            <option value="ALL">All Batches ({batches.length})</option>
            <option value="EXPIRING_SOON">Expiring Within 4 Months</option>
            <option value="EXPIRED">Expired Batches</option>
            <option value="ZERO_STOCK">Zero Stock</option>
            <option value="MISSING_EXPIRY">Missing Expiry Date</option>
          </select>
        </div>

        <button
          type="button"
          onClick={openAddBatch}
          disabled={products.length === 0}
          className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-1.5 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer disabled:opacity-50"
        >
          <Plus className="w-4 h-4" />
          <span>Add Batch</span>
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs min-w-[880px]">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
              <th className="py-3 px-3">Medicine</th>
              <th className="py-3 px-3">Batch No.</th>
              <th className="py-3 px-3">Expiry</th>
              <th className="py-3 px-3 text-right">Stock</th>
              <th className="py-3 px-3 text-right">Purchase Rate</th>
              <th className="py-3 px-3 text-right">Wholesale Rate</th>
              <th className="py-3 px-3 text-right">MRP</th>
              <th className="py-3 px-3">Deal</th>
              <th className="py-3 px-3">Status</th>
              <th className="py-3 px-3">Updated</th>
              <th className="py-3 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map(({ batch, product, purchaseRate }) => {
              const expired = isBatchExpired(batch.expiryDate);
              const expSoon = isExpiringSoon(batch.expiryDate, 4);
              const status = computeBatchAvailability(
                batch,
                product.minStockLevel,
                product.confirmAvailabilityOnly
              );
              return (
                <tr key={batch.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-3">
                    <div className="font-bold text-slate-950">{product.name}</div>
                    <div className="text-slate-500">
                      {product.manufacturer} · {product.packSize}
                    </div>
                  </td>
                  <td className="py-3 px-3 font-mono font-bold text-slate-900">
                    {batch.batchNumber}
                  </td>
                  <td
                    className={`py-3 px-3 font-mono font-bold tabular-nums ${
                      expired || expSoon || !batch.expiryDate
                        ? 'text-[#B91C1C]'
                        : 'text-slate-900'
                    }`}
                  >
                    {batch.expiryDisplay}
                    {expired && ' (Expired)'}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                    {batch.availableQty}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-600">
                    {formatINR(purchaseRate)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-slate-950">
                    {formatINR(batch.wholesaleRate)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-600">
                    {formatINR(batch.mrp)}
                  </td>
                  <td className="py-3 px-3">
                    {batch.schemeDetails ? (
                      <div className="space-y-0.5">
                        <div className="font-mono font-semibold text-slate-900">
                          {batch.schemeDetails}
                        </div>
                        <span
                          className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                            isDealRateAdjustable(batch, product)
                              ? 'bg-[#D4FF3F]/45 text-slate-950 border-lime-500/60'
                              : 'bg-red-50 text-[#B91C1C] border-red-200'
                          }`}
                        >
                          {isDealRateAdjustable(batch, product)
                            ? 'Adjustable in Rate'
                            : 'Not Adjustable'}
                        </span>
                      </div>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </td>
                  <td className="py-3 px-3">
                    <StatusTag status={status} compact />
                  </td>
                  <td className="py-3 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                    {formatDateTimeIST(batch.updatedAt)}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => openEditBatch(batch)}
                        className="p-2 rounded-md text-slate-600 hover:bg-slate-200 hover:text-slate-950 cursor-pointer"
                        title="Edit batch"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteBatchAndCost(batch.id)}
                        className="p-2 rounded-md text-slate-500 hover:bg-red-50 hover:text-[#E34234] cursor-pointer"
                        title="Delete batch"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showBatchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="font-display text-lg font-bold text-slate-950">
                {editingBatch ? 'Edit Batch & Expiry' : 'Add New Batch'}
              </h2>
              <button
                type="button"
                onClick={() => setShowBatchModal(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBatch} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Medicine Product *
                </label>
                <select
                  required
                  disabled={!!editingBatch}
                  value={fProductId}
                  onChange={(e) => setFProductId(e.target.value)}
                  className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm bg-white"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.packSize}) — {p.manufacturer}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Batch Number *
                  </label>
                  <input
                    required
                    value={fBatchNo}
                    onChange={(e) => setFBatchNo(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Expiry (MM/YY or MM/YYYY)
                  </label>
                  <input
                    value={fExpiry}
                    onChange={(e) => setFExpiry(e.target.value)}
                    placeholder="12/28"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Purchase Rate (Admin Only)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={fPurchase}
                    onChange={(e) => setFPurchase(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Wholesale Rate (₹)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={fWholesale}
                    onChange={(e) => setFWholesale(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    MRP (₹)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={fMrp}
                    onChange={(e) => setFMrp(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Discount %
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={fDiscount}
                    onChange={(e) => setFDiscount(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Scheme / Deal
                  </label>
                  <input
                    value={fScheme}
                    onChange={(e) => setFScheme(e.target.value)}
                    placeholder="9+1"
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Available Qty
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={fQty}
                    onChange={(e) => setFQty(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Deal Rate Adjustability
                  </label>
                  <select
                    value={fDealAdjustable ? 'yes' : 'no'}
                    onChange={(e) => setFDealAdjustable(e.target.value === 'yes')}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm bg-white"
                  >
                    <option value="no">
                      Not Adjustable in Rate (Fixed slab / free qty only, e.g. Panderm++)
                    </option>
                    <option value="yes">
                      Adjustable in Rate (Value adjusts in unit rate, e.g. Monocef)
                    </option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Availability Status Override
                  </label>
                  <select
                    value={fOverride}
                    onChange={(e) =>
                      setFOverride(e.target.value as AvailabilityOverride)
                    }
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm bg-white"
                  >
                    <option value="AUTO">AUTO (Based on Stock &amp; Expiry)</option>
                    <option value="IN_STOCK">Force IN STOCK</option>
                    <option value="LOW_STOCK">Force LOW STOCK</option>
                    <option value="OUT_OF_STOCK">Force OUT OF STOCK</option>
                    <option value="CONFIRM_AVAILABILITY">
                      Force CONFIRM AVAILABILITY
                    </option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowBatchModal(false)}
                  className="min-h-[42px] px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="min-h-[42px] px-5 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer"
                >
                  {saving ? 'Saving...' : 'Save Batch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
