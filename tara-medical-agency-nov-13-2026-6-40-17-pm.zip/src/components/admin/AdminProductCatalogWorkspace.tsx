import React, { useState } from 'react';
import { FileSpreadsheet, Layers, Package } from 'lucide-react';
import type {
  AdminBatchCost,
  ExcelImportLog,
  MedicineBatch,
  MedicineProduct,
  PharmaCompany,
  ProductWithBatches,
} from '../../types/pharma';
import { AdminBatchesView } from './AdminBatchesView';
import { AdminExcelImportView } from './AdminExcelImportView';
import { AdminProductsView } from './AdminProductsView';

interface AdminProductCatalogWorkspaceProps {
  products: ProductWithBatches[];
  rawProducts: MedicineProduct[];
  batches: MedicineBatch[];
  batchCosts: Record<string, AdminBatchCost>;
  companies: PharmaCompany[];
  importLogs: ExcelImportLog[];
}

type ProductRelatedTab = 'products' | 'batches' | 'import';

export const AdminProductCatalogWorkspace: React.FC<
  AdminProductCatalogWorkspaceProps
> = ({
  products,
  rawProducts,
  batches,
  batchCosts,
  companies,
  importLogs,
}) => {
  const [activeTab, setActiveTab] = useState<ProductRelatedTab>('products');

  const tabs = [
    {
      id: 'products' as const,
      label: `Products (${rawProducts.length})`,
      icon: Package,
    },
    {
      id: 'batches' as const,
      label: `Batches & Expiry (${batches.length})`,
      icon: Layers,
    },
    {
      id: 'import' as const,
      label: 'Excel / CSV Import',
      icon: FileSpreadsheet,
    },
  ];

  return (
    <div className="space-y-5 pb-24 md:pb-12">
      <div className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg sm:text-xl font-bold text-slate-950">
            Product &amp; Catalog Editing
          </h1>
          <p className="text-xs text-slate-600">
            Add or edit medicines, wholesale rates, deals, batches, expiry dates, and stock imports.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`inline-flex items-center gap-1.5 min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-[#D4FF3F]'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {activeTab === 'products' && (
        <AdminProductsView
          products={products}
          companies={companies}
          allBatches={batches}
          batchCosts={batchCosts}
        />
      )}

      {activeTab === 'batches' && (
        <AdminBatchesView
          products={rawProducts}
          batches={batches}
          batchCosts={batchCosts}
        />
      )}

      {activeTab === 'import' && (
        <AdminExcelImportView
          existingProducts={rawProducts}
          existingBatches={batches}
          companies={companies}
          importLogs={importLogs}
        />
      )}
    </div>
  );
};
