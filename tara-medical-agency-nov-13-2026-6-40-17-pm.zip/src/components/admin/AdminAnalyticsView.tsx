import React, { useMemo, useRef, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  Clock,
  Download,
  Eye,
  GitCompareArrows,
  PackageX,
  Search,
  ShoppingCart,
  TrendingDown,
  TrendingUp,
  Users,
} from 'lucide-react';
import {
  formatDateTimeIST,
  formatINR,
  isBatchExpired,
  isExpiringSoon,
} from '../../lib/pharmaUtils';
import type {
  AdminBatchCost,
  AdminSubTab,
  CustomerActivityEvent,
  CustomerActivityEventType,
  EnquiryItem,
  MedicineBatch,
  PharmaCompany,
  ProductWithBatches,
  RetailerAccount,
  RetailerEnquiry,
} from '../../types/pharma';

interface AdminAnalyticsViewProps {
  products: ProductWithBatches[];
  batches: MedicineBatch[];
  batchCosts: Record<string, AdminBatchCost>;
  companies: PharmaCompany[];
  retailers: RetailerAccount[];
  allEnquiries: RetailerEnquiry[];
  enquiryItems: Array<EnquiryItem & { enquiryId: string }>;
  customerEvents: CustomerActivityEvent[];
  onJumpToAdminTab: (tab: AdminSubTab) => void;
}

type TimeframeOption = '7d' | '30d' | 'all';
type StockActionType =
  | 'restock_urgent'
  | 'expiry_push'
  | 'slow_mover'
  | 'fast_mover'
  | 'balanced';
type AnalyticsSubSection = 'stock' | 'demand' | 'customers';

function toMillis(ts: { toDate?: () => Date } | null | undefined): number {
  if (!ts || typeof ts.toDate !== 'function') return 0;
  try {
    return ts.toDate().getTime();
  } catch {
    return 0;
  }
}

function escapeCsvCell(val: string | number): string {
  const s = String(val ?? '');
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

const EVENT_LABELS: Record<CustomerActivityEventType, string> = {
  search: 'Searched Catalog',
  zero_result_search: 'Missed Search (0 Results)',
  product_view: 'Viewed Medicine',
  compare_add: 'Added to Compare',
  cart_add: 'Added to Enquiry',
  enquiry_submit: 'Sent WhatsApp Enquiry',
  deal_filter: 'Browsed Deals',
  company_view: 'Viewed Company',
};

export const AdminAnalyticsView: React.FC<AdminAnalyticsViewProps> = ({
  products,
  batches,
  batchCosts,
  companies,
  retailers,
  allEnquiries,
  enquiryItems,
  customerEvents,
  onJumpToAdminTab,
}) => {
  const [timeframe, setTimeframe] = useState<TimeframeOption>('30d');
  const [section, setSection] = useState<AnalyticsSubSection>('stock');
  const [stockFilter, setStockFilter] = useState<'ALL' | StockActionType>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const detailsSectionRef = useRef<HTMLDivElement | null>(null);

  const scrollToDetails = () => {
    detailsSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const cutoffMs = useMemo(() => {
    const now = Date.now();
    if (timeframe === '7d') return now - 7 * 24 * 60 * 60 * 1000;
    if (timeframe === '30d') return now - 30 * 24 * 60 * 60 * 1000;
    return 0;
  }, [timeframe]);

  const filteredEvents = useMemo(() => {
    if (cutoffMs === 0) return customerEvents;
    return customerEvents.filter((e) => {
      const ms = toMillis(e.createdAt);
      return ms === 0 || ms >= cutoffMs;
    });
  }, [customerEvents, cutoffMs]);

  const filteredEnquiries = useMemo(() => {
    if (cutoffMs === 0) return allEnquiries;
    return allEnquiries.filter((e) => {
      const ms = toMillis(e.createdAt);
      return ms === 0 || ms >= cutoffMs;
    });
  }, [allEnquiries, cutoffMs]);

  const activeEnquiryIds = useMemo(
    () => new Set(filteredEnquiries.map((e) => e.id)),
    [filteredEnquiries]
  );

  const filteredEnquiryItems = useMemo(
    () => enquiryItems.filter((item) => activeEnquiryIds.has(item.enquiryId)),
    [enquiryItems, activeEnquiryIds]
  );

  // Per-product customer activity + stock + valuation analysis
  const productAnalytics = useMemo(() => {
    const batchesByProduct = new Map<string, MedicineBatch[]>();
    for (const b of batches) {
      if (!b.isActive) continue;
      const list = batchesByProduct.get(b.productId) || [];
      list.push(b);
      batchesByProduct.set(b.productId, list);
    }

    const metricsByProduct = new Map<
      string,
      {
        views: number;
        compareAdds: number;
        cartAdds: number;
        cartQty: number;
        enquiryUnits: number;
        enquiryRevenue: number;
      }
    >();

    const ensureMetric = (productId: string) => {
      let m = metricsByProduct.get(productId);
      if (!m) {
        m = {
          views: 0,
          compareAdds: 0,
          cartAdds: 0,
          cartQty: 0,
          enquiryUnits: 0,
          enquiryRevenue: 0,
        };
        metricsByProduct.set(productId, m);
      }
      return m;
    };

    for (const ev of filteredEvents) {
      if (!ev.productId) continue;
      const m = ensureMetric(ev.productId);
      if (ev.eventType === 'product_view') m.views += 1;
      else if (ev.eventType === 'compare_add') m.compareAdds += 1;
      else if (ev.eventType === 'cart_add') {
        m.cartAdds += 1;
        m.cartQty += ev.qty || 1;
      }
    }

    for (const item of filteredEnquiryItems) {
      if (!item.productId) continue;
      const m = ensureMetric(item.productId);
      m.enquiryUnits += item.qty || 0;
      m.enquiryRevenue += item.lineTotal || 0;
    }

    return products
      .map((p) => {
        const pBatches = batchesByProduct.get(p.product.id) || [];
        const m = metricsByProduct.get(p.product.id) || {
          views: 0,
          compareAdds: 0,
          cartAdds: 0,
          cartQty: 0,
          enquiryUnits: 0,
          enquiryRevenue: 0,
        };

        let stockWholesaleValue = 0;
        let stockCostValue = 0;
        let hasPurchaseCost = false;
        let expiryRiskQty = 0;
        let expiryRiskValue = 0;
        let knownCostUnits = 0;
        let knownCostSum = 0;
        let knownSaleSum = 0;

        for (const b of pBatches) {
          const qty = Math.max(0, b.availableQty || 0);
          const costEntry = batchCosts[b.id];
          const hasCost =
            costEntry && typeof costEntry.purchaseRate === 'number' && costEntry.purchaseRate > 0;
          const unitCost = hasCost ? costEntry.purchaseRate : b.wholesaleRate;
          if (hasCost) {
            hasPurchaseCost = true;
            knownCostUnits += 1;
            knownCostSum += costEntry.purchaseRate;
            knownSaleSum += b.wholesaleRate;
          }

          stockWholesaleValue += qty * (b.wholesaleRate || 0);
          stockCostValue += qty * (unitCost || 0);

          if (qty > 0 && (isBatchExpired(b.expiryDate) || isExpiringSoon(b.expiryDate, 4))) {
            expiryRiskQty += qty;
            expiryRiskValue += qty * (unitCost || 0);
          }
        }

        const marginPct =
          knownCostUnits > 0 && knownSaleSum > 0
            ? Number((((knownSaleSum - knownCostSum) / knownSaleSum) * 100).toFixed(1))
            : null;

        const demandScore =
          m.views * 1 +
          m.compareAdds * 2 +
          m.cartAdds * 3 +
          m.enquiryUnits * 4;

        const currentStock = p.totalAvailableQty;
        const minLevel = p.product.minStockLevel || 0;
        const isLowOrOut =
          currentStock <= 0 ||
          currentStock <= minLevel ||
          p.availabilityStatus === 'OUT OF STOCK' ||
          p.availabilityStatus === 'LOW STOCK';

        let actionType: StockActionType = 'balanced';
        if (isLowOrOut && (demandScore > 0 || currentStock <= 0 || currentStock < minLevel)) {
          actionType = 'restock_urgent';
        } else if (expiryRiskQty > 0) {
          actionType = 'expiry_push';
        } else if (demandScore === 0 && currentStock > Math.max(minLevel * 1.5, 20)) {
          actionType = 'slow_mover';
        } else if (demandScore >= 4 && currentStock > minLevel) {
          actionType = 'fast_mover';
        }

        const suggestedReorderQty =
          actionType === 'restock_urgent'
            ? Math.max(minLevel * 2 - currentStock, Math.ceil(m.enquiryUnits * 1.5), 10)
            : 0;

        return {
          product: p,
          ...m,
          demandScore,
          currentStock,
          minLevel,
          stockWholesaleValue,
          stockCostValue,
          hasPurchaseCost,
          expiryRiskQty,
          expiryRiskValue,
          marginPct,
          actionType,
          suggestedReorderQty,
        };
      })
      .sort((a, b) => {
        const priority: Record<StockActionType, number> = {
          restock_urgent: 0,
          expiry_push: 1,
          slow_mover: 2,
          fast_mover: 3,
          balanced: 4,
        };
        if (priority[a.actionType] !== priority[b.actionType]) {
          return priority[a.actionType] - priority[b.actionType];
        }
        return b.demandScore - a.demandScore || b.expiryRiskValue - a.expiryRiskValue;
      });
  }, [products, batches, batchCosts, filteredEvents, filteredEnquiryItems]);

  // Executive KPIs
  const kpis = useMemo(() => {
    let restockCount = 0;
    let restockWithDemand = 0;
    let expiryRiskCapital = 0;
    let expiryRiskUnits = 0;
    let totalWholesaleVal = 0;
    let totalCostVal = 0;
    let slowMoverValue = 0;
    let slowMoverCount = 0;

    for (const row of productAnalytics) {
      if (row.actionType === 'restock_urgent') {
        restockCount += 1;
        if (row.demandScore > 0) restockWithDemand += 1;
      }
      if (row.actionType === 'slow_mover') {
        slowMoverCount += 1;
        slowMoverValue += row.stockCostValue;
      }
      expiryRiskCapital += row.expiryRiskValue;
      expiryRiskUnits += row.expiryRiskQty;
      totalWholesaleVal += row.stockWholesaleValue;
      totalCostVal += row.stockCostValue;
    }

    const activeShopUids = new Set<string>();
    let missedSearchCount = 0;
    for (const ev of filteredEvents) {
      activeShopUids.add(ev.retailerUid);
      if (ev.eventType === 'zero_result_search') missedSearchCount += 1;
    }
    for (const enq of filteredEnquiries) {
      activeShopUids.add(enq.retailerUid);
    }

    const totalEnquiryValue = filteredEnquiries.reduce(
      (sum, e) => sum + (e.estimatedTotal || 0),
      0
    );

    const estMarginPct =
      totalWholesaleVal > 0 && totalCostVal > 0 && totalCostVal <= totalWholesaleVal
        ? Number((((totalWholesaleVal - totalCostVal) / totalWholesaleVal) * 100).toFixed(1))
        : null;

    return {
      restockCount,
      restockWithDemand,
      expiryRiskCapital,
      expiryRiskUnits,
      totalWholesaleVal,
      totalCostVal,
      estMarginPct,
      slowMoverCount,
      slowMoverValue,
      totalEvents: filteredEvents.length,
      activeShops: activeShopUids.size,
      totalEnquiries: filteredEnquiries.length,
      totalEnquiryValue,
      missedSearchCount,
    };
  }, [productAnalytics, filteredEvents, filteredEnquiries]);

  // Missed searches & Top search queries
  const searchIntelligence = useMemo(() => {
    const zeroMap = new Map<
      string,
      { query: string; count: number; shops: Set<string>; lastAt: number }
    >();
    const topMap = new Map<
      string,
      { query: string; count: number; avgResults: number; zeroCount: number }
    >();

    for (const ev of filteredEvents) {
      if (ev.eventType !== 'search' && ev.eventType !== 'zero_result_search') continue;
      const rawQ = (ev.searchQuery || '').trim();
      if (!rawQ) continue;
      const key = rawQ.toLowerCase();
      const ms = toMillis(ev.createdAt);

      const topEntry = topMap.get(key) || {
        query: rawQ,
        count: 0,
        avgResults: 0,
        zeroCount: 0,
      };
      const prevTotal = topEntry.avgResults * topEntry.count;
      topEntry.count += 1;
      topEntry.avgResults = (prevTotal + (ev.resultCount || 0)) / topEntry.count;
      if (ev.eventType === 'zero_result_search') topEntry.zeroCount += 1;
      topMap.set(key, topEntry);

      if (ev.eventType === 'zero_result_search') {
        const zEntry = zeroMap.get(key) || {
          query: rawQ,
          count: 0,
          shops: new Set<string>(),
          lastAt: 0,
        };
        zEntry.count += 1;
        zEntry.shops.add(ev.shopName || ev.retailerId || ev.retailerUid);
        if (ms > zEntry.lastAt) zEntry.lastAt = ms;
        zeroMap.set(key, zEntry);
      }
    }

    const missedSearches = Array.from(zeroMap.values())
      .map((x) => ({
        query: x.query,
        count: x.count,
        shopCount: x.shops.size,
        lastAt: x.lastAt,
      }))
      .sort((a, b) => b.count - a.count || b.lastAt - a.lastAt);

    const topSearches = Array.from(topMap.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 12);

    return { missedSearches, topSearches };
  }, [filteredEvents]);

  // Company & Category Demand Summary
  const companyAnalysis = useMemo(() => {
    const map = new Map<
      string,
      {
        companyName: string;
        skuCount: number;
        lowOrOutCount: number;
        totalUnits: number;
        stockValue: number;
        demandScore: number;
        enquiryRevenue: number;
        companyViews: number;
      }
    >();

    for (const c of companies) {
      map.set(c.id, {
        companyName: c.name,
        skuCount: 0,
        lowOrOutCount: 0,
        totalUnits: 0,
        stockValue: 0,
        demandScore: 0,
        enquiryRevenue: 0,
        companyViews: 0,
      });
    }

    for (const row of productAnalytics) {
      const cId = row.product.product.companyId || 'other';
      const entry = map.get(cId) || {
        companyName: row.product.product.manufacturer || 'Other',
        skuCount: 0,
        lowOrOutCount: 0,
        totalUnits: 0,
        stockValue: 0,
        demandScore: 0,
        enquiryRevenue: 0,
        companyViews: 0,
      };
      entry.skuCount += 1;
      if (
        row.product.availabilityStatus === 'OUT OF STOCK' ||
        row.product.availabilityStatus === 'LOW STOCK'
      ) {
        entry.lowOrOutCount += 1;
      }
      entry.totalUnits += row.currentStock;
      entry.stockValue += row.stockWholesaleValue;
      entry.demandScore += row.demandScore;
      entry.enquiryRevenue += row.enquiryRevenue;
      map.set(cId, entry);
    }

    for (const ev of filteredEvents) {
      if (ev.eventType === 'company_view' && ev.companyId) {
        const entry = map.get(ev.companyId);
        if (entry) entry.companyViews += 1;
      }
    }

    return Array.from(map.values())
      .filter((x) => x.skuCount > 0 || x.companyViews > 0)
      .sort(
        (a, b) =>
          b.demandScore + b.companyViews * 2 - (a.demandScore + a.companyViews * 2) ||
          b.stockValue - a.stockValue
      );
  }, [companies, productAnalytics, filteredEvents]);

  // Retailer Activity Scorecard & Dormant Retailers
  const customerScorecard = useMemo(() => {
    const map = new Map<
      string,
      {
        uid: string;
        retailerId: string;
        shopName: string;
        city: string;
        searches: number;
        views: number;
        cartAdds: number;
        enquiries: number;
        orderValue: number;
        lastActiveMs: number;
      }
    >();

    for (const r of retailers) {
      if (r.status !== 'active') continue;
      map.set(r.uid, {
        uid: r.uid,
        retailerId: r.retailerId,
        shopName: r.shopName || r.ownerName,
        city: r.city || '—',
        searches: 0,
        views: 0,
        cartAdds: 0,
        enquiries: 0,
        orderValue: 0,
        lastActiveMs: 0,
      });
    }

    for (const ev of filteredEvents) {
      const entry = map.get(ev.retailerUid) || {
        uid: ev.retailerUid,
        retailerId: ev.retailerId || '—',
        shopName: ev.shopName || 'Retailer',
        city: ev.city || '—',
        searches: 0,
        views: 0,
        cartAdds: 0,
        enquiries: 0,
        orderValue: 0,
        lastActiveMs: 0,
      };
      if (ev.eventType === 'search' || ev.eventType === 'zero_result_search') {
        entry.searches += 1;
      } else if (ev.eventType === 'product_view') {
        entry.views += 1;
      } else if (ev.eventType === 'cart_add') {
        entry.cartAdds += 1;
      }
      const ms = toMillis(ev.createdAt);
      if (ms > entry.lastActiveMs) entry.lastActiveMs = ms;
      map.set(ev.retailerUid, entry);
    }

    for (const enq of filteredEnquiries) {
      const entry = map.get(enq.retailerUid) || {
        uid: enq.retailerUid,
        retailerId: '—',
        shopName: enq.retailerShopName || 'Retailer',
        city: '—',
        searches: 0,
        views: 0,
        cartAdds: 0,
        enquiries: 0,
        orderValue: 0,
        lastActiveMs: 0,
      };
      entry.enquiries += 1;
      entry.orderValue += enq.estimatedTotal || 0;
      const ms = toMillis(enq.createdAt);
      if (ms > entry.lastActiveMs) entry.lastActiveMs = ms;
      map.set(enq.retailerUid, entry);
    }

    const allRows = Array.from(map.values());
    const activeRows = allRows
      .filter(
        (x) =>
          x.searches + x.views + x.cartAdds + x.enquiries > 0 || x.orderValue > 0
      )
      .sort(
        (a, b) =>
          b.orderValue - a.orderValue ||
          b.enquiries * 5 + b.cartAdds * 2 + b.views -
            (a.enquiries * 5 + a.cartAdds * 2 + a.views)
      );

    const dormantRows = allRows.filter(
      (x) =>
        x.searches + x.views + x.cartAdds + x.enquiries === 0 && x.orderValue === 0
    );

    return { activeRows, dormantRows };
  }, [retailers, filteredEvents, filteredEnquiries]);

  const expiryRiskBatches = useMemo(() => {
    const productById = new Map(products.map((p) => [p.product.id, p.product]));
    return batches
      .filter(
        (b) =>
          b.isActive &&
          (b.availableQty || 0) > 0 &&
          (isBatchExpired(b.expiryDate) || isExpiringSoon(b.expiryDate, 4))
      )
      .map((b) => {
        const prod = productById.get(b.productId);
        const costEntry = batchCosts[b.id];
        const unitCost =
          costEntry && typeof costEntry.purchaseRate === 'number' && costEntry.purchaseRate > 0
            ? costEntry.purchaseRate
            : b.wholesaleRate;
        return {
          batch: b,
          productName: prod?.name || b.productId,
          manufacturer: prod?.manufacturer || '',
          packSize: prod?.packSize || '',
          expired: isBatchExpired(b.expiryDate),
          capitalAtRisk: (b.availableQty || 0) * (unitCost || 0),
        };
      })
      .sort((a, b) =>
        (a.batch.expiryDate || '9999-99-99').localeCompare(
          b.batch.expiryDate || '9999-99-99'
        )
      );
  }, [batches, products, batchCosts]);

  const visibleStockRows = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    return productAnalytics.filter((row) => {
      if (stockFilter === 'expiry_push') {
        if (row.expiryRiskQty <= 0) return false;
      } else if (stockFilter !== 'ALL' && row.actionType !== stockFilter) {
        return false;
      }
      if (!q) return true;
      const p = row.product.product;
      return (
        p.name.toLowerCase().includes(q) ||
        p.genericName.toLowerCase().includes(q) ||
        p.manufacturer.toLowerCase().includes(q) ||
        p.productCode.toLowerCase().includes(q)
      );
    });
  }, [productAnalytics, stockFilter, searchTerm]);

  const handleExportCsv = () => {
    const headers = [
      'Product Code',
      'Medicine Name',
      'Company',
      'Pack',
      'Current Stock',
      'Min Stock Level',
      'Earliest Expiry',
      'Stock Value (INR)',
      'Expiry Risk Qty',
      'Customer Views',
      'Cart Adds',
      'Enquiry Units',
      'Demand Score',
      'Recommendation',
      'Suggested Reorder Qty',
    ];
    const lines = [headers.map(escapeCsvCell).join(',')];
    for (const r of visibleStockRows) {
      lines.push(
        [
          r.product.product.productCode,
          r.product.product.name,
          r.product.product.manufacturer,
          r.product.product.packSize,
          r.currentStock,
          r.minLevel,
          r.product.earliestExpiryDisplay,
          r.stockWholesaleValue.toFixed(2),
          r.expiryRiskQty,
          r.views,
          r.cartAdds,
          r.enquiryUnits,
          r.demandScore,
          r.actionType.toUpperCase(),
          r.suggestedReorderQty,
        ]
          .map(escapeCsvCell)
          .join(',')
      );
    }

    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `tara-medical-stock-analytics-${timeframe}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const renderRecommendationBadge = (
    type: StockActionType,
    suggestedQty: number,
    expiryQty: number
  ) => {
    if (type === 'restock_urgent') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-red-100 text-[#B91C1C] text-[11px] font-bold">
          <PackageX className="w-3 h-3" />
          Restock +{suggestedQty}
        </span>
      );
    }
    if (type === 'expiry_push') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 text-[11px] font-bold">
          <Clock className="w-3 h-3" />
          Push Deal ({expiryQty} exp)
        </span>
      );
    }
    if (type === 'slow_mover') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-200 text-slate-800 text-[11px] font-bold">
          <TrendingDown className="w-3 h-3" />
          Slow Mover
        </span>
      );
    }
    if (type === 'fast_mover') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#D4FF3F] text-slate-950 text-[11px] font-bold">
          <TrendingUp className="w-3 h-3" />
          Fast Mover
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 text-[11px] font-semibold">
        <CheckCircle2 className="w-3 h-3" />
        Balanced
      </span>
    );
  };

  return (
    <div className="space-y-6 pb-24 md:pb-12">
      {/* Header */}
      <section className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-[#CBB3E8]">
            Tara Medical Agency · Stock &amp; Customer Intelligence
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold text-white flex items-center gap-2.5">
            <BarChart3 className="w-6 h-6 text-[#D4FF3F]" />
            <span>Customer Activity &amp; Stock Analytics</span>
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-300">
            Live demand signals from retailer searches, views, compare lists &amp; enquiries combined with stock, expiry risk &amp; margins.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-xl bg-slate-800 p-1 border border-slate-700">
            {(
              [
                { id: '7d', label: '7 Days' },
                { id: '30d', label: '30 Days' },
                { id: 'all', label: 'All Time' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setTimeframe(opt.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  timeframe === opt.id
                    ? 'bg-[#D4FF3F] text-slate-950'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 min-h-[38px] px-3.5 py-1.5 rounded-xl bg-white text-slate-950 text-xs font-bold hover:bg-slate-100 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </section>

      {/* Executive KPI Cards */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div
          role="button"
          tabIndex={0}
          onClick={() => {
            setSection('stock');
            setStockFilter('restock_urgent');
            setSearchTerm('');
            scrollToDetails();
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setSection('stock');
              setStockFilter('restock_urgent');
              setSearchTerm('');
              scrollToDetails();
            }
          }}
          aria-label="Show urgent restock items"
          className={`rounded-xl p-4 cursor-pointer transition group focus:outline-none focus:ring-2 focus:ring-red-300 border ${
            section === 'stock' && stockFilter === 'restock_urgent'
              ? 'bg-red-50/70 border-[#B91C1C] ring-2 ring-red-200'
              : 'bg-white border-slate-200 hover:border-slate-900 hover:bg-red-50/30'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-600">
            <span>Urgent Restock Items</span>
            <PackageX className="w-4 h-4 text-[#E34234]" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-[#B91C1C] tabular-nums">
            {kpis.restockCount}
          </div>
          <div className="mt-1 flex items-center justify-between gap-2 text-xs text-slate-600 tabular-nums">
            <span>{kpis.restockWithDemand} have active retailer demand</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-950 group-hover:translate-x-0.5 transition-transform shrink-0" />
          </div>
        </div>

        <div
          role="button"
          tabIndex={0}
          onClick={() => {
            setSection('stock');
            setStockFilter('expiry_push');
            setSearchTerm('');
            scrollToDetails();
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setSection('stock');
              setStockFilter('expiry_push');
              setSearchTerm('');
              scrollToDetails();
            }
          }}
          aria-label="Show expiry risk batches and medicines"
          className={`rounded-xl p-4 cursor-pointer transition group focus:outline-none focus:ring-2 focus:ring-amber-300 border ${
            section === 'stock' && stockFilter === 'expiry_push'
              ? 'bg-amber-50/80 border-amber-600 ring-2 ring-amber-200'
              : 'bg-white border-slate-200 hover:border-slate-900 hover:bg-amber-50/30'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-600">
            <span>Expiry Risk Capital</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {formatINR(kpis.expiryRiskCapital)}
          </div>
          <div className="mt-1 flex items-center justify-between gap-2 text-xs text-slate-600 tabular-nums">
            <span>{kpis.expiryRiskUnits} units expiring ≤4m / expired</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-950 group-hover:translate-x-0.5 transition-transform shrink-0" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Active Stock Value</span>
            <TrendingUp className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {formatINR(kpis.totalWholesaleVal)}
          </div>
          <div className="mt-1 text-xs text-slate-600 tabular-nums">
            {kpis.slowMoverCount} slow movers ({formatINR(kpis.slowMoverValue)})
            {kpis.estMarginPct !== null ? ` · ${kpis.estMarginPct}% margin` : ''}
          </div>
        </div>

        <div
          role="button"
          tabIndex={0}
          onClick={() => {
            setSection('customers');
            scrollToDetails();
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setSection('customers');
              scrollToDetails();
            }
          }}
          aria-label="Show customer activity breakdown"
          className={`rounded-xl p-4 cursor-pointer transition group focus:outline-none focus:ring-2 focus:ring-[#CBB3E8] border ${
            section === 'customers'
              ? 'bg-[#CBB3E8]/20 border-slate-900 ring-2 ring-[#CBB3E8]'
              : 'bg-white border-slate-200 hover:border-slate-900 hover:bg-[#CBB3E8]/10'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-600">
            <span>Customer Activity</span>
            <Activity className="w-4 h-4 text-slate-700" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {kpis.totalEvents}
          </div>
          <div className="mt-1 flex items-center justify-between gap-2 text-xs text-slate-600 tabular-nums">
            <span>
              {kpis.activeShops} active shops · {kpis.totalEnquiries} enquiries ({formatINR(kpis.totalEnquiryValue)})
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-950 group-hover:translate-x-0.5 transition-transform shrink-0" />
          </div>
        </div>
      </section>

      {/* Section Switcher */}
      <div
        ref={detailsSectionRef}
        className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3 scroll-mt-16"
      >
        {(
          [
            { id: 'stock', label: 'Stock & Reorder Analysis', icon: BarChart3 },
            {
              id: 'demand',
              label: `Search & Unmet Demand (${searchIntelligence.missedSearches.length})`,
              icon: Search,
            },
            {
              id: 'customers',
              label: `Customer Activity (${customerScorecard.activeRows.length} Active)`,
              icon: Users,
            },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          const active = section === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSection(tab.id)}
              className={`inline-flex items-center gap-2 min-h-[40px] px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                active
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className={`w-4 h-4 ${active ? 'text-[#D4FF3F]' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* SECTION 1: STOCK MANAGEMENT & REORDER ANALYSIS */}
      {section === 'stock' && (
        <section className="space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {(
                [
                  { id: 'ALL', label: `All (${productAnalytics.length})` },
                  {
                    id: 'restock_urgent',
                    label: `Restock Urgent (${kpis.restockCount})`,
                  },
                  {
                    id: 'expiry_push',
                    label: `Expiry Push (${
                      productAnalytics.filter((x) => x.expiryRiskQty > 0).length
                    })`,
                  },
                  {
                    id: 'slow_mover',
                    label: `Slow Movers (${kpis.slowMoverCount})`,
                  },
                  {
                    id: 'fast_mover',
                    label: `Fast Movers (${
                      productAnalytics.filter((x) => x.actionType === 'fast_mover').length
                    })`,
                  },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setStockFilter(f.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    stockFilter === f.id
                      ? 'bg-[#CBB3E8] text-slate-950'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Filter medicine, salt, company..."
                className="w-full min-h-[38px] pl-9 pr-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
          </div>

          {stockFilter === 'expiry_push' && (
            <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="font-display text-sm sm:text-base font-bold text-slate-950">
                    Batches at Expiry Risk ({expiryRiskBatches.length})
                  </h2>
                  <p className="text-xs text-slate-600">
                    Expired or expiring within 4 months — attach deals or adjust rates in Batches to liquidate fast
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onJumpToAdminTab('batches')}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 cursor-pointer"
                >
                  Manage Batches →
                </button>
              </div>
              {expiryRiskBatches.length === 0 ? (
                <div className="text-xs text-slate-600 bg-white rounded-xl p-3 border border-amber-100">
                  No active stock batches are expired or expiring within 4 months.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {expiryRiskBatches.slice(0, 12).map((item) => (
                    <div
                      key={item.batch.id}
                      className="bg-white border border-amber-200 rounded-xl p-3 text-xs space-y-1"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="font-bold text-slate-950 truncate">
                          {item.productName}
                        </span>
                        <span
                          className={`px-1.5 py-0.5 rounded font-mono font-bold text-[10px] shrink-0 ${
                            item.expired
                              ? 'bg-red-100 text-[#B91C1C]'
                              : 'bg-amber-100 text-amber-900'
                          }`}
                        >
                          {item.expired ? 'EXPIRED' : `Exp ${item.batch.expiryDisplay}`}
                        </span>
                      </div>
                      <div className="text-slate-500 font-mono">
                        Batch {item.batch.batchNumber} · {item.batch.availableQty} units · {formatINR(item.capitalAtRisk)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    <th className="py-3 px-4">Medicine &amp; Company</th>
                    <th className="py-3 px-3 text-right">Stock / Min</th>
                    <th className="py-3 px-3">Expiry</th>
                    <th className="py-3 px-3 text-right">Stock Value</th>
                    <th className="py-3 px-3 text-center">Customer Demand</th>
                    <th className="py-3 px-4 text-right">Stock Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {visibleStockRows.slice(0, 80).map((row) => {
                    const p = row.product.product;
                    return (
                      <tr key={p.id} className="hover:bg-slate-50/80">
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-950">{p.name}</div>
                          <div className="text-[11px] text-slate-500">
                            {p.manufacturer} · {p.packSize}
                            {row.marginPct !== null && (
                              <span className="ml-2 font-mono text-emerald-700 font-semibold">
                                {row.marginPct}% margin
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums">
                          <span
                            className={`font-bold ${
                              row.currentStock <= row.minLevel
                                ? 'text-[#B91C1C]'
                                : 'text-slate-950'
                            }`}
                          >
                            {row.currentStock}
                          </span>
                          <span className="text-slate-400"> / {row.minLevel}</span>
                        </td>
                        <td className="py-3 px-3 font-mono text-xs text-slate-700 whitespace-nowrap">
                          {row.product.earliestExpiryDisplay}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-900">
                          {formatINR(row.stockWholesaleValue)}
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex items-center justify-center gap-2.5 text-[11px] font-mono text-slate-600 tabular-nums">
                            <span title="Product views" className="inline-flex items-center gap-0.5">
                              <Eye className="w-3 h-3 text-slate-400" />
                              {row.views}
                            </span>
                            <span title="Added to compare" className="inline-flex items-center gap-0.5">
                              <GitCompareArrows className="w-3 h-3 text-slate-400" />
                              {row.compareAdds}
                            </span>
                            <span title="Added to enquiry" className="inline-flex items-center gap-0.5">
                              <ShoppingCart className="w-3 h-3 text-slate-400" />
                              {row.cartAdds + row.enquiryUnits}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          {renderRecommendationBadge(
                            row.actionType,
                            row.suggestedReorderQty,
                            row.expiryRiskQty
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  {visibleStockRows.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-10 text-center text-sm text-slate-500">
                        No products match the selected filter.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
              <span>
                Showing {Math.min(visibleStockRows.length, 80)} of {visibleStockRows.length} SKUs
              </span>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onJumpToAdminTab('batches')}
                  className="font-bold text-slate-900 hover:underline cursor-pointer"
                >
                  Update Batches &amp; Deals →
                </button>
                <button
                  type="button"
                  onClick={() => onJumpToAdminTab('products')}
                  className="font-bold text-slate-900 hover:underline cursor-pointer"
                >
                  Manage Min Stock Levels →
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* SECTION 2: SEARCH & UNMET DEMAND */}
      {section === 'demand' && (
        <section className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Missed Searches (0 Results) */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h2 className="font-display text-base font-bold text-slate-950">
                    Unmet Search Demand (0 Results)
                  </h2>
                  <p className="text-xs text-slate-500">
                    Medicines or salts customers searched for that were not found in your catalog
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-lg bg-red-50 text-[#B91C1C] font-mono text-xs font-bold">
                  {searchIntelligence.missedSearches.length} queries
                </span>
              </div>

              {searchIntelligence.missedSearches.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-100">
                  No zero-result customer searches recorded in this timeframe yet.
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {searchIntelligence.missedSearches.slice(0, 12).map((item) => (
                    <div
                      key={item.query}
                      className="py-2.5 flex items-center justify-between gap-3 text-sm"
                    >
                      <div>
                        <div className="font-bold text-slate-950">
                          &ldquo;{item.query}&rdquo;
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Requested by {item.shopCount} {item.shopCount === 1 ? 'shop' : 'shops'}
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-md bg-red-100 text-[#B91C1C] font-mono text-xs font-bold tabular-nums">
                        {item.count}×
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Top Searched Queries */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
              <div>
                <h2 className="font-display text-base font-bold text-slate-950">
                  Top Customer Search Terms
                </h2>
                <p className="text-xs text-slate-500">
                  Most frequently searched brands, compositions, and codes
                </p>
              </div>

              {searchIntelligence.topSearches.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-100">
                  Customer search queries will appear here automatically as retailers search the catalog.
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {searchIntelligence.topSearches.map((item) => (
                    <div
                      key={item.query}
                      className="py-2.5 flex items-center justify-between gap-3 text-sm"
                    >
                      <div>
                        <div className="font-semibold text-slate-900">
                          {item.query}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          Avg {Math.round(item.avgResults)} matches
                          {item.zeroCount > 0 ? ` · ${item.zeroCount} missed` : ''}
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-md bg-[#CBB3E8]/35 text-slate-950 font-mono text-xs font-bold tabular-nums">
                        {item.count} searches
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Company Demand vs Stock Coverage */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
            <div>
              <h2 className="font-display text-base font-bold text-slate-950">
                Company-Wise Demand vs. Stock Coverage
              </h2>
              <p className="text-xs text-slate-500">
                Compare customer demand score and enquiry revenue against current stock &amp; low-stock alerts per manufacturer
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    <th className="py-2.5 px-3">Company</th>
                    <th className="py-2.5 px-3 text-right">SKUs</th>
                    <th className="py-2.5 px-3 text-right">Low / Out</th>
                    <th className="py-2.5 px-3 text-right">Stock Units</th>
                    <th className="py-2.5 px-3 text-right">Stock Value</th>
                    <th className="py-2.5 px-3 text-right">Demand Score</th>
                    <th className="py-2.5 px-3 text-right">Enquiry Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {companyAnalysis.map((c) => (
                    <tr key={c.companyName} className="hover:bg-slate-50/70">
                      <td className="py-2.5 px-3 font-bold text-slate-900">
                        {c.companyName}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        {c.skuCount}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        <span
                          className={
                            c.lowOrOutCount > 0 ? 'font-bold text-[#B91C1C]' : 'text-slate-500'
                          }
                        >
                          {c.lowOrOutCount}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        {c.totalUnits}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        {formatINR(c.stockValue)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-950">
                        {c.demandScore + c.companyViews * 2}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-800 font-semibold">
                        {formatINR(c.enquiryRevenue)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      {/* SECTION 3: CUSTOMER (RETAILER) ACTIVITY & LIVE STREAM */}
      {section === 'customers' && (
        <section className="space-y-5">
          {/* Active Retailer Engagement Table */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="font-display text-base font-bold text-slate-950">
                  Retailer Activity &amp; Order Leaderboard
                </h2>
                <p className="text-xs text-slate-500">
                  Tracks useful shopping behavior per approved pharmacy
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-slate-700">
                {customerScorecard.activeRows.length} active · {customerScorecard.dormantRows.length} dormant
              </span>
            </div>

            {customerScorecard.activeRows.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-100">
                No customer browsing or enquiry events recorded in this timeframe yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                      <th className="py-2.5 px-3">Pharmacy / Shop</th>
                      <th className="py-2.5 px-3">City</th>
                      <th className="py-2.5 px-3 text-right">Searches</th>
                      <th className="py-2.5 px-3 text-right">Views</th>
                      <th className="py-2.5 px-3 text-right">Cart Adds</th>
                      <th className="py-2.5 px-3 text-right">Enquiries</th>
                      <th className="py-2.5 px-3 text-right">Est. Order ₹</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {customerScorecard.activeRows.map((r) => (
                      <tr key={r.uid} className="hover:bg-slate-50/70">
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-slate-950">{r.shopName}</div>
                          <div className="font-mono text-[11px] text-slate-500">
                            {r.retailerId}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-slate-600">{r.city}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                          {r.searches}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                          {r.views}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                          {r.cartAdds}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums">
                          {r.enquiries}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-emerald-800">
                          {formatINR(r.orderValue)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Dormant Approved Retailers */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
              <div>
                <h2 className="font-display text-base font-bold text-slate-950">
                  Dormant Approved Retailers ({customerScorecard.dormantRows.length})
                </h2>
                <p className="text-xs text-slate-500">
                  Active accounts with zero searches, views, or enquiries in this period — good candidates for follow-up
                </p>
              </div>
              {customerScorecard.dormantRows.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl">
                  All approved retailers have activity in this window.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                  {customerScorecard.dormantRows.slice(0, 20).map((r) => (
                    <div
                      key={r.uid}
                      className="py-2.5 flex items-center justify-between gap-2 text-xs"
                    >
                      <div>
                        <div className="font-bold text-slate-900">{r.shopName}</div>
                        <div className="text-slate-500 font-mono">
                          {r.retailerId} · {r.city}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onJumpToAdminTab('directory')}
                        className="px-2.5 py-1 rounded-md border border-slate-200 text-slate-700 font-semibold hover:bg-slate-50 cursor-pointer"
                      >
                        View Account
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Live Activity Feed */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
              <div>
                <h2 className="font-display text-base font-bold text-slate-950">
                  Recent Customer Activity Stream
                </h2>
                <p className="text-xs text-slate-500">
                  Latest retailer searches, medicine views, compare additions &amp; enquiries
                </p>
              </div>
              {filteredEvents.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl">
                  Waiting for retailer activity events.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                  {filteredEvents.slice(0, 30).map((ev) => (
                    <div
                      key={ev.id}
                      className="py-2.5 flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="min-w-0">
                        <div className="font-bold text-slate-900 truncate">
                          {ev.shopName}{' '}
                          <span className="font-mono font-normal text-slate-500">
                            ({ev.retailerId})
                          </span>
                        </div>
                        <div className="mt-0.5 text-slate-700">
                          <span
                            className={`inline-block px-1.5 py-0.5 rounded font-semibold mr-1.5 ${
                              ev.eventType === 'zero_result_search'
                                ? 'bg-red-100 text-[#B91C1C]'
                                : ev.eventType === 'enquiry_submit'
                                ? 'bg-[#D4FF3F] text-slate-950'
                                : 'bg-slate-100 text-slate-800'
                            }`}
                          >
                            {EVENT_LABELS[ev.eventType]}
                          </span>
                          {ev.productName ||
                            (ev.searchQuery ? `"${ev.searchQuery}"` : '') ||
                            ev.companyName ||
                            ''}
                          {typeof ev.estimatedValue === 'number' && ev.estimatedValue > 0
                            ? ` · ${formatINR(ev.estimatedValue)}`
                            : ''}
                        </div>
                      </div>
                      <span className="font-mono text-[10px] text-slate-400 shrink-0">
                        {ev.createdAt ? formatDateTimeIST(ev.createdAt.toDate()) : 'Just now'}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
