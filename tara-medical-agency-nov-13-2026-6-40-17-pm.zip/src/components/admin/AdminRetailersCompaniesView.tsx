import React, { useState } from 'react';
import {
  Building2,
  Check,
  CheckCircle2,
  Copy,
  Edit3,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  MessageCircle,
  Plus,
  RefreshCw,
  Trash2,
  UserPlus,
  Users,
  X,
  XCircle,
} from 'lucide-react';
import { normalizeRetailerId } from '../../lib/firebase';
import {
  createRetailerByAdmin,
  deleteCompany,
  resetRetailerPasswordByAdmin,
  updateRetailerAdmin,
  upsertCompany,
} from '../../services/catalogService';
import type {
  PharmaCompany,
  PriceTier,
  RetailerAccount,
} from '../../types/pharma';

interface AdminRetailersCompaniesViewProps {
  retailers: RetailerAccount[];
  companies: PharmaCompany[];
}

interface CreatedCredentials {
  retailerId: string;
  initialPassword: string;
  shopName: string;
  ownerName: string;
  phone: string;
}

function generateInitialPassword(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let suffix = '';
  for (let i = 0; i < 5; i += 1) {
    suffix += chars[Math.floor(Math.random() * chars.length)];
  }
  return `Tma@${suffix}`;
}

export const AdminRetailersCompaniesView: React.FC<
  AdminRetailersCompaniesViewProps
> = ({ retailers, companies }) => {
  const [compName, setCompName] = useState('');
  const [compCode, setCompCode] = useState('');
  const [savingComp, setSavingComp] = useState(false);

  // Add Retailer modal/drawer state
  const [showAddForm, setShowAddForm] = useState(false);
  const [retailerIdInput, setRetailerIdInput] = useState('');
  const [initialPassword, setInitialPassword] = useState(() =>
    generateInitialPassword()
  );
  const [showPw, setShowPw] = useState(true);
  const [shopName, setShopName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [drugLicenseNo, setDrugLicenseNo] = useState('');
  const [city, setCity] = useState('Chatra');
  const [address, setAddress] = useState('');
  const [priceTier, setPriceTier] = useState<PriceTier>('standard');
  const [customDiscountBonus, setCustomDiscountBonus] = useState(0);
  const [creatingRetailer, setCreatingRetailer] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);
  const [createdCreds, setCreatedCreds] = useState<CreatedCredentials | null>(
    null
  );
  const [copiedCreds, setCopiedCreds] = useState(false);

  // Edit existing retailer profile modal state (Retailer ID remains locked)
  const [editingRetailer, setEditingRetailer] =
    useState<RetailerAccount | null>(null);
  const [editShopName, setEditShopName] = useState('');
  const [editOwnerName, setEditOwnerName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editDl, setEditDl] = useState('');
  const [editCity, setEditCity] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);
  const [resettingPw, setResettingPw] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  const normalizedPreview = normalizeRetailerId(retailerIdInput);

  const handleOpenAddForm = () => {
    const nextNum = 101 + retailers.length;
    setRetailerIdInput(`TMA-${nextNum}`);
    setInitialPassword(generateInitialPassword());
    setShowPw(true);
    setShopName('');
    setOwnerName('');
    setPhone('');
    setDrugLicenseNo('');
    setCity('Chatra');
    setAddress('');
    setPriceTier('standard');
    setCustomDiscountBonus(0);
    setCreateError(null);
    setShowAddForm(true);
  };

  const handleCreateRetailer = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError(null);

    const normId = normalizeRetailerId(retailerIdInput);
    if (normId.length < 3 || normId.length > 32) {
      setCreateError(
        'Retailer ID must be 3–32 characters (letters, numbers, "-" or "_").'
      );
      return;
    }

    const duplicate = retailers.find(
      (r) => normalizeRetailerId(r.retailerId || '') === normId
    );
    if (duplicate) {
      setCreateError(
        `Retailer ID "${normId}" is already assigned to ${duplicate.shopName}. Please choose a unique Retailer ID.`
      );
      return;
    }

    if (initialPassword.length < 6) {
      setCreateError('Initial password must be at least 6 characters.');
      return;
    }
    if (!shopName.trim() || !ownerName.trim() || !phone.trim()) {
      setCreateError(
        'Please fill in Pharmacy/Clinic Name, Proprietor Name, and Mobile Phone.'
      );
      return;
    }

    setCreatingRetailer(true);
    try {
      const result = await createRetailerByAdmin({
        retailerId: normId,
        initialPassword,
        shopName: shopName.trim(),
        ownerName: ownerName.trim(),
        phone: phone.trim(),
        drugLicenseNo: drugLicenseNo.trim(),
        city: city.trim() || 'Chatra',
        address: address.trim(),
        priceTier,
        customDiscountBonus: Number(customDiscountBonus) || 0,
      });

      setCreatedCreds({
        retailerId: result.retailerId,
        initialPassword,
        shopName: shopName.trim(),
        ownerName: ownerName.trim(),
        phone: phone.trim(),
      });
      setCopiedCreds(false);
      setShowAddForm(false);
    } catch (err) {
      const rawMsg = err instanceof Error ? err.message : String(err);
      let friendlyMsg = rawMsg;
      if (rawMsg.trim().startsWith('{')) {
        try {
          const parsed = JSON.parse(rawMsg) as { error?: string };
          if (parsed.error) friendlyMsg = parsed.error;
        } catch {
          // Keep rawMsg if not valid JSON
        }
      }
      setCreateError(friendlyMsg || 'Failed to create retailer account.');
    } finally {
      setCreatingRetailer(false);
    }
  };

  const handleCopyCredentials = async () => {
    if (!createdCreds) return;
    const text = [
      `Tara Medical Agency - Retailer Portal Login`,
      `Pharmacy: ${createdCreds.shopName}`,
      `Retailer ID: ${createdCreds.retailerId} (Permanent)`,
      `Initial Password: ${createdCreds.initialPassword}`,
      `Portal URL: ${window.location.origin}`,
      `Note: You can change your password after logging in, but Retailer ID cannot be changed.`,
    ].join('\n');
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCreds(true);
      setTimeout(() => setCopiedCreds(false), 3000);
    } catch {
      // Fallback ignored if clipboard denied
    }
  };

  const getWhatsAppShareUrl = (creds: CreatedCredentials) => {
    const digits = creds.phone.replace(/\D/g, '');
    const waTarget =
      digits.length === 10
        ? `91${digits}`
        : digits.length >= 11
        ? digits
        : '';
    const msg = [
      `*Tara Medical Agency - Retailer Portal Credentials*`,
      `Namaste ${creds.ownerName},`,
      `Your wholesale stock & rate portal account for *${creds.shopName}* is ready:`,
      ``,
      `*Retailer ID:* ${creds.retailerId}`,
      `*Password:* ${creds.initialPassword}`,
      `*Login Link:* ${window.location.origin}`,
      ``,
      `Please sign in on the *Retailer Login* tab. You can change your password anytime from Account & Password (your Retailer ID is permanent).`,
    ].join('\n');
    const encoded = encodeURIComponent(msg);
    return waTarget
      ? `https://wa.me/${waTarget}?text=${encoded}`
      : `https://wa.me/?text=${encoded}`;
  };

  const openEditModal = (r: RetailerAccount) => {
    setEditingRetailer(r);
    setEditShopName(r.shopName);
    setEditOwnerName(r.ownerName);
    setEditPhone(r.phone);
    setEditDl(r.drugLicenseNo || '');
    setEditCity(r.city || '');
    setEditAddress(r.address || '');
    setEditError(null);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRetailer) return;
    if (!editShopName.trim() || !editOwnerName.trim() || !editPhone.trim()) {
      setEditError('Shop Name, Proprietor Name, and Phone are required.');
      return;
    }
    setSavingEdit(true);
    setEditError(null);
    try {
      await updateRetailerAdmin(editingRetailer.uid, {
        shopName: editShopName.trim(),
        ownerName: editOwnerName.trim(),
        phone: editPhone.trim(),
        drugLicenseNo: editDl.trim(),
        city: editCity.trim(),
        address: editAddress.trim(),
      });
      setEditingRetailer(null);
    } catch (err) {
      setEditError(
        err instanceof Error ? err.message : 'Failed to update retailer details.'
      );
    } finally {
      setSavingEdit(false);
    }
  };

  const handleResetRetailerPassword = async () => {
    if (!editingRetailer) return;
    const tempPassword = generateInitialPassword();
    setResettingPw(true);
    setEditError(null);
    try {
      await resetRetailerPasswordByAdmin(editingRetailer.uid, tempPassword);
      setCreatedCreds({
        retailerId: editingRetailer.retailerId,
        initialPassword: tempPassword,
        shopName: editingRetailer.shopName,
        ownerName: editingRetailer.ownerName,
        phone: editingRetailer.phone,
      });
      setCopiedCreds(false);
      setEditingRetailer(null);
    } catch (err) {
      setEditError(
        err instanceof Error ? err.message : 'Failed to reset retailer password.'
      );
    } finally {
      setResettingPw(false);
    }
  };

  const handleAddCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!compName.trim()) return;
    setSavingComp(true);
    try {
      await upsertCompany({
        name: compName.trim(),
        shortCode: compCode.trim() || compName.trim().slice(0, 6).toUpperCase(),
        active: true,
      });
      setCompName('');
      setCompCode('');
    } finally {
      setSavingComp(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* One-time Created Credentials Card */}
      {createdCreds && (
        <section className="bg-slate-900 text-white rounded-xl p-5 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#D4FF3F] shrink-0 mt-0.5" />
              <div>
                <h3 className="font-display text-base font-bold">
                  Retailer Account Created — Share Credentials Now
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Copy or send these login credentials to{' '}
                  <strong className="text-white">{createdCreds.shopName}</strong>.
                  The initial password is shown once and is never stored in plain
                  text.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setCreatedCreds(null)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              aria-label="Dismiss credentials card"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-800/80 border border-slate-700 rounded-xl p-4">
            <div>
              <div className="text-[11px] text-slate-400">
                Unique Retailer ID (Permanent)
              </div>
              <div className="mt-0.5 font-mono text-base font-bold text-[#D4FF3F]">
                {createdCreds.retailerId}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-slate-400">Initial Password</div>
              <div className="mt-0.5 font-mono text-base font-bold text-white">
                {createdCreds.initialPassword}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleCopyCredentials}
              className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-1.5 rounded-lg bg-white text-slate-950 text-xs font-bold hover:bg-slate-100 cursor-pointer"
            >
              {copiedCreds ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Copied Credentials</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy ID &amp; Password</span>
                </>
              )}
            </button>
            <a
              href={getWhatsAppShareUrl(createdCreds)}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-1.5 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Send Credentials via WhatsApp</span>
            </a>
          </div>
        </section>
      )}

      {/* Retailer Accounts Access Control */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-950 flex items-center gap-2">
              <Users className="w-5 h-5" />
              <span>Retailer Accounts &amp; Credentials ({retailers.length})</span>
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-slate-600">
              Create approved retailer accounts with a unique permanent Retailer ID
              and initial password. Retailers can update their password later, but
              cannot change their Retailer ID.
            </p>
          </div>

          <button
            type="button"
            onClick={handleOpenAddForm}
            className="inline-flex items-center justify-center gap-1.5 min-h-[44px] px-4 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add New Retailer</span>
          </button>
        </div>

        {/* Add New Retailer Form */}
        {showAddForm && (
          <form
            onSubmit={handleCreateRetailer}
            className="p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-slate-900" />
                <h3 className="font-display text-sm sm:text-base font-bold text-slate-950">
                  Issue New Retailer Login (ID &amp; Password)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-200 cursor-pointer"
                aria-label="Cancel add retailer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Unique Retailer ID * (Permanent)
                </label>
                <input
                  required
                  value={retailerIdInput}
                  onChange={(e) => setRetailerIdInput(e.target.value)}
                  placeholder="e.g. TMA-101"
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono text-sm uppercase"
                />
                <div className="mt-1 text-[11px] text-slate-500">
                  Saved as:{' '}
                  <span className="font-mono font-bold text-slate-800">
                    {normalizedPreview || '—'}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Initial Password * (min 6 chars)
                </label>
                <div className="flex items-center gap-1.5">
                  <div className="relative flex-1">
                    <input
                      required
                      minLength={6}
                      type={showPw ? 'text' : 'password'}
                      value={initialPassword}
                      onChange={(e) => setInitialPassword(e.target.value)}
                      className="w-full min-h-[42px] pl-3 pr-9 py-1.5 rounded-lg border border-slate-300 bg-white font-mono text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPw((v) => !v)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800 cursor-pointer"
                      aria-label={showPw ? 'Hide password' : 'Show password'}
                    >
                      {showPw ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => setInitialPassword(generateInitialPassword())}
                    className="min-h-[42px] px-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-100 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                    title="Generate random password"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Generate</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Pharmacy / Clinic Name *
                </label>
                <input
                  required
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  placeholder="e.g. Maa Sharda Medical Hall"
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Proprietor / Doctor Name *
                </label>
                <input
                  required
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="e.g. Rajesh Kumar"
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  WhatsApp / Mobile Phone *
                </label>
                <input
                  required
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="10-digit mobile number"
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Drug License No. (Optional)
                </label>
                <input
                  value={drugLicenseNo}
                  onChange={(e) => setDrugLicenseNo(e.target.value)}
                  placeholder="e.g. JH-CHA-..."
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Town / Block
                </label>
                <input
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Chatra, Simaria, Hunterganj..."
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Price Tier
                </label>
                <select
                  value={priceTier}
                  onChange={(e) => setPriceTier(e.target.value as PriceTier)}
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-sm"
                >
                  <option value="standard">Standard</option>
                  <option value="tier_a">Tier A (Volume)</option>
                  <option value="tier_b">Tier B (Key Account)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Extra Bonus Discount %
                </label>
                <input
                  type="number"
                  min={0}
                  max={50}
                  step="0.5"
                  value={customDiscountBonus}
                  onChange={(e) =>
                    setCustomDiscountBonus(Number(e.target.value) || 0)
                  }
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono text-sm"
                />
              </div>

              <div className="sm:col-span-2 lg:col-span-3">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Shop Address (Optional)
                </label>
                <input
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Main Market / Near Bus Stand..."
                  className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-sm"
                />
              </div>
            </div>

            {createError && (
              <p className="text-xs font-semibold text-[#B91C1C] bg-red-50 border border-red-200 rounded-lg px-3.5 py-2.5 leading-relaxed">
                {createError}
              </p>
            )}

            <div className="flex flex-wrap items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="min-h-[42px] px-4 py-2 rounded-lg border border-slate-300 bg-white text-slate-700 text-xs font-semibold hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={creatingRetailer}
                className="min-h-[42px] px-5 py-2 rounded-lg bg-slate-950 text-white text-xs font-bold hover:bg-slate-800 disabled:opacity-60 cursor-pointer"
              >
                {creatingRetailer
                  ? 'Creating Account...'
                  : 'Create Retailer & Issue Credentials'}
              </button>
            </div>
          </form>
        )}

        {retailers.length === 0 ? (
          <div className="p-6 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-600 text-center">
            No retailers added yet. Click <strong>Add New Retailer</strong> above
            to assign a Unique Retailer ID and initial Password to a pharmacy or
            practitioner.
          </div>
        ) : (
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left border-collapse text-xs min-w-[880px]">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-3">Retailer ID</th>
                  <th className="py-3 px-3">Pharmacy / Clinic</th>
                  <th className="py-3 px-3">Owner &amp; Contact</th>
                  <th className="py-3 px-3">DL / Location</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Price Tier</th>
                  <th className="py-3 px-3">Extra Disc %</th>
                  <th className="py-3 px-3 text-right">Access Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {retailers.map((r) => (
                  <tr key={r.uid} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3">
                      <div className="font-mono font-bold text-slate-950">
                        {r.retailerId || 'LEGACY'}
                      </div>
                      {r.mustChangePassword && (
                        <div className="text-[10px] font-semibold text-amber-700 mt-0.5">
                          Initial PW active
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-bold text-slate-950">{r.shopName}</div>
                      {r.address && (
                        <div className="text-slate-500 truncate max-w-[200px]">
                          {r.address}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-medium text-slate-800">
                        {r.ownerName}
                      </div>
                      <div className="font-mono text-slate-600">{r.phone}</div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-mono text-slate-700">
                        {r.drugLicenseNo || 'No DL'}
                      </div>
                      <div className="text-slate-500">{r.city || 'Chatra'}</div>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded font-bold uppercase text-[11px] ${
                          r.status === 'active'
                            ? 'bg-[#D4FF3F]/50 text-slate-950'
                            : r.status === 'pending'
                            ? 'bg-[#CBB3E8]/55 text-slate-950'
                            : 'bg-red-100 text-[#B91C1C]'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <select
                        value={r.priceTier}
                        onChange={(e) =>
                          updateRetailerAdmin(r.uid, {
                            priceTier: e.target.value as PriceTier,
                          })
                        }
                        className="min-h-[34px] px-2 rounded-md border border-slate-300 bg-white text-xs"
                      >
                        <option value="standard">Standard</option>
                        <option value="tier_a">Tier A (Volume)</option>
                        <option value="tier_b">Tier B (Key Account)</option>
                      </select>
                    </td>
                    <td className="py-3 px-3">
                      <input
                        type="number"
                        min={0}
                        max={50}
                        step="0.5"
                        defaultValue={r.customDiscountBonus}
                        onBlur={(e) => {
                          const val = Math.min(
                            50,
                            Math.max(0, Number(e.target.value) || 0)
                          );
                          if (val !== r.customDiscountBonus) {
                            updateRetailerAdmin(r.uid, {
                              customDiscountBonus: val,
                            });
                          }
                        }}
                        className="w-20 min-h-[34px] px-2 rounded-md border border-slate-300 font-mono text-xs"
                      />
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openEditModal(r)}
                          className="inline-flex items-center gap-1 min-h-[34px] px-2.5 py-1 rounded-md border border-slate-300 bg-white text-slate-700 font-semibold hover:bg-slate-100 cursor-pointer"
                          title="Edit shop details"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        {r.status !== 'active' && (
                          <button
                            type="button"
                            onClick={() =>
                              updateRetailerAdmin(r.uid, { status: 'active' })
                            }
                            className="inline-flex items-center gap-1 min-h-[34px] px-2.5 py-1 rounded-md bg-[#D4FF3F] text-slate-950 font-bold hover:brightness-95 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Activate</span>
                          </button>
                        )}
                        {r.status === 'active' && (
                          <button
                            type="button"
                            onClick={() =>
                              updateRetailerAdmin(r.uid, {
                                status: 'deactivated',
                              })
                            }
                            className="inline-flex items-center gap-1 min-h-[34px] px-2.5 py-1 rounded-md border border-red-300 bg-red-50 text-[#B91C1C] font-semibold hover:bg-red-100 cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Deactivate</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Edit Retailer Details Modal (Retailer ID Locked) */}
      {editingRetailer && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Edit Retailer Profile"
        >
          <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-display text-lg font-bold text-slate-950">
                Edit Retailer Details
              </h3>
              <button
                type="button"
                onClick={() => setEditingRetailer(null)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
                aria-label="Close edit modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="mt-4 space-y-3.5">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-slate-500">
                    Permanent Retailer ID (Locked)
                  </div>
                  <div className="font-mono text-sm font-bold text-slate-950">
                    {editingRetailer.retailerId}
                  </div>
                </div>
                <Lock className="w-4 h-4 text-slate-400" />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Pharmacy / Clinic Name *
                  </label>
                  <input
                    required
                    value={editShopName}
                    onChange={(e) => setEditShopName(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Proprietor / Doctor Name *
                  </label>
                  <input
                    required
                    value={editOwnerName}
                    onChange={(e) => setEditOwnerName(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    WhatsApp / Mobile Phone *
                  </label>
                  <input
                    required
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Drug License No.
                  </label>
                  <input
                    value={editDl}
                    onChange={(e) => setEditDl(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Town / Block
                  </label>
                  <input
                    value={editCity}
                    onChange={(e) => setEditCity(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Address
                  </label>
                  <input
                    value={editAddress}
                    onChange={(e) => setEditAddress(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
              </div>

              {editError && (
                <p className="text-xs font-semibold text-[#B91C1C]">
                  {editError}
                </p>
              )}

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                <button
                  type="button"
                  disabled={resettingPw}
                  onClick={handleResetRetailerPassword}
                  className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-1.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-xs font-bold hover:bg-slate-100 cursor-pointer disabled:opacity-60"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>
                    {resettingPw ? 'Resetting...' : 'Reset Password'}
                  </span>
                </button>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingRetailer(null)}
                    className="min-h-[40px] px-4 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={savingEdit}
                    className="min-h-[40px] px-4 py-1.5 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer"
                  >
                    {savingEdit ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Pharmaceutical Companies Directory */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-950 flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              <span>Pharmaceutical Companies ({companies.length})</span>
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-slate-600">
              Add or toggle pharmaceutical manufacturers displayed in the retailer
              catalogue.
            </p>
          </div>

          <form
            onSubmit={handleAddCompany}
            className="flex flex-wrap items-center gap-2"
          >
            <input
              required
              value={compName}
              onChange={(e) => setCompName(e.target.value)}
              placeholder="Company Name (e.g. Lupin)"
              className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
            />
            <input
              value={compCode}
              onChange={(e) => setCompCode(e.target.value)}
              placeholder="Code (LUPIN)"
              className="w-28 min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-mono"
            />
            <button
              type="submit"
              disabled={savingComp}
              className="inline-flex items-center gap-1 min-h-[40px] px-3.5 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Company</span>
            </button>
          </form>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {companies.map((c) => (
            <div
              key={c.id}
              className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between gap-3"
            >
              <div className="min-w-0">
                <div className="font-mono text-[11px] font-bold text-slate-500">
                  {c.shortCode}
                </div>
                <div className="text-sm font-bold text-slate-900 truncate">
                  {c.name}
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() =>
                    upsertCompany({
                      id: c.id,
                      name: c.name,
                      shortCode: c.shortCode,
                      active: !c.active,
                    })
                  }
                  className={`px-2.5 py-1 rounded-md text-xs font-semibold cursor-pointer ${
                    c.active
                      ? 'bg-[#D4FF3F]/45 text-slate-950'
                      : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {c.active ? 'Active' : 'Hidden'}
                </button>
                <button
                  type="button"
                  onClick={() => deleteCompany(c.id)}
                  className="p-1.5 rounded-md text-slate-400 hover:text-[#E34234] hover:bg-red-50 cursor-pointer"
                  aria-label={`Delete ${c.name}`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
