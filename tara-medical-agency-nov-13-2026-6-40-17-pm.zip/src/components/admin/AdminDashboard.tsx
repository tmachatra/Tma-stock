import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  BarChart3,
  Database,
  FileSpreadsheet,
  KeyRound,
  Layers,
  LayoutDashboard,
  Menu,
  Package,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import {
  formatDateTimeIST,
  isBatchExpired,
  isExpiringSoon,
} from '../../lib/pharmaUtils';
import { seedInitialCatalog } from '../../services/catalogService';
import type {
  AdminBatchCost,
  AdminSubTab,
  ExcelImportLog,
  MedicineBatch,
  MedicineProduct,
  PharmaCompany,
  ProductWithBatches,
  RetailerAccount,
} from '../../types/pharma';
import { AdminBatchesView } from './AdminBatchesView';
import { AdminExcelImportView } from './AdminExcelImportView';
import { AdminProductsView } from './AdminProductsView';
import { AdminRetailersCompaniesView } from './AdminRetailersCompaniesView';

interface AdminDashboardProps {
  products: ProductWithBatches[];
  rawProducts: MedicineProduct[];
  batches: MedicineBatch[];
  batchCosts: Record<string, AdminBatchCost>;
  companies: PharmaCompany[];
  retailers: RetailerAccount[];
  importLogs: ExcelImportLog[];
  requestedTab?: AdminSubTab | null;
  onRequestedTabHandled?: () => void;
  onOpenAnalytics?: () => void;
  onOpenAdminPasswordModal: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  products,
  rawProducts,
  batches,
  batchCosts,
  companies,
  retailers,
  importLogs,
  requestedTab,
  onRequestedTabHandled,
  onOpenAnalytics,
  onOpenAdminPasswordModal,
}) => {
  const { adminAccount } = useAuth();
  const [subTab, setSubTab] = useState<AdminSubTab>('overview');
  const [adminMenuOpen, setAdminMenuOpen] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [seedMessage, setSeedMessage] = useState<string | null>(null);

  useEffect(() => {
    if (requestedTab) {
      setSubTab(requestedTab);
      onRequestedTabHandled?.();
    }
  }, [requestedTab, onRequestedTabHandled]);

  const adminTabs = useMemo(
    () =>
      [
        { id: 'overview', label: 'Overview', icon: LayoutDashboard },
        {
          id: 'analytics',
          label: 'Customer & Stock Analytics',
          icon: BarChart3,
        },
        {
          id: 'products',
          label: `Products (${rawProducts.length})`,
          icon: Package,
        },
        {
          id: 'batches',
          label: `Batches & Expiry (${batches.length})`,
          icon: Layers,
        },
        {
          id: 'import',
          label: 'Excel / CSV Import',
          icon: FileSpreadsheet,
        },
        {
          id: 'directory',
          label: `Retailers & Companies (${retailers.length})`,
          icon: Users,
        },
      ] as const,
    [rawProducts.length, batches.length, retailers.length]
  );

  const activeTabMeta =
    adminTabs.find((t) => t.id === subTab) ?? adminTabs[0];

  const stats = useMemo(() => {
    const missingInfo = products.filter((p) => p.hasMissingInfo).length;
    const lowOrOut = products.filter(
      (p) =>
        p.availabilityStatus === 'LOW STOCK' ||
        p.availabilityStatus === 'OUT OF STOCK'
    ).length;
    const expiringSoon = batches.filter(
      (b) => isExpiringSoon(b.expiryDate, 4) || isBatchExpired(b.expiryDate)
    ).length;
    const pendingRetailers = retailers.filter(
      (r) => r.status === 'pending'
    ).length;
    const activeRetailers = retailers.filter(
      (r) => r.status === 'active'
    ).length;
    let latestUpdate: Date | null = null;
    for (const p of products) {
      if (p.latestUpdatedAt && (!latestUpdate || p.latestUpdatedAt > latestUpdate)) {
        latestUpdate = p.latestUpdatedAt;
      }
    }
    return {
      missingInfo,
      lowOrOut,
      expiringSoon,
      pendingRetailers,
      activeRetailers,
      latestUpdate,
    };
  }, [products, batches, retailers]);

  const handleSeedCatalog = async () => {
    setSeeding(true);
    setSeedMessage(null);
    try {
      const res = await seedInitialCatalog();
      setSeedMessage(
        `Seeded ${res.productsCount} verified invoice medicines and ${res.batchesCount} batches (with isolated admin purchase rates).`
      );
    } catch (err) {
      setSeedMessage(
        err instanceof Error ? err.message : 'Failed to seed sample catalog.'
      );
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="space-y-6 pb-24 md:pb-12">

      {adminAccount?.mustChangePassword && (
        <div className="bg-[#CBB3E8]/30 border border-[#CBB3E8] rounded-xl px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs sm:text-sm text-slate-900">
            <span className="font-bold">Admin Security Reminder:</span> You are signed in with the initial setup password for{' '}
            <span className="font-mono font-bold">{adminAccount.adminId}</span>. Please change it to your own private password.
          </div>
          <button
            type="button"
            onClick={onOpenAdminPasswordModal}
            className="inline-flex items-center justify-center gap-1.5 min-h-[38px] px-4 py-1.5 rounded-lg bg-slate-950 text-white text-xs font-bold hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <KeyRound className="w-3.5 h-3.5 text-[#D4FF3F]" />
            <span>Change Admin Password</span>
          </button>
        </div>
      )}

      {seedMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-900">
          {seedMessage}
        </div>
      )}

      {/* Hamburger Menu Trigger Bar */}
      <div className="flex items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl px-3.5 py-2.5">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => setAdminMenuOpen(true)}
            aria-label="Open admin sections menu"
            aria-expanded={adminMenuOpen}
            className="inline-flex items-center gap-2 min-h-[40px] px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 shrink-0 cursor-pointer"
          >
            <Menu className="w-4 h-4 text-[#D4FF3F]" />
            <span>Menu</span>
          </button>
          <div className="min-w-0">
            <div className="text-[11px] font-medium text-slate-500 leading-none">
              Admin Section
            </div>
            <div className="mt-1 text-sm font-bold text-slate-950 truncate">
              {activeTabMeta.label}
            </div>
          </div>
        </div>
        <span className="hidden sm:inline text-xs font-mono text-slate-500">
          Updated:{' '}
          {stats.latestUpdate
            ? formatDateTimeIST(stats.latestUpdate)
            : 'No products loaded yet'}
        </span>
      </div>

      {adminMenuOpen && (
        <div
          className="fixed inset-0 z-50 flex"
          role="dialog"
          aria-modal="true"
          aria-label="Admin navigation menu"
        >
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
            onClick={() => setAdminMenuOpen(false)}
          />
          <aside className="relative z-10 w-full max-w-xs bg-white h-full overflow-y-auto shadow-2xl p-5 flex flex-col">
            <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-200">
              <div>
                <div className="text-xs font-semibold text-slate-500">
                  Tara Medical Agency
                </div>
                <div className="font-display text-base font-bold text-slate-950">
                  Admin Console Menu
                </div>
              </div>
              <button
                type="button"
                onClick={() => setAdminMenuOpen(false)}
                aria-label="Close admin menu"
                className="inline-flex items-center justify-center min-h-[40px] min-w-[40px] rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="mt-4 space-y-1.5">
              {adminTabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = subTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => {
                      setAdminMenuOpen(false);
                      if (tab.id === 'analytics' && onOpenAnalytics) {
                        onOpenAnalytics();
                        return;
                      }
                      setSubTab(tab.id);
                    }}
                    className={`w-full min-h-[44px] px-3.5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-3 text-left transition cursor-pointer ${
                      isActive
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-700 hover:bg-slate-100 hover:text-slate-950'
                    }`}
                  >
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isActive ? 'text-[#D4FF3F]' : 'text-slate-500'
                      }`}
                    />
                    <span className="truncate">{tab.label}</span>
                  </button>
                );
              })}
            </nav>

            <div className="mt-auto pt-4 border-t border-slate-200 space-y-2">
              <div className="text-[11px] font-medium text-slate-500">
                Catalog Maintenance
              </div>
              <button
                type="button"
                disabled={seeding}
                onClick={async () => {
                  await handleSeedCatalog();
                  setAdminMenuOpen(false);
                }}
                className="w-full inline-flex items-center justify-center gap-2 min-h-[42px] px-3.5 py-2 rounded-xl bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer disabled:opacity-60"
              >
                <Database className="w-4 h-4 shrink-0" />
                <span>
                  {seeding
                    ? 'Seeding Catalog...'
                    : rawProducts.length === 0
                    ? 'Load Invoice Catalog (38 Medicines)'
                    : 'Reset / Sync Invoice Sample Catalog'}
                </span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {subTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Products</span>
                <Package className="w-4 h-4 text-slate-400" />
              </div>
              <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
                {rawProducts.length}
              </div>
              <div className="mt-1 text-xs text-slate-600">
                {companies.length} pharma companies
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Active Batches</span>
                <Layers className="w-4 h-4 text-slate-400" />
              </div>
              <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
                {batches.length}
              </div>
              <div className="mt-1 text-xs text-slate-600">
                {stats.lowOrOut} low / out of stock
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Near Expiry / Expired</span>
                <AlertCircle className="w-4 h-4 text-[#E34234]" />
              </div>
              <div className="mt-2 font-display text-2xl font-bold text-[#B91C1C] tabular-nums">
                {stats.expiringSoon}
              </div>
              <div className="mt-1 text-xs text-slate-600">
                Within 4 months or expired
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Missing Data Alerts</span>
                <FileSpreadsheet className="w-4 h-4 text-amber-600" />
              </div>
              <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
                {stats.missingInfo}
              </div>
              <div className="mt-1 text-xs text-slate-600">
                Missing rate, salt or expiry
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 col-span-2 lg:col-span-1">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Retailer Accounts</span>
                <Users className="w-4 h-4 text-slate-400" />
              </div>
              <div className="mt-2 font-display text-2xl font-bold text-slate-950 tabular-nums">
                {stats.activeRetailers}
              </div>
              <div className="mt-1 text-xs text-slate-600">
                {stats.pendingRetailers} pending approval
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              type="button"
              onClick={() => setSubTab('import')}
              className="bg-white border border-slate-200 rounded-xl p-5 text-left hover:border-slate-900 transition cursor-pointer"
            >
              <div className="font-display text-base font-bold text-slate-950">
                Import Excel / CSV Stock Sheet
              </div>
              <p className="mt-1 text-xs text-slate-600">
                Upload Marg ERP, Kamal Agencies, or custom spreadsheets, map columns, and update stock without duplicates.
              </p>
            </button>

            <button
              type="button"
              onClick={() => setSubTab('batches')}
              className="bg-white border border-slate-200 rounded-xl p-5 text-left hover:border-slate-900 transition cursor-pointer"
            >
              <div className="font-display text-base font-bold text-slate-950">
                Audit Batches &amp; Expiry Dates
              </div>
              <p className="mt-1 text-xs text-slate-600">
                Update batch quantities, add new batches, or check items expiring within the next 4 months.
              </p>
            </button>

            <button
              type="button"
              onClick={() => setSubTab('directory')}
              className="bg-white border border-slate-200 rounded-xl p-5 text-left hover:border-slate-900 transition cursor-pointer"
            >
              <div className="font-display text-base font-bold text-slate-950">
                Approve &amp; Manage Retailers
              </div>
              <p className="mt-1 text-xs text-slate-600">
                Activate new medical stores, deactivate accounts, or assign custom discount tiers.
              </p>
            </button>
          </div>
        </div>
      )}

      {subTab === 'products' && (
        <AdminProductsView
          products={products}
          companies={companies}
          allBatches={batches}
          batchCosts={batchCosts}
        />
      )}

      {subTab === 'batches' && (
        <AdminBatchesView
          products={rawProducts}
          batches={batches}
          batchCosts={batchCosts}
        />
      )}

      {subTab === 'import' && (
        <AdminExcelImportView
          existingProducts={rawProducts}
          existingBatches={batches}
          companies={companies}
          importLogs={importLogs}
        />
      )}

      {subTab === 'directory' && (
        <AdminRetailersCompaniesView
          retailers={retailers}
          companies={companies}
        />
      )}
    </div>
  );
};
