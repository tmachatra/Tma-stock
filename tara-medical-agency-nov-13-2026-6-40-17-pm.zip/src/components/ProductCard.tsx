import React from 'react';
import {
  Check,
  ChevronRight,
  GitCompareArrows,
  Layers,
  Minus,
  Plus,
} from 'lucide-react';
import {
  formatDateTimeIST,
  formatINR,
  formatSchemeOfferLabel,
  getActiveSchemeInfo,
  isExpiringSoon,
} from '../lib/pharmaUtils';
import type { ProductWithBatches } from '../types/pharma';
import { StatusTag } from './StatusTag';

interface ProductCardProps {
  item: ProductWithBatches;
  qtyInCart: number;
  isCompared: boolean;
  onAddToCart: (item: ProductWithBatches) => void;
  onUpdateCartQty: (productId: string, batchId: string, qty: number) => void;
  onToggleCompare: (productId: string) => void;
  onOpenDetails: (item: ProductWithBatches) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  item,
  qtyInCart,
  isCompared,
  onAddToCart,
  onUpdateCartQty,
  onToggleCompare,
  onOpenDetails,
}) => {
  const { product, earliestValidBatch } = item;
  const expSoon = isExpiringSoon(item.earliestExpiryIso, 4);
  const multiBatchCount = item.batches.length;
  const { schemeDetails: activeScheme, dealRateAdjustable } =
    getActiveSchemeInfo(item);
  const schemeOfferLabel = formatSchemeOfferLabel(activeScheme);

  return (
    <article className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col justify-between transition-colors hover:border-slate-300">
      <div>
        {/* Top Row: Thumbnail (if any) + Name + Status */}
        <div className="flex items-start justify-between gap-3">
          {product.imageUrl && (
            <button
              type="button"
              onClick={() => onOpenDetails(item)}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl border border-slate-200 bg-slate-50 overflow-hidden shrink-0 cursor-pointer hover:border-slate-400 transition"
              title={`View ${product.name} photo & details`}
              aria-label={`View ${product.name} photo`}
            >
              <img
                src={product.imageUrl}
                alt={product.name}
                loading="lazy"
                className="w-full h-full object-contain bg-white"
              />
            </button>
          )}
          <div className="min-w-0 flex-1">
            <button
              type="button"
              onClick={() => onOpenDetails(item)}
              className="text-left group cursor-pointer"
            >
              <h3 className="font-display text-base sm:text-lg font-bold text-slate-950 leading-snug group-hover:underline">
                {product.name}
              </h3>
            </button>
            <div className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-slate-600">
              <span className="font-medium text-slate-800">
                {product.manufacturer}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono font-medium">{product.packSize}</span>
              {product.productCode && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-500">
                    {product.productCode}
                  </span>
                </>
              )}
            </div>
          </div>
          <StatusTag status={item.availabilityStatus} compact />
        </div>

        {/* Generic / Composition */}
        <p className="mt-2.5 text-xs sm:text-sm text-slate-700 leading-snug line-clamp-2">
          <span className="font-semibold text-slate-900">
            {product.genericName || 'Salt not specified'}
          </span>
          {product.composition &&
          product.composition !== product.genericName ? (
            <span className="text-slate-600"> — {product.composition}</span>
          ) : null}
        </p>

        {/* Pricing, Deal, and Expiry Grid */}
        <div className="mt-3.5 pt-3.5 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <div className="text-slate-500">Wholesale Rate</div>
            <div className="mt-0.5 font-mono text-base font-bold text-slate-950 tabular-nums">
              {item.effectiveWholesaleRate > 0
                ? formatINR(item.effectiveWholesaleRate)
                : 'Confirm'}
            </div>
            {activeScheme && dealRateAdjustable && item.effectiveUnitAfterScheme ? (
              <div className="text-[11px] font-mono text-emerald-800 font-semibold tabular-nums">
                Adj. Net {formatINR(item.effectiveUnitAfterScheme)}
              </div>
            ) : activeScheme && !dealRateAdjustable ? (
              <div className="text-[11px] text-[#B91C1C] font-semibold">
                Fixed rate (slab only)
              </div>
            ) : null}
          </div>

          <div>
            <div className="text-slate-500">MRP &amp; Disc.</div>
            <div className="mt-0.5 font-mono text-sm font-semibold text-slate-900 tabular-nums">
              {item.mrp > 0 ? formatINR(item.mrp) : '—'}
            </div>
            <div className="text-[11px] font-mono text-slate-600 tabular-nums">
              {item.discountPercent > 0 ? `${item.discountPercent}% off` : 'Net rate'}
            </div>
          </div>

          <div>
            <div className="text-slate-500">Scheme / Free Qty</div>
            <div className="mt-0.5">
              {activeScheme ? (
                <div className="space-y-1">
                  <span className="inline-block px-2 py-0.5 rounded bg-[#CBB3E8]/55 text-slate-950 font-mono text-xs font-bold tabular-nums">
                    {activeScheme}
                  </span>
                  {schemeOfferLabel && schemeOfferLabel !== activeScheme && (
                    <div className="text-[11px] font-semibold text-slate-700 leading-tight">
                      {schemeOfferLabel}
                    </div>
                  )}
                  <div
                    className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold leading-tight border ${
                      dealRateAdjustable
                        ? 'bg-[#D4FF3F]/45 text-slate-950 border-lime-500/60'
                        : 'bg-red-50 text-[#B91C1C] border-red-200'
                    }`}
                  >
                    {dealRateAdjustable
                      ? 'Adjustable in Rate'
                      : 'Not Adjustable in Rate'}
                  </div>
                </div>
              ) : (
                <div className="space-y-0.5">
                  <span className="text-slate-400 font-medium">No scheme</span>
                  <div className="text-[10px] text-slate-400">Standard rate</div>
                </div>
              )}
            </div>
          </div>

          <div>
            <div className="text-slate-500">Earliest Expiry</div>
            <div
              className={`mt-0.5 font-mono text-sm font-bold tabular-nums ${
                expSoon ? 'text-[#B91C1C]' : 'text-slate-900'
              }`}
            >
              {item.earliestExpiryDisplay}
            </div>
            {multiBatchCount > 1 && (
              <div className="inline-flex items-center gap-1 text-[11px] text-slate-600 font-medium">
                <Layers className="w-3 h-3" />
                <span>{multiBatchCount} batches</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer: Timestamp + Actions */}
      <div className="mt-4 pt-3 border-t border-slate-100 space-y-3">
        <div className="flex items-center justify-between text-[11px] text-slate-500">
          <span>
            Updated:{' '}
            <span className="font-mono text-slate-700 tabular-nums">
              {formatDateTimeIST(item.latestUpdatedAt)}
            </span>
          </span>
          {item.totalAvailableQty > 0 && (
            <span className="font-mono text-slate-700 tabular-nums">
              Stock: {item.totalAvailableQty}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {qtyInCart > 0 && earliestValidBatch ? (
            <div className="flex-1 flex items-center justify-between min-h-[44px] rounded-lg bg-[#D4FF3F]/40 border border-lime-500/50 px-1.5">
              <button
                type="button"
                onClick={() =>
                  onUpdateCartQty(
                    product.id,
                    earliestValidBatch.id,
                    qtyInCart - 1
                  )
                }
                className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-md bg-white text-slate-900 border border-slate-200 hover:bg-slate-50 cursor-pointer"
                aria-label="Decrease quantity"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="font-mono text-sm font-bold text-slate-950 tabular-nums">
                {qtyInCart} in list
              </span>
              <button
                type="button"
                onClick={() =>
                  onUpdateCartQty(
                    product.id,
                    earliestValidBatch.id,
                    qtyInCart + 1
                  )
                }
                className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-md bg-white text-slate-900 border border-slate-200 hover:bg-slate-50 cursor-pointer"
                aria-label="Increase quantity"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => onAddToCart(item)}
              className="flex-1 min-h-[44px] px-3 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs sm:text-sm font-bold hover:brightness-95 active:scale-[0.99] transition flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>Add to Enquiry</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => onToggleCompare(product.id)}
            className={`min-h-[44px] min-w-[44px] px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer ${
              isCompared
                ? 'bg-[#CBB3E8] border-[#CBB3E8] text-slate-950'
                : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
            }`}
            title={isCompared ? 'Remove from comparison' : 'Compare medicine'}
            aria-label="Compare medicine"
          >
            {isCompared ? (
              <Check className="w-4 h-4" />
            ) : (
              <GitCompareArrows className="w-4 h-4" />
            )}
            <span className="hidden sm:inline">
              {isCompared ? 'Added' : 'Compare'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => onOpenDetails(item)}
            className="min-h-[44px] px-3 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs font-semibold hover:bg-slate-50 flex items-center justify-center gap-1 whitespace-nowrap cursor-pointer"
          >
            <span>Details</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </article>
  );
};
