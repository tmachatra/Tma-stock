import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Filter, Search, Tag, X } from 'lucide-react';
import {
  fuzzySearchProducts,
  getActiveSchemeInfo,
  hasActiveDealOrScheme,
} from '../lib/pharmaUtils';
import type { AvailabilityStatus, ProductWithBatches } from '../types/pharma';
import { ProductCard } from './ProductCard';

interface CatalogSearchViewProps {
  products: ProductWithBatches[];
  initialQuery: string;
  onQueryChange: (q: string) => void;
  dealsOnly?: boolean;
  onDealsOnlyChange?: (val: boolean) => void;
  cartQuantities: Record<string, number>;
  compareIds: string[];
  onAddToCart: (item: ProductWithBatches) => void;
  onUpdateCartQty: (productId: string, batchId: string, qty: number) => void;
  onToggleCompare: (productId: string) => void;
  onOpenDetails: (item: ProductWithBatches) => void;
  onSearchTracked?: (query: string, resultCount: number) => void;
}

export const CatalogSearchView: React.FC<CatalogSearchViewProps> = ({
  products,
  initialQuery,
  onQueryChange,
  dealsOnly: controlledDealsOnly,
  onDealsOnlyChange,
  cartQuantities,
  compareIds,
  onAddToCart,
  onUpdateCartQty,
  onToggleCompare,
  onOpenDetails,
  onSearchTracked,
}) => {
  const lastTrackedSearchRef = useRef<string>('');
  const [availabilityFilter, setAvailabilityFilter] = useState<
    'ALL' | AvailabilityStatus
  >('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [internalDealsOnly, setInternalDealsOnly] = useState(false);
  const dealsOnly =
    controlledDealsOnly !== undefined ? controlledDealsOnly : internalDealsOnly;
  const setDealsOnly = (next: boolean) => {
    if (onDealsOnlyChange) {
      onDealsOnlyChange(next);
    } else {
      setInternalDealsOnly(next);
    }
  };
  const [dealAdjustFilter, setDealAdjustFilter] = useState<
    'ALL' | 'ADJUSTABLE' | 'NON_ADJUSTABLE'
  >('ALL');
  const [sortBy, setSortBy] = useState<
    'relevance' | 'rate_asc' | 'expiry_asc' | 'name_asc'
  >('relevance');
  const [showSuggestions, setShowSuggestions] = useState(false);

  const categories = useMemo(() => {
    const set = new Set<string>();
    for (const p of products) {
      if (p.product.category) set.add(p.product.category);
    }
    return ['ALL', ...Array.from(set).sort()];
  }, [products]);

  const searchHits = useMemo(
    () => fuzzySearchProducts(products, initialQuery),
    [products, initialQuery]
  );

  const liveSuggestions = useMemo(() => {
    if (!initialQuery.trim() || !showSuggestions) return [];
    return searchHits.slice(0, 6);
  }, [searchHits, initialQuery, showSuggestions]);

  const filteredItems = useMemo(() => {
    let list = searchHits.map((h) => h.item);

    if (availabilityFilter !== 'ALL') {
      list = list.filter((i) => i.availabilityStatus === availabilityFilter);
    }
    if (categoryFilter !== 'ALL') {
      list = list.filter((i) => i.product.category === categoryFilter);
    }
    if (dealsOnly) {
      list = list.filter((i) => hasActiveDealOrScheme(i));
    }
    if (dealAdjustFilter === 'ADJUSTABLE') {
      list = list.filter((i) => {
        const info = getActiveSchemeInfo(i);
        return !!info.schemeDetails && info.dealRateAdjustable;
      });
    } else if (dealAdjustFilter === 'NON_ADJUSTABLE') {
      list = list.filter((i) => {
        const info = getActiveSchemeInfo(i);
        return !!info.schemeDetails && !info.dealRateAdjustable;
      });
    }

    if (sortBy === 'rate_asc') {
      list = [...list].sort(
        (a, b) =>
          (a.effectiveWholesaleRate || 999999) -
          (b.effectiveWholesaleRate || 999999)
      );
    } else if (sortBy === 'expiry_asc') {
      list = [...list].sort((a, b) =>
        (a.earliestExpiryIso || '9999-99').localeCompare(
          b.earliestExpiryIso || '9999-99'
        )
      );
    } else if (sortBy === 'name_asc') {
      list = [...list].sort((a, b) =>
        a.product.name.localeCompare(b.product.name)
      );
    }

    return list;
  }, [
    searchHits,
    availabilityFilter,
    categoryFilter,
    dealsOnly,
    dealAdjustFilter,
    sortBy,
  ]);

  useEffect(() => {
    if (!onSearchTracked || products.length === 0) return;
    const trimmed = initialQuery.trim();
    if (trimmed.length < 2) return;
    const key = `${trimmed.toLowerCase()}::${searchHits.length}`;
    if (lastTrackedSearchRef.current === key) return;
    const timer = setTimeout(() => {
      lastTrackedSearchRef.current = key;
      onSearchTracked(trimmed, searchHits.length);
    }, 1200);
    return () => clearTimeout(timer);
  }, [initialQuery, searchHits.length, products.length, onSearchTracked]);

  return (
    <div className="space-y-5 pb-24 md:pb-12">
      {/* Search Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="relative">
          <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={initialQuery}
            onFocus={() => setShowSuggestions(true)}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 180)}
            onChange={(e) => {
              onQueryChange(e.target.value);
              setShowSuggestions(true);
            }}
            placeholder="Search brand, generic salt, composition, company or code..."
            className="w-full min-h-[48px] pl-11 pr-10 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-950 text-sm sm:text-base font-medium focus:outline-none focus:ring-2 focus:ring-[#CBB3E8] focus:bg-white"
          />
          {initialQuery && (
            <button
              type="button"
              onClick={() => onQueryChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-slate-500 hover:bg-slate-200 cursor-pointer"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}

          {liveSuggestions.length > 0 && (
            <div className="absolute left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-lg z-20 divide-y divide-slate-100 overflow-hidden">
              {liveSuggestions.map((hit) => (
                <button
                  key={hit.item.product.id}
                  type="button"
                  onMouseDown={() => {
                    onQueryChange(hit.item.product.name);
                    setShowSuggestions(false);
                  }}
                  className="w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center justify-between gap-3 cursor-pointer"
                >
                  <div className="min-w-0 flex items-center gap-2.5">
                    {hit.item.product.imageUrl && (
                      <img
                        src={hit.item.product.imageUrl}
                        alt={hit.item.product.name}
                        className="w-9 h-9 rounded-lg border border-slate-200 bg-white object-contain shrink-0"
                      />
                    )}
                    <div className="min-w-0 truncate">
                      <span className="text-sm font-bold text-slate-900">
                        {hit.item.product.name}
                      </span>
                      <span className="ml-2 text-xs text-slate-500">
                        {hit.item.product.genericName} ·{' '}
                        {hit.item.product.manufacturer}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-900 shrink-0">
                    ₹{hit.item.effectiveWholesaleRate.toFixed(2)}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Filter & Sort Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 mr-1">
            <Filter className="w-3.5 h-3.5" />
            <span>Filters:</span>
          </div>

          <select
            value={availabilityFilter}
            onChange={(e) =>
              setAvailabilityFilter(e.target.value as 'ALL' | AvailabilityStatus)
            }
            aria-label="Filter by availability"
            className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-800"
          >
            <option value="ALL">All Stock Status</option>
            <option value="IN STOCK">IN STOCK</option>
            <option value="LOW STOCK">LOW STOCK</option>
            <option value="OUT OF STOCK">OUT OF STOCK</option>
            <option value="CONFIRM AVAILABILITY">CONFIRM AVAILABILITY</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            aria-label="Filter by category"
            className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-800"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat === 'ALL' ? 'All Categories' : cat}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => {
              const next = !dealsOnly;
              setDealsOnly(next);
              if (!next) setDealAdjustFilter('ALL');
            }}
            className={`min-h-[40px] px-3 py-1.5 rounded-lg border text-xs font-semibold transition cursor-pointer ${
              dealsOnly
                ? 'bg-[#CBB3E8] border-[#CBB3E8] text-slate-950'
                : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Deals / Schemes Only
          </button>

          <select
            value={dealAdjustFilter}
            onChange={(e) =>
              setDealAdjustFilter(
                e.target.value as 'ALL' | 'ADJUSTABLE' | 'NON_ADJUSTABLE'
              )
            }
            aria-label="Filter by deal rate adjustability"
            className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-800"
          >
            <option value="ALL">All Deal Types</option>
            <option value="ADJUSTABLE">Rate Adjustable Deals</option>
            <option value="NON_ADJUSTABLE">Not Adjustable in Rate</option>
          </select>

          <select
            value={sortBy}
            onChange={(e) =>
              setSortBy(
                e.target.value as
                  | 'relevance'
                  | 'rate_asc'
                  | 'expiry_asc'
                  | 'name_asc'
              )
            }
            aria-label="Sort results"
            className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-800 ml-auto"
          >
            <option value="relevance">Sort: Best Match</option>
            <option value="name_asc">Sort: Name (A–Z)</option>
            <option value="rate_asc">Sort: Lowest Wholesale Rate</option>
            <option value="expiry_asc">Sort: Earliest Expiry</option>
          </select>
        </div>
      </div>

      {/* Active Deals, Schemes, Free Quantity & Bonus Offers Banner */}
      {dealsOnly && (
        <div className="bg-[#CBB3E8]/30 border border-[#CBB3E8] rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-slate-950 text-[#D4FF3F] shrink-0">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-display text-base sm:text-lg font-bold text-slate-950">
                Active Deals, Schemes, Free Quantity &amp; Bonus Offers
              </h1>
              <p className="text-xs sm:text-sm text-slate-700 mt-0.5">
                Showing <strong className="text-slate-950 tabular-nums">{filteredItems.length}</strong>{' '}
                medicines. <strong className="text-slate-950">Adjustable in Rate</strong> deals (e.g. Monocef) convert into net unit rates, while{' '}
                <strong className="text-[#B91C1C]">Not Adjustable in Rate</strong> deals (e.g. Panderm++ Oint) apply on full slab quantities only.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setDealsOnly(false);
              setDealAdjustFilter('ALL');
            }}
            className="min-h-[40px] px-4 py-1.5 rounded-lg bg-white border border-slate-300 text-xs font-bold text-slate-900 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Show All Medicines
          </button>
        </div>
      )}

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-600 px-1">
        <span className="tabular-nums">
          Showing <strong className="text-slate-900">{filteredItems.length}</strong>{' '}
          {filteredItems.length === 1 ? 'medicine' : 'medicines'}
          {initialQuery ? ` for "${initialQuery}"` : ''}
        </span>
        {(availabilityFilter !== 'ALL' ||
          categoryFilter !== 'ALL' ||
          dealsOnly ||
          dealAdjustFilter !== 'ALL' ||
          initialQuery) && (
          <button
            type="button"
            onClick={() => {
              onQueryChange('');
              setAvailabilityFilter('ALL');
              setCategoryFilter('ALL');
              setDealsOnly(false);
              setDealAdjustFilter('ALL');
            }}
            className="font-semibold text-slate-900 hover:underline cursor-pointer"
          >
            Reset filters
          </button>
        )}
      </div>

      {/* Results Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center">
          <p className="text-base font-bold text-slate-900">
            No matching medicines found
          </p>
          <p className="mt-1 text-sm text-slate-600">
            Try searching by generic salt name, company name, or partial brand spelling.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map((item) => (
            <ProductCard
              key={item.product.id}
              item={item}
              qtyInCart={cartQuantities[item.product.id] || 0}
              isCompared={compareIds.includes(item.product.id)}
              onAddToCart={onAddToCart}
              onUpdateCartQty={onUpdateCartQty}
              onToggleCompare={onToggleCompare}
              onOpenDetails={onOpenDetails}
            />
          ))}
        </div>
      )}
    </div>
  );
};
