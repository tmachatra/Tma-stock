import React, { useState } from 'react';
import { Check, Copy, Download, ExternalLink, Share, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ variant?: 'compact' | 'banner' }> = ({
  variant = 'compact',
}) => {
  const { isInstallable, isInstalled, isIOS, isInAppBrowser, install } =
    usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copied, setCopied] = useState(false);

  if (isInstalled) return null;

  const appUrl =
    typeof window !== 'undefined' ? window.location.origin : '';

  const handleCopyUrl = async () => {
    if (!appUrl) return;
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Ignore clipboard errors
    }
  };

  const handlePrimaryClick = async () => {
    if (isInstallable) {
      const ok = await install();
      if (ok) return;
    }
    setShowGuide(true);
  };

  return (
    <>
      <button
        type="button"
        onClick={handlePrimaryClick}
        className={
          variant === 'banner'
            ? 'inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-sm font-semibold hover:brightness-95 transition whitespace-nowrap shrink-0 cursor-pointer'
            : 'inline-flex items-center gap-1.5 min-h-[40px] px-3 py-1.5 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 transition whitespace-nowrap shrink-0 cursor-pointer'
        }
      >
        {isIOS ? (
          <Share className="w-3.5 h-3.5" />
        ) : isInstallable ? (
          <Download className="w-3.5 h-3.5" />
        ) : (
          <Smartphone className="w-3.5 h-3.5" />
        )}
        <span>
          {isInstallable ? 'Install Android App' : 'Get Android App'}
        </span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Install Tara Medical Mobile App"
        >
          <div className="w-full max-w-md rounded-2xl bg-white p-6 border border-slate-200 shadow-xl space-y-4 text-slate-900">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs font-bold text-[#B91C1C]">
                  Tara Medical Agency · Mobile App
                </div>
                <h3 className="mt-0.5 font-display text-lg font-bold text-slate-950">
                  {isIOS
                    ? 'Install on iPhone / iPad'
                    : 'Install as Android App'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
                aria-label="Close install instructions"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <ol className="space-y-2.5 text-sm text-slate-700 list-decimal list-inside">
                <li>
                  Open this portal in <strong>Safari</strong>.
                </li>
                <li>
                  Tap the <strong>Share</strong> button in Safari&apos;s toolbar.
                </li>
                <li>
                  Scroll down and tap <strong>Add to Home Screen</strong>.
                </li>
                <li>
                  Launch <strong>Tara Medical</strong> directly from your home screen.
                </li>
              </ol>
            ) : (
              <div className="space-y-3">
                {isInAppBrowser && (
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
                    You appear to be inside an in-app browser (such as WhatsApp). Copy or open the link in <strong>Google Chrome</strong> first to install the Android app.
                  </div>
                )}

                <ol className="space-y-2 text-sm text-slate-700 list-decimal list-inside">
                  <li>
                    Open this link in <strong>Google Chrome</strong> on your Android phone.
                  </li>
                  <li>
                    Tap the <strong>⋮ (Menu)</strong> icon at the top-right of Chrome.
                  </li>
                  <li>
                    Tap <strong>Install app</strong> (or <strong>Add to Home screen → Install</strong>).
                  </li>
                  <li>
                    <strong>Tara Medical</strong> installs to your Android Home Screen &amp; App Drawer with full-screen view and offline support.
                  </li>
                </ol>

                {appUrl && (
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                    <div className="text-[11px] font-semibold text-slate-500">
                      Portal Link for Android Chrome
                    </div>
                    <div className="font-mono text-xs text-slate-800 break-all">
                      {appUrl}
                    </div>
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleCopyUrl}
                        className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 cursor-pointer"
                      >
                        {copied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-[#D4FF3F]" />
                            <span>Copied Link</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Link</span>
                          </>
                        )}
                      </button>
                      <a
                        href={appUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs font-semibold hover:bg-slate-50"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Open in Browser Tab</span>
                      </a>
                    </div>
                  </div>
                )}
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="w-full min-h-[44px] rounded-xl bg-[#D4FF3F] text-slate-950 text-sm font-bold hover:brightness-95 transition cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </>
  );
};
