import React, { useMemo, useState } from 'react';
import { ArrowLeft, Building2, Search } from 'lucide-react';
import {
  formatDateTimeIST,
  fuzzySearchProducts,
  hasActiveDealOrScheme,
} from '../lib/pharmaUtils';
import type { PharmaCompany, ProductWithBatches } from '../types/pharma';
import { ProductCard } from './ProductCard';

interface CompaniesViewProps {
  companies: PharmaCompany[];
  products: ProductWithBatches[];
  selectedCompanyId: string | null;
  onSelectCompany: (companyId: string | null) => void;
  cartQuantities: Record<string, number>;
  compareIds: string[];
  onAddToCart: (item: ProductWithBatches) => void;
  onUpdateCartQty: (productId: string, batchId: string, qty: number) => void;
  onToggleCompare: (productId: string) => void;
  onOpenDetails: (item: ProductWithBatches) => void;
}

export const CompaniesView: React.FC<CompaniesViewProps> = ({
  companies,
  products,
  selectedCompanyId,
  onSelectCompany,
  cartQuantities,
  compareIds,
  onAddToCart,
  onUpdateCartQty,
  onToggleCompare,
  onOpenDetails,
}) => {
  const [companySearch, setCompanySearch] = useState('');
  const [catalogSearch, setCatalogSearch] = useState('');

  const companySummaries = useMemo(() => {
    return companies
      .filter((c) => c.active)
      .map((c) => {
        const items = products.filter((p) => p.product.companyId === c.id);
        const inStock = items.filter(
          (i) => i.availabilityStatus === 'IN STOCK'
        ).length;
        const deals = items.filter((i) => hasActiveDealOrScheme(i)).length;
        let lastUpdated: Date | null = null;
        for (const i of items) {
          if (
            i.latestUpdatedAt &&
            (!lastUpdated || i.latestUpdatedAt > lastUpdated)
          ) {
            lastUpdated = i.latestUpdatedAt;
          }
        }
        return { company: c, total: items.length, inStock, deals, lastUpdated };
      })
      .filter((entry) => {
        if (!companySearch.trim()) return true;
        const q = companySearch.toLowerCase();
        return (
          entry.company.name.toLowerCase().includes(q) ||
          entry.company.shortCode.toLowerCase().includes(q)
        );
      });
  }, [companies, products, companySearch]);

  const selectedCompany = useMemo(
    () => companies.find((c) => c.id === selectedCompanyId) || null,
    [companies, selectedCompanyId]
  );

  const companyProducts = useMemo(() => {
    if (!selectedCompanyId) return [];
    const base = products.filter(
      (p) => p.product.companyId === selectedCompanyId
    );
    if (!catalogSearch.trim()) return base;
    return fuzzySearchProducts(base, catalogSearch).map((h) => h.item);
  }, [products, selectedCompanyId, catalogSearch]);

  if (selectedCompany) {
    return (
      <div className="space-y-5 pb-24 md:pb-12">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6">
          <button
            type="button"
            onClick={() => {
              onSelectCompany(null);
              setCatalogSearch('');
            }}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-800 hover:bg-slate-50 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>All Pharmaceutical Companies</span>
          </button>

          <div className="mt-4 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="font-mono text-xs font-semibold text-slate-500">
                {selectedCompany.shortCode} · Company Catalogue
              </div>
              <h1 className="mt-1 font-display text-2xl sm:text-3xl font-extrabold text-slate-950">
                {selectedCompany.name}
              </h1>
            </div>

            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={catalogSearch}
                onChange={(e) => setCatalogSearch(e.target.value)}
                placeholder={`Search ${selectedCompany.shortCode} products...`}
                className="w-full min-h-[44px] pl-9 pr-3 py-2 rounded-xl border border-slate-300 bg-slate-50 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#CBB3E8] focus:bg-white"
              />
            </div>
          </div>
        </div>

        {companyProducts.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center">
            <p className="text-sm font-semibold text-slate-800">
              No products found under {selectedCompany.name}.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {companyProducts.map((item) => (
              <ProductCard
                key={item.product.id}
                item={item}
                qtyInCart={cartQuantities[item.product.id] || 0}
                isCompared={compareIds.includes(item.product.id)}
                onAddToCart={onAddToCart}
                onUpdateCartQty={onUpdateCartQty}
                onToggleCompare={onToggleCompare}
                onOpenDetails={onOpenDetails}
              />
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-5 pb-24 md:pb-12">
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-950 flex items-center gap-2.5">
            <Building2 className="w-6 h-6" />
            <span>Company-Wise Catalogue</span>
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Select a pharmaceutical manufacturer to inspect its available products, rates, and deals.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={companySearch}
            onChange={(e) => setCompanySearch(e.target.value)}
            placeholder="Filter company name..."
            className="w-full min-h-[44px] pl-9 pr-3 py-2 rounded-xl border border-slate-300 bg-slate-50 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#CBB3E8] focus:bg-white"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {companySummaries.map(({ company, total, inStock, deals, lastUpdated }) => (
          <button
            key={company.id}
            type="button"
            onClick={() => onSelectCompany(company.id)}
            className="bg-white border border-slate-200 rounded-xl p-5 text-left hover:border-slate-900 transition cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-xs font-bold text-slate-500">
                  {company.shortCode}
                </span>
                {deals > 0 && (
                  <span className="px-2 py-0.5 rounded bg-[#CBB3E8]/50 text-slate-950 font-mono text-[11px] font-bold">
                    {deals} {deals === 1 ? 'deal' : 'deals'}
                  </span>
                )}
              </div>
              <h2 className="mt-1.5 font-display text-lg font-bold text-slate-950">
                {company.name}
              </h2>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
              <span className="tabular-nums">
                <strong className="text-slate-900">{total}</strong> products ·{' '}
                <strong className="text-slate-900">{inStock}</strong> in stock
              </span>
              <span className="font-mono text-[11px] text-slate-500">
                {lastUpdated ? formatDateTimeIST(lastUpdated) : '—'}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
