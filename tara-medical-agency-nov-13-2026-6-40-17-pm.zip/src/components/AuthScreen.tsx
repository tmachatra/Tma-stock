import React, { useState } from 'react';
import {
  Eye,
  EyeOff,
  KeyRound,
  LogOut,
  Menu,
  MessageCircle,
  Phone,
  ShieldAlert,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  AGENCY_DISPLAY_PHONE,
  AGENCY_WHATSAPP_NUMBER,
  normalizeCodeId,
} from '../lib/firebase';
import { PWAInstallButton } from './PWAInstallButton';

export const AuthScreen: React.FC = () => {
  const {
    user,
    retailer,
    isAdmin,
    authLoading,
    authError,
    signInAdminWithIdPassword,
    signInRetailerWithIdPassword,
    signOutUser,
  } = useAuth();

  const [loginTab, setLoginTab] = useState<'retailer' | 'admin'>('retailer');

  // Retailer login fields
  const [retailerIdInput, setRetailerIdInput] = useState('');
  const [retailerPasswordInput, setRetailerPasswordInput] = useState('');
  const [showRetailerPassword, setShowRetailerPassword] = useState(false);

  // Admin login fields
  const [adminIdInput, setAdminIdInput] = useState('');
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [showOverviewMenu, setShowOverviewMenu] = useState(false);

  const handleRetailerLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await signInRetailerWithIdPassword(retailerIdInput, retailerPasswordInput);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await signInAdminWithIdPassword(adminIdInput, adminPasswordInput);
    } finally {
      setSubmitting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-8 text-center">
          <div className="w-10 h-10 mx-auto rounded-lg bg-[#CBB3E8] animate-pulse" />
          <p className="mt-4 text-sm font-medium text-slate-600">
            Verifying your Tara Medical Agency account...
          </p>
        </div>
      </div>
    );
  }

  // Signed in as non-admin retailer whose account is deactivated or pending
  if (user && !isAdmin && (!retailer || retailer.status !== 'active')) {
    const isDeactivated = retailer?.status === 'deactivated';
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center gap-3 text-[#E34234]">
            <ShieldAlert className="w-6 h-6 shrink-0" />
            <h1 className="text-xl font-bold text-slate-900">
              {isDeactivated
                ? 'Retailer Account Deactivated'
                : 'Account Pending Activation'}
            </h1>
          </div>
          <p className="mt-3 text-sm text-slate-600 leading-relaxed">
            {isDeactivated
              ? `Retailer access for ${retailer?.shopName} (${retailer?.retailerId}) is currently deactivated by Tara Medical Agency.`
              : 'Your retailer profile is not currently active. Please contact Tara Medical Agency to activate your Retailer ID.'}
          </p>
          <div className="mt-5 p-4 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-700 space-y-1">
            <div className="font-semibold text-slate-900">Tara Medical Agency</div>
            <div>Jatrahibag, Chatra, Jharkhand</div>
            <div className="font-mono text-xs text-slate-600">
              Phone / WhatsApp: {AGENCY_DISPLAY_PHONE}
            </div>
          </div>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <a
              href={`https://wa.me/${AGENCY_WHATSAPP_NUMBER}?text=${encodeURIComponent(
                `Hello Tara Medical Agency, please assist with my retailer login${
                  retailer?.retailerId ? ` (ID: ${retailer.retailerId})` : ''
                }.`
              )}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-sm font-semibold hover:brightness-95 transition"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Contact on WhatsApp</span>
            </a>
            <button
              type="button"
              onClick={signOutUser}
              className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 bg-white text-slate-700 text-sm font-medium hover:bg-slate-50 transition cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Unauthenticated Login Screen — Simple ID + Password for BOTH Retailer & Admin
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      <header className="bg-white border-b border-slate-200 px-4 sm:px-8 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setShowOverviewMenu(true)}
              aria-label="Open agency overview menu"
              aria-expanded={showOverviewMenu}
              className="inline-flex items-center justify-center min-h-[40px] min-w-[40px] rounded-lg border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 shrink-0 cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <img
              src="/icon.svg"
              alt="Tara Medical Agency emblem"
              className="w-9 h-9 rounded-lg shrink-0"
            />
            <span className="font-display text-base sm:text-lg font-bold text-slate-900 truncate">
              Tara Medical Agency
            </span>
          </div>
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <PWAInstallButton />
            <a
              href={`tel:${AGENCY_WHATSAPP_NUMBER}`}
              className="inline-flex items-center gap-1.5 min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs font-semibold hover:bg-slate-50 whitespace-nowrap"
            >
              <Phone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{AGENCY_DISPLAY_PHONE}</span>
            </a>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-start justify-center px-4 pt-5 pb-10 sm:pt-8 sm:pb-14">
        <div className="w-full max-w-md">
          {/* Separate Retailer vs Admin ID+Password Login Panel */}
          <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              {/* Portal Switcher Tabs */}
              <div className="grid grid-cols-2 gap-1 p-1 bg-slate-800 rounded-xl">
                <button
                  type="button"
                  onClick={() => setLoginTab('retailer')}
                  className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    loginTab === 'retailer'
                      ? 'bg-[#D4FF3F] text-slate-950'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Retailer Login</span>
                </button>
                <button
                  type="button"
                  onClick={() => setLoginTab('admin')}
                  className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    loginTab === 'admin'
                      ? 'bg-[#CBB3E8] text-slate-950'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Admin Login</span>
                </button>
              </div>

              {loginTab === 'retailer' ? (
                <div className="mt-6">
                  <h2 className="text-xl font-bold text-white">
                    Retailer Portal Sign In
                  </h2>
                  <p className="mt-1.5 text-xs text-slate-300 leading-relaxed">
                    Enter the Unique Retailer ID and password given to you by Tara Medical Agency.
                  </p>

                  <form onSubmit={handleRetailerLogin} className="mt-5 space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Unique Retailer ID
                      </label>
                      <input
                        type="text"
                        required
                        autoCapitalize="characters"
                        value={retailerIdInput}
                        onChange={(e) =>
                          setRetailerIdInput(normalizeCodeId(e.target.value))
                        }
                        placeholder="e.g. TMA-101"
                        className="w-full min-h-[46px] px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#D4FF3F]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Password
                      </label>
                      <div className="relative">
                        <input
                          type={showRetailerPassword ? 'text' : 'password'}
                          required
                          value={retailerPasswordInput}
                          onChange={(e) =>
                            setRetailerPasswordInput(e.target.value)
                          }
                          placeholder="Enter your password"
                          className="w-full min-h-[46px] pl-3.5 pr-11 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#D4FF3F]"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setShowRetailerPassword(!showRetailerPassword)
                          }
                          className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-white cursor-pointer"
                          aria-label={
                            showRetailerPassword
                              ? 'Hide password'
                              : 'Show password'
                          }
                        >
                          {showRetailerPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    {authError && (
                      <div className="p-3 rounded-lg bg-[#E34234]/20 border border-[#E34234] text-xs text-red-100 leading-relaxed">
                        {authError}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#D4FF3F] text-slate-950 font-bold text-sm hover:brightness-95 active:scale-[0.99] transition disabled:opacity-60 cursor-pointer"
                    >
                      {submitting ? 'Signing In...' : 'Sign In as Retailer'}
                    </button>
                  </form>

                  <div className="mt-5 pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-2">
                    <p>
                      Don&apos;t have a Retailer ID yet or forgot your password? Request credentials from Tara Medical Agency:
                    </p>
                    <a
                      href={`https://wa.me/${AGENCY_WHATSAPP_NUMBER}?text=${encodeURIComponent(
                        'Hello Tara Medical Agency, please create or reset my Retailer ID and Password for the wholesale portal.'
                      )}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 text-[#D4FF3F] font-semibold hover:underline"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Request ID on WhatsApp ({AGENCY_DISPLAY_PHONE})</span>
                    </a>
                  </div>
                </div>
              ) : (
                <div className="mt-6">
                  <h2 className="text-xl font-bold text-white">
                    Admin Console Sign In
                  </h2>
                  <p className="mt-1.5 text-xs text-slate-300 leading-relaxed">
                    Sign in with your Admin ID and password to manage medicine inventory, batches, Excel imports, and retailer IDs.
                  </p>

                  <form onSubmit={handleAdminLogin} className="mt-5 space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Admin ID
                      </label>
                      <input
                        type="text"
                        required
                        autoCapitalize="characters"
                        value={adminIdInput}
                        onChange={(e) =>
                          setAdminIdInput(normalizeCodeId(e.target.value))
                        }
                        placeholder="e.g. TMA-ADMIN"
                        className="w-full min-h-[46px] px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#CBB3E8]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Password
                      </label>
                      <div className="relative">
                        <input
                          type={showAdminPassword ? 'text' : 'password'}
                          required
                          value={adminPasswordInput}
                          onChange={(e) =>
                            setAdminPasswordInput(e.target.value)
                          }
                          placeholder="Enter admin password"
                          className="w-full min-h-[46px] pl-3.5 pr-11 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#CBB3E8]"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setShowAdminPassword(!showAdminPassword)
                          }
                          className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-white cursor-pointer"
                          aria-label={
                            showAdminPassword ? 'Hide password' : 'Show password'
                          }
                        >
                          {showAdminPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    {authError && (
                      <div className="p-3 rounded-lg bg-[#E34234]/20 border border-[#E34234] text-xs text-red-100 leading-relaxed">
                        {authError}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#CBB3E8] text-slate-950 font-bold text-sm hover:brightness-95 active:scale-[0.99] transition disabled:opacity-60 cursor-pointer"
                    >
                      {submitting ? 'Signing In...' : 'Sign In as Admin'}
                    </button>
                  </form>
                </div>
              )}
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-0.5">
              <div className="font-semibold text-slate-200">
                Tara Medical Agency · Chatra
              </div>
              <div>Jatrahibag, Near Laklakwanath Mandir PO+PS Chatra</div>
              <div className="font-mono">DL: JH-CHA-162713/162714</div>
            </div>
          </div>
        </div>
      </main>

      {showOverviewMenu && (
        <div
          className="fixed inset-0 z-50 flex"
          role="dialog"
          aria-modal="true"
          aria-label="Tara Medical Agency Overview"
        >
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
            onClick={() => setShowOverviewMenu(false)}
          />
          <aside className="relative z-10 w-full max-w-md bg-white h-full overflow-y-auto shadow-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-200">
                <div className="flex items-center gap-2.5">
                  <img
                    src="/icon.svg"
                    alt="Tara Medical Agency emblem"
                    className="w-8 h-8 rounded-lg"
                  />
                  <span className="font-display text-base font-bold text-slate-950">
                    Tara Medical Agency
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowOverviewMenu(false)}
                  aria-label="Close menu"
                  className="inline-flex items-center justify-center min-h-[40px] min-w-[40px] rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-6">
                <p className="text-xs font-semibold text-slate-600">
                  Chatra, Jharkhand · Wholesale Allopathic Distributor
                </p>
                <h2 className="mt-2.5 text-2xl font-extrabold text-slate-900 tracking-tight text-balance">
                  Check medicine availability, wholesale rates, deals, and expiry in seconds.
                </h2>
                <p className="mt-3 text-sm text-slate-600 leading-relaxed">
                  Built exclusively for approved retail pharmacies and medical
                  practitioners supplied by Tara Medical Agency. Sign in with the
                  Unique ID and password assigned by our office.
                </p>
              </div>

              <div className="mt-6 space-y-4 pt-6 border-t border-slate-200">
                <div>
                  <div className="text-xs font-semibold text-slate-500">Step 1</div>
                  <div className="mt-0.5 text-sm font-bold text-slate-900">
                    Instant Discovery
                  </div>
                  <p className="mt-1 text-xs text-slate-600">
                    Search by brand, salt, composition, or pharma company.
                  </p>
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-500">Step 2</div>
                  <div className="mt-0.5 text-sm font-bold text-slate-900">
                    WhatsApp Enquiry
                  </div>
                  <p className="mt-1 text-xs text-slate-600">
                    Share your shortlist directly for rate &amp; stock confirmation.
                  </p>
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-500">Step 3</div>
                  <div className="mt-0.5 text-sm font-bold text-slate-900">
                    Scheduled Delivery
                  </div>
                  <p className="mt-1 text-xs text-slate-600">
                    Confirmed orders are dispatched on the next delivery cycle.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-5 border-t border-slate-200 space-y-3 text-xs text-slate-600">
              <div>
                <div className="font-bold text-slate-900">Tara Medical Agency</div>
                <div>Jatrahibag, Near Laklakwanath Mandir PO+PS Chatra, Jharkhand</div>
                <div className="font-mono mt-0.5">
                  DL: JH-CHA-162713/162714 · GSTIN: 20EGTPR3395L1ZM
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <a
                  href={`tel:${AGENCY_WHATSAPP_NUMBER}`}
                  className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-slate-900 font-semibold hover:bg-slate-50"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{AGENCY_DISPLAY_PHONE}</span>
                </a>
                <a
                  href={`https://wa.me/${AGENCY_WHATSAPP_NUMBER}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 font-bold hover:brightness-95"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp Desk</span>
                </a>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
};
