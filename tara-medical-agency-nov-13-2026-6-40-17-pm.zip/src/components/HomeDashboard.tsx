import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  Building2,
  KeyRound,
  MessageCircle,
  Search,
  Sparkles,
  Tag,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AGENCY_DISPLAY_PHONE, AGENCY_WHATSAPP_NUMBER } from '../lib/firebase';
import {
  formatDateTimeIST,
  fuzzySearchProducts,
  hasActiveDealOrScheme,
} from '../lib/pharmaUtils';
import type {
  AppScreen,
  PharmaCompany,
  ProductWithBatches,
} from '../types/pharma';
import { ProductCard } from './ProductCard';

interface HomeDashboardProps {
  products: ProductWithBatches[];
  companies: PharmaCompany[];
  loading: boolean;
  cartQuantities: Record<string, number>;
  compareIds: string[];
  onSearchSubmit: (q: string) => void;
  onNavigate: (screen: AppScreen) => void;
  onOpenDeals: () => void;
  onSelectCompany: (companyId: string) => void;
  onAddToCart: (item: ProductWithBatches) => void;
  onUpdateCartQty: (productId: string, batchId: string, qty: number) => void;
  onToggleCompare: (productId: string) => void;
  onOpenDetails: (item: ProductWithBatches) => void;
  onOpenAccountSettings: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  products,
  companies,
  loading,
  cartQuantities,
  compareIds,
  onSearchSubmit,
  onNavigate,
  onOpenDeals,
  onSelectCompany,
  onAddToCart,
  onUpdateCartQty,
  onToggleCompare,
  onOpenDetails,
  onOpenAccountSettings,
}) => {
  const { retailer, user, isAdmin } = useAuth();
  const [quickQuery, setQuickQuery] = useState('');

  const suggestions = useMemo(() => {
    if (!quickQuery.trim()) return [];
    return fuzzySearchProducts(products, quickQuery).slice(0, 6);
  }, [products, quickQuery]);

  const activeDeals = useMemo(
    () =>
      products
        .filter(
          (p) =>
            hasActiveDealOrScheme(p) &&
            p.availabilityStatus !== 'OUT OF STOCK'
        )
        .slice(0, 6),
    [products]
  );

  const inStockCount = useMemo(
    () => products.filter((p) => p.availabilityStatus === 'IN STOCK').length,
    [products]
  );

  const dealCount = useMemo(
    () => products.filter((p) => hasActiveDealOrScheme(p)).length,
    [products]
  );

  const lastCatalogUpdate = useMemo(() => {
    let maxDate: Date | null = null;
    for (const p of products) {
      if (p.latestUpdatedAt && (!maxDate || p.latestUpdatedAt > maxDate)) {
        maxDate = p.latestUpdatedAt;
      }
    }
    return maxDate;
  }, [products]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchSubmit(quickQuery);
  };

  return (
    <div className="space-y-8 pb-24 md:pb-12">
      {/* Prompt retailer to change initial admin-assigned password */}
      {!isAdmin && retailer?.mustChangePassword && (
        <div className="bg-[#CBB3E8]/30 border border-[#CBB3E8] rounded-xl px-4 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs sm:text-sm text-slate-900">
            <span className="font-bold">Security Reminder:</span> You are signed
            in with the initial password assigned for Retailer ID{' '}
            <span className="font-mono font-bold">{retailer.retailerId}</span>.
            Please set your own private password (your Retailer ID remains permanent).
          </div>
          <button
            type="button"
            onClick={onOpenAccountSettings}
            className="inline-flex items-center justify-center gap-1.5 min-h-[40px] px-4 py-1.5 rounded-lg bg-slate-950 text-white text-xs font-bold hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <KeyRound className="w-3.5 h-3.5 text-[#D4FF3F]" />
            <span>Change Password</span>
          </button>
        </div>
      )}

      {/* Hero Search & Welcome Banner */}
      <section className="bg-slate-900 text-white rounded-2xl p-5 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="px-[44px] font-bold text-center font-mono text-[14px] text-[#CBB3E8] uppercase">
              TARA MEDICAL AGENCY. SINCE 2026
            </div>
            <h1 className="mt-2 font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-balance">
              Find stock, wholesale rates, deals &amp; expiry in seconds.
            </h1>
            <p className="mt-2 text-sm text-slate-300">
              Logged in as{' '}
              <strong className="text-white">
                {retailer?.shopName ||
                  (isAdmin
                    ? user?.displayName || 'Administrator'
                    : user?.idCode)}
              </strong>
              {retailer?.retailerId && (
                <>
                  {' · ID: '}
                  <span className="font-mono font-semibold text-[#D4FF3F]">
                    {retailer.retailerId}
                  </span>
                </>
              )}
              {retailer?.city ? ` · ${retailer.city}` : ''}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <a
              href={`https://wa.me/${AGENCY_WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-1.5 rounded-lg bg-slate-800 text-white text-xs font-semibold border border-slate-700 hover:bg-slate-700 whitespace-nowrap"
            >
              <MessageCircle className="w-3.5 h-3.5 text-[#D4FF3F]" />
              <span>Agency WhatsApp ({AGENCY_DISPLAY_PHONE})</span>
            </a>
          </div>
        </div>

        {/* Prominent Search Bar with Live Suggestions */}
        <form onSubmit={handleSubmit} className="mt-6 relative max-w-3xl">
          <div className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={quickQuery}
                onChange={(e) => setQuickQuery(e.target.value)}
                placeholder="Search brand, salt, composition, company or code (e.g. Monocef, Azithromycin, Flexon)..."
                className="w-full min-h-[48px] pl-11 pr-4 py-2.5 rounded-xl bg-white text-slate-950 placeholder:text-slate-400 text-sm sm:text-base font-medium focus:outline-none focus:ring-2 focus:ring-[#D4FF3F]"
              />
            </div>
            <button
              type="submit"
              className="min-h-[48px] px-6 py-2.5 rounded-xl bg-[#D4FF3F] text-slate-950 text-sm font-bold hover:brightness-95 transition whitespace-nowrap cursor-pointer"
            >
              Search Medicines
            </button>
          </div>

          {suggestions.length > 0 && (
            <div className="absolute left-0 right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-xl z-20 divide-y divide-slate-100 overflow-hidden">
              {suggestions.map((hit) => (
                <button
                  key={hit.item.product.id}
                  type="button"
                  onClick={() => onOpenDetails(hit.item)}
                  className="w-full px-4 py-3 text-left hover:bg-slate-50 flex items-center justify-between gap-4 cursor-pointer"
                >
                  <div className="min-w-0 flex items-center gap-2.5">
                    {hit.item.product.imageUrl && (
                      <img
                        src={hit.item.product.imageUrl}
                        alt={hit.item.product.name}
                        className="w-9 h-9 rounded-lg border border-slate-200 bg-white object-contain shrink-0"
                      />
                    )}
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-slate-900 truncate">
                        {hit.item.product.name}{' '}
                        <span className="font-mono text-xs font-normal text-slate-500">
                          ({hit.item.product.packSize})
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 truncate">
                        {hit.item.product.genericName} ·{' '}
                        {hit.item.product.manufacturer}
                      </div>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono text-sm font-bold text-slate-950 tabular-nums">
                      ₹{hit.item.effectiveWholesaleRate.toFixed(2)}
                    </div>
                    <div className="text-[11px] font-mono text-slate-500">
                      Exp {hit.item.earliestExpiryDisplay}
                    </div>
                  </div>
                </button>
              ))}
              <button
                type="button"
                onClick={() => onSearchSubmit(quickQuery)}
                className="w-full px-4 py-2.5 text-left text-xs font-bold text-slate-900 bg-[#CBB3E8]/30 hover:bg-[#CBB3E8]/45 flex items-center justify-between cursor-pointer"
              >
                <span>View all matching results for &ldquo;{quickQuery}&rdquo;</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </form>
      </section>

      {/* 4-Column KPI Summary Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Total Medicines</div>
          <div className="mt-1 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {loading ? '—' : products.length}
          </div>
          <div className="mt-1 text-xs text-slate-600 tabular-nums">
            {inStockCount} currently in stock
          </div>
        </div>

        <div
          role="button"
          tabIndex={0}
          onClick={onOpenDeals}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onOpenDeals();
            }
          }}
          className="bg-white border border-slate-200 rounded-xl p-4 cursor-pointer hover:border-slate-900 hover:bg-[#CBB3E8]/15 transition group focus:outline-none focus:ring-2 focus:ring-[#CBB3E8]"
          aria-label="View all medicines with active deals, schemes, free quantity, and bonus offers"
        >
          <div className="flex items-center justify-between gap-2 text-xs text-slate-600">
            <span>Active Deals &amp; Schemes</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-950 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <div className="mt-1 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {loading ? '—' : dealCount}
          </div>
          <div className="mt-1 text-xs font-medium text-slate-700 group-hover:text-slate-950">
            Free quantity &amp; bonus offers
          </div>
        </div>

        <div
          role="button"
          tabIndex={0}
          onClick={() => {
            onNavigate('companies');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onNavigate('companies');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }}
          className="bg-white border border-slate-200 rounded-xl p-4 cursor-pointer hover:border-slate-900 hover:bg-[#CBB3E8]/15 transition group focus:outline-none focus:ring-2 focus:ring-[#CBB3E8]"
          aria-label="Browse company-wise catalogues"
        >
          <div className="flex items-center justify-between gap-2 text-xs text-slate-600">
            <span>Pharma Companies</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-950 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <div className="mt-1 font-display text-2xl font-bold text-slate-950 tabular-nums">
            {loading ? '—' : companies.length}
          </div>
          <div className="mt-1 text-xs font-medium text-slate-700 group-hover:text-slate-950">
            Browse company-wise catalogues
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Last Catalog Sync</div>
          <div className="mt-1 font-mono text-sm font-bold text-slate-950 tabular-nums">
            {lastCatalogUpdate
              ? formatDateTimeIST(lastCatalogUpdate)
              : 'Waiting for data'}
          </div>
          <div className="mt-1 text-xs text-slate-600">
            Live verified stock &amp; expiry
          </div>
        </div>
      </section>

      {/* Active Deals & Schemes */}
      <section className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-slate-900" />
            <h2 className="font-display text-lg sm:text-xl font-bold text-slate-950">
              Active Wholesale Deals &amp; Schemes
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('search')}
            className="text-xs sm:text-sm font-semibold text-slate-900 hover:underline inline-flex items-center gap-1 cursor-pointer"
          >
            <span>Browse all medicines</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-56 rounded-xl bg-white border border-slate-200 animate-pulse p-5"
              />
            ))}
          </div>
        ) : activeDeals.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
            <Sparkles className="w-6 h-6 text-slate-400 mx-auto" />
            <p className="mt-2 text-sm text-slate-600">
              No scheme items found yet. Browse the full catalog or check with Tara Medical Agency.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeDeals.map((item) => (
              <ProductCard
                key={item.product.id}
                item={item}
                qtyInCart={cartQuantities[item.product.id] || 0}
                isCompared={compareIds.includes(item.product.id)}
                onAddToCart={onAddToCart}
                onUpdateCartQty={onUpdateCartQty}
                onToggleCompare={onToggleCompare}
                onOpenDetails={onOpenDetails}
              />
            ))}
          </div>
        )}
      </section>

      {/* Company-wise Quick Directory */}
      <section className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-slate-900" />
            <h2 className="font-display text-lg sm:text-xl font-bold text-slate-950">
              Browse by Pharmaceutical Company
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('companies')}
            className="text-xs sm:text-sm font-semibold text-slate-900 hover:underline inline-flex items-center gap-1 cursor-pointer"
          >
            <span>All companies</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {companies.slice(0, 12).map((c) => {
            const count = products.filter(
              (p) => p.product.companyId === c.id
            ).length;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => onSelectCompany(c.id)}
                className="bg-white border border-slate-200 rounded-xl p-3.5 text-left hover:border-slate-900 transition cursor-pointer"
              >
                <div className="font-mono text-xs font-bold text-slate-500">
                  {c.shortCode}
                </div>
                <div className="mt-1 text-sm font-bold text-slate-900 truncate">
                  {c.name}
                </div>
                <div className="mt-1.5 text-xs text-slate-600 tabular-nums">
                  {count} {count === 1 ? 'item' : 'items'}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Quiet Agency Footer */}
      <footer className="pt-6 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <strong className="text-slate-700">Tara Medical Agency</strong> ·
          Jatrahibag, Near Laklakwanath Mandir PO+PS Chatra, Jharkhand
        </div>
        <div className="font-mono">
          DL: JH-CHA-162713/162714 · GSTIN: 20EGTPR3395L1ZM
        </div>
      </footer>
    </div>
  );
};
