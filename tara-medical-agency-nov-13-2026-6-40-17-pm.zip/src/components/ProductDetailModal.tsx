import React, { useState } from 'react';
import {
  GitCompareArrows,
  Layers,
  Plus,
  X,
  ZoomIn,
} from 'lucide-react';
import {
  computeBatchAvailability,
  computeEffectiveSchemeRate,
  formatDateTimeIST,
  formatINR,
  formatSchemeOfferLabel,
  getActiveSchemeInfo,
  isBatchExpired,
  isDealRateAdjustable,
  isExpiringSoon,
} from '../lib/pharmaUtils';
import type { MedicineBatch, ProductWithBatches } from '../types/pharma';
import { StatusTag } from './StatusTag';

interface ProductDetailModalProps {
  item: ProductWithBatches | null;
  onClose: () => void;
  onAddBatchToEnquiry: (item: ProductWithBatches, batch: MedicineBatch | null) => void;
  onCompareSameSalt: (item: ProductWithBatches) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  item,
  onClose,
  onAddBatchToEnquiry,
  onCompareSameSalt,
}) => {
  const [zoomImage, setZoomImage] = useState(false);
  if (!item) return null;
  const { product, batches } = item;
  const { schemeDetails: activeScheme, dealRateAdjustable } =
    getActiveSchemeInfo(item);
  const schemeOfferLabel = formatSchemeOfferLabel(activeScheme);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={product.name}
    >
      <div className="w-full max-w-3xl max-h-[92vh] bg-white rounded-t-3xl sm:rounded-2xl border border-slate-200 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
              <span className="font-semibold text-slate-900">
                {product.manufacturer}
              </span>
              <span aria-hidden="true">·</span>
              <span>{product.category}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">Pack {product.packSize}</span>
              {product.hsnCode && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">HSN {product.hsnCode}</span>
                </>
              )}
            </div>
            <h2 className="mt-1 font-display text-xl sm:text-2xl font-bold text-slate-950">
              {product.name}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close product details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* Salt & Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pb-5 border-b border-slate-200">
            <div className="sm:col-span-2 flex flex-col sm:flex-row items-start gap-4">
              {product.imageUrl && (
                <button
                  type="button"
                  onClick={() => setZoomImage(true)}
                  className="relative group w-28 h-28 sm:w-32 sm:h-32 rounded-xl border border-slate-200 bg-white overflow-hidden shrink-0 cursor-pointer hover:border-slate-400 transition"
                  title="Tap to enlarge product image"
                >
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-full object-contain"
                  />
                  <span className="absolute bottom-1.5 right-1.5 inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-900/80 text-white text-[10px] font-semibold">
                    <ZoomIn className="w-3 h-3" />
                    <span>Zoom</span>
                  </span>
                </button>
              )}
              <div className="space-y-1.5 min-w-0 flex-1">
                <div className="text-xs font-semibold text-slate-500">
                  Generic Salt &amp; Composition
                </div>
                <div className="text-sm font-bold text-slate-900">
                  {product.genericName || 'Not specified'}
                </div>
                <div className="text-xs text-slate-600 leading-relaxed">
                  {product.composition || 'Composition not listed'}
                </div>
                <div className="pt-1 text-xs text-slate-500">
                  Product Code:{' '}
                  <span className="font-mono text-slate-800">
                    {product.productCode || 'N/A'}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col justify-between">
              <div>
                <div className="text-xs text-slate-500">Overall Stock Status</div>
                <div className="mt-1.5">
                  <StatusTag status={item.availabilityStatus} />
                </div>
              </div>
              <div className="mt-3 text-xs text-slate-600 space-y-0.5">
                <div>
                  Total Available:{' '}
                  <strong className="font-mono text-slate-900 tabular-nums">
                    {item.totalAvailableQty}
                  </strong>
                </div>
                <div>
                  Last Updated:{' '}
                  <span className="font-mono text-slate-800">
                    {formatDateTimeIST(item.latestUpdatedAt)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Primary / Earliest Valid Batch Headline */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3.5 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500">Wholesale Buying Rate</div>
              <div className="mt-1 font-mono text-lg font-bold text-slate-950 tabular-nums">
                {item.effectiveWholesaleRate > 0
                  ? formatINR(item.effectiveWholesaleRate)
                  : 'Confirm'}
              </div>
              {activeScheme && dealRateAdjustable && item.effectiveUnitAfterScheme ? (
                <div className="text-xs font-mono text-emerald-800 font-semibold tabular-nums">
                  Adj. Net w/ Deal: {formatINR(item.effectiveUnitAfterScheme)}
                </div>
              ) : activeScheme && !dealRateAdjustable ? (
                <div className="text-xs text-[#B91C1C] font-semibold">
                  Fixed rate (not adjustable)
                </div>
              ) : null}
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500">Retail MRP</div>
              <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums">
                {item.mrp > 0 ? formatINR(item.mrp) : '—'}
              </div>
              <div className="text-xs font-mono text-slate-600 tabular-nums">
                Discount: {item.discountPercent}%
              </div>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500">Scheme / Deal</div>
              <div className="mt-1 text-base font-bold text-slate-950">
                {activeScheme ? (
                  <div className="space-y-1">
                    <span className="inline-block px-2 py-0.5 rounded bg-[#CBB3E8]/55 font-mono text-sm">
                      {activeScheme}
                    </span>
                    {schemeOfferLabel && schemeOfferLabel !== activeScheme && (
                      <div className="text-[11px] font-semibold text-slate-700">
                        {schemeOfferLabel}
                      </div>
                    )}
                    <div
                      className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                        dealRateAdjustable
                          ? 'bg-[#D4FF3F]/45 text-slate-950 border-lime-500/60'
                          : 'bg-red-50 text-[#B91C1C] border-red-200'
                      }`}
                    >
                      {dealRateAdjustable
                        ? 'Adjustable in Rate'
                        : 'Not Adjustable in Rate'}
                    </div>
                  </div>
                ) : (
                  <span className="text-slate-400 text-sm font-medium">No scheme</span>
                )}
              </div>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500">Earliest Valid Expiry</div>
              <div
                className={`mt-1 font-mono text-lg font-bold tabular-nums ${
                  isExpiringSoon(item.earliestExpiryIso, 4)
                    ? 'text-[#B91C1C]'
                    : 'text-slate-950'
                }`}
              >
                {item.earliestExpiryDisplay}
              </div>
              <div className="text-[11px] text-slate-500">
                FIFO earliest batch
              </div>
            </div>
          </div>

          {/* Batch-Level Breakdown Table */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-slate-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  Batch-Level Inventory &amp; Expiry ({batches.length})
                </h3>
              </div>
              <span className="text-xs text-slate-500">
                Each batch retains its exact rate &amp; expiry
              </span>
            </div>

            {batches.length === 0 ? (
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 text-sm text-slate-600">
                No active batches recorded. Send an enquiry to confirm current stock and rate.
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                      <th className="py-2.5 px-3">Batch No.</th>
                      <th className="py-2.5 px-3">Expiry</th>
                      <th className="py-2.5 px-3 text-right">Stock</th>
                      <th className="py-2.5 px-3 text-right">Rate</th>
                      <th className="py-2.5 px-3 text-right">MRP</th>
                      <th className="py-2.5 px-3">Deal</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {batches.map((b) => {
                      const st = computeBatchAvailability(
                        b,
                        product.minStockLevel,
                        product.confirmAvailabilityOnly
                      );
                      const expired = isBatchExpired(b.expiryDate);
                      const batchAdjustable = isDealRateAdjustable(b, product);
                      const netDeal = batchAdjustable
                        ? computeEffectiveSchemeRate(
                            b.wholesaleRate,
                            b.schemeDetails
                          )
                        : null;
                      return (
                        <tr key={b.id} className="hover:bg-slate-50/70">
                          <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                            {b.batchNumber}
                          </td>
                          <td
                            className={`py-2.5 px-3 font-mono font-bold tabular-nums ${
                              expired || isExpiringSoon(b.expiryDate, 4)
                                ? 'text-[#B91C1C]'
                                : 'text-slate-900'
                            }`}
                          >
                            {b.expiryDisplay}
                            {expired && (
                              <span className="ml-1 text-[10px] font-sans font-semibold">
                                (Expired)
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-900">
                            {b.availableQty}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-950">
                            {formatINR(b.wholesaleRate)}
                            {netDeal ? (
                              <div className="text-[10px] font-semibold text-emerald-800">
                                Adj. Net {formatINR(netDeal)}
                              </div>
                            ) : b.schemeDetails ? (
                              <div className="text-[10px] font-sans font-semibold text-[#B91C1C]">
                                Fixed (Not Adj.)
                              </div>
                            ) : null}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                            {formatINR(b.mrp)}
                          </td>
                          <td className="py-2.5 px-3">
                            {b.schemeDetails ? (
                              <div className="space-y-0.5">
                                <div className="font-mono font-semibold text-slate-900">
                                  {b.schemeDetails}
                                </div>
                                <div
                                  className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                                    batchAdjustable
                                      ? 'bg-[#D4FF3F]/45 text-slate-950 border-lime-500/60'
                                      : 'bg-red-50 text-[#B91C1C] border-red-200'
                                  }`}
                                >
                                  {batchAdjustable
                                    ? 'Adjustable in Rate'
                                    : 'Not Adjustable'}
                                </div>
                              </div>
                            ) : (
                              <span className="text-slate-400">No scheme</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3">
                            <StatusTag status={st} compact />
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <button
                              type="button"
                              onClick={() => onAddBatchToEnquiry(item, b)}
                              className="min-h-[34px] px-2.5 py-1 rounded-md bg-[#D4FF3F] text-slate-950 font-bold hover:brightness-95 cursor-pointer whitespace-nowrap"
                            >
                              + Add
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer CTA */}
        <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              onCompareSameSalt(item);
              onClose();
            }}
            className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs sm:text-sm font-semibold hover:bg-slate-100 cursor-pointer"
          >
            <GitCompareArrows className="w-4 h-4" />
            <span>Compare Similar Salt</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onAddBatchToEnquiry(item, item.earliestValidBatch);
              onClose();
            }}
            className="inline-flex items-center gap-1.5 min-h-[44px] px-5 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-sm font-bold hover:brightness-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Earliest Expiry to Enquiry</span>
          </button>
        </div>
      </div>

      {zoomImage && product.imageUrl && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/85 p-4"
          onClick={() => setZoomImage(false)}
          role="dialog"
          aria-modal="true"
          aria-label={`${product.name} full image`}
        >
          <div
            className="relative max-w-lg w-full bg-white rounded-2xl p-3 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setZoomImage(false)}
              aria-label="Close enlarged photo"
              className="absolute top-3 right-3 z-10 min-h-[38px] min-w-[38px] flex items-center justify-center rounded-full bg-slate-900 text-white hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <img
              src={product.imageUrl}
              alt={product.name}
              className="w-full max-h-[75vh] object-contain rounded-xl bg-white"
            />
            <div className="mt-2 px-1 text-xs font-bold text-slate-900 text-center">
              {product.name} · {product.packSize}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
