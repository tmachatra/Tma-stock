import React, { useMemo, useState } from 'react';
import {
  Check,
  ClipboardList,
  Copy,
  MessageCircle,
  Minus,
  Plus,
  Trash2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AGENCY_DISPLAY_PHONE, AGENCY_WHATSAPP_NUMBER } from '../lib/firebase';
import {
  buildWhatsAppEnquiryMessage,
  formatDateTimeIST,
  formatINR,
} from '../lib/pharmaUtils';
import { saveRetailerEnquiry } from '../services/catalogService';
import type { CartEnquiryItem, RetailerEnquiry } from '../types/pharma';

interface EnquiryListViewProps {
  items: CartEnquiryItem[];
  pastEnquiries: RetailerEnquiry[];
  onUpdateQty: (productId: string, batchId: string, qty: number) => void;
  onRemoveItem: (productId: string, batchId: string) => void;
  onClearList: () => void;
  onBrowseCatalog: () => void;
  onEnquirySubmitted?: (items: CartEnquiryItem[], estimatedTotal: number) => void;
}

export const EnquiryListView: React.FC<EnquiryListViewProps> = ({
  items,
  pastEnquiries,
  onUpdateQty,
  onRemoveItem,
  onClearList,
  onBrowseCatalog,
  onEnquirySubmitted,
}) => {
  const { retailer, user } = useAuth();
  const [notes, setNotes] = useState('');
  const [copied, setCopied] = useState(false);
  const [sending, setSending] = useState(false);
  const [sentNotice, setSentNotice] = useState<{
    type: 'success' | 'warning';
    text: string;
    waUrl?: string;
  } | null>(null);

  const estimatedTotal = useMemo(
    () => items.reduce((sum, item) => sum + item.wholesaleRate * item.qty, 0),
    [items]
  );

  const whatsappMessage = useMemo(
    () => buildWhatsAppEnquiryMessage(items, retailer, notes),
    [items, retailer, notes]
  );

  const handleCopyMessage = async () => {
    try {
      await navigator.clipboard.writeText(whatsappMessage);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback ignored
    }
  };

  const handleSendWhatsApp = async () => {
    if (items.length === 0) return;
    setSending(true);
    setSentNotice(null);
    const waUrl = `https://wa.me/${AGENCY_WHATSAPP_NUMBER}?text=${encodeURIComponent(
      whatsappMessage
    )}`;
    try {
      const effectiveRetailer = retailer || {
        uid: user?.uid || 'admin_preview',
        retailerId: user?.idCode || 'ADMIN',
        ownerName: user?.displayName || 'Tara Medical Admin',
        shopName: 'Tara Medical Agency (Preview)',
        phone: AGENCY_DISPLAY_PHONE,
        drugLicenseNo: '',
        city: 'Chatra',
        address: '',
        role: 'admin' as const,
        status: 'active' as const,
        priceTier: 'standard' as const,
        customDiscountBonus: 0,
        mustChangePassword: false,
        createdAt: null,
        updatedAt: null,
      };
      await saveRetailerEnquiry(effectiveRetailer, items, notes, 'sent_whatsapp');
      onEnquirySubmitted?.(items, estimatedTotal);
      const link = document.createElement('a');
      link.href = waUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      onClearList();
      setNotes('');
      setSentNotice({
        type: 'success',
        text: `Enquiry saved and prepared for Tara Medical Agency WhatsApp (${AGENCY_DISPLAY_PHONE}). Our desk will confirm availability, billing rate, and delivery schedule.`,
        waUrl,
      });
    } catch {
      const link = document.createElement('a');
      link.href = waUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setSentNotice({
        type: 'warning',
        text: `Could not sync enquiry log to server, but your WhatsApp enquiry for ${AGENCY_DISPLAY_PHONE} is ready below.`,
        waUrl,
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-6 pb-24 md:pb-12">
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-950 flex items-center gap-2.5">
            <ClipboardList className="w-6 h-6" />
            <span>Enquiry List &amp; WhatsApp Desk</span>
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Review shortlisted medicines, adjust quantities, and send your enquiry to Tara Medical Agency ({AGENCY_DISPLAY_PHONE}).
          </p>
        </div>

        {items.length > 0 && (
          <button
            type="button"
            onClick={onClearList}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear List</span>
          </button>
        )}
      </div>

      {sentNotice && (
        <div
          className={`text-xs sm:text-sm font-medium rounded-2xl p-4 space-y-2 border ${
            sentNotice.type === 'success'
              ? 'text-emerald-900 bg-emerald-50 border-emerald-200'
              : 'text-amber-900 bg-amber-50 border-amber-200'
          }`}
        >
          <p>{sentNotice.text}</p>
          {sentNotice.waUrl && (
            <a
              href={sentNotice.waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 font-bold underline text-slate-950"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Open WhatsApp ({AGENCY_DISPLAY_PHONE})</span>
            </a>
          )}
        </div>
      )}

      {items.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center">
          <p className="text-base font-bold text-slate-900">
            Your enquiry shortlist is empty
          </p>
          <p className="mt-1 text-sm text-slate-600">
            Search medicines or browse company catalogues to add products for rate and stock confirmation.
          </p>
          <button
            type="button"
            onClick={onBrowseCatalog}
            className="mt-5 min-h-[44px] px-5 py-2.5 rounded-xl bg-[#D4FF3F] text-slate-950 text-sm font-bold hover:brightness-95 cursor-pointer"
          >
            Browse Medicines
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Shortlisted Items */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl divide-y divide-slate-100">
            {items.map((item) => {
              const lineTotal = item.wholesaleRate * item.qty;
              return (
                <div
                  key={`${item.productId}_${item.batchId}`}
                  className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="min-w-0 flex-1">
                    <div className="font-display text-base font-bold text-slate-950">
                      {item.productName}
                    </div>
                    <div className="mt-0.5 text-xs text-slate-600 flex flex-wrap items-center gap-x-2 gap-y-0.5">
                      <span>{item.manufacturer}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{item.packSize}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">
                        Rate {formatINR(item.wholesaleRate)}
                      </span>
                      {item.schemeDetails && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono font-semibold text-slate-900 bg-[#CBB3E8]/50 px-1.5 rounded">
                            Deal: {item.schemeDetails}
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                              item.dealRateAdjustable
                                ? 'bg-[#D4FF3F]/45 text-slate-950 border-lime-500/60'
                                : 'bg-red-50 text-[#B91C1C] border-red-200'
                            }`}
                          >
                            {item.dealRateAdjustable
                              ? 'Adjustable in Rate'
                              : 'Not Adjustable in Rate'}
                          </span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">Exp {item.expiryDisplay}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                    <div className="flex items-center gap-1.5 border border-slate-300 rounded-lg p-1 bg-slate-50">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateQty(item.productId, item.batchId, item.qty - 1)
                        }
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-md bg-white border border-slate-200 hover:bg-slate-100 cursor-pointer"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <input
                        type="number"
                        min={1}
                        value={item.qty}
                        onChange={(e) => {
                          const val = parseInt(e.target.value, 10);
                          if (Number.isFinite(val) && val > 0) {
                            onUpdateQty(item.productId, item.batchId, val);
                          }
                        }}
                        className="w-14 text-center font-mono text-sm font-bold text-slate-950 bg-transparent focus:outline-none tabular-nums"
                        aria-label="Quantity"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateQty(item.productId, item.batchId, item.qty + 1)
                        }
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-md bg-white border border-slate-200 hover:bg-slate-100 cursor-pointer"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-right min-w-[82px]">
                      <div className="font-mono text-sm font-bold text-slate-950 tabular-nums">
                        {formatINR(lineTotal)}
                      </div>
                      <div className="text-[11px] text-slate-500">Est.</div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onRemoveItem(item.productId, item.batchId)}
                      className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-400 hover:text-[#E34234] hover:bg-red-50 cursor-pointer"
                      aria-label={`Remove ${item.productName}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* WhatsApp Enquiry Generator Panel */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
            <div className="flex items-baseline justify-between pb-3 border-b border-slate-200">
              <span className="text-sm font-semibold text-slate-700">
                Estimated Subtotal (Excl. GST)
              </span>
              <span className="font-mono text-2xl font-extrabold text-slate-950 tabular-nums">
                {formatINR(estimatedTotal)}
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Note for Tara Medical Agency (Optional)
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Urgent stock needed, substitute acceptable if out of stock..."
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#CBB3E8]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-slate-700">
                  WhatsApp Message Preview
                </span>
                <button
                  type="button"
                  onClick={handleCopyMessage}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 hover:text-slate-950 cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Text</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-700 whitespace-pre-wrap max-h-56 overflow-y-auto leading-relaxed">
                {whatsappMessage}
              </pre>
            </div>

            <div className="text-xs text-slate-600 bg-[#CBB3E8]/25 border border-[#CBB3E8] rounded-xl p-3">
              Sending this enquiry does not automatically confirm your order. Tara Medical Agency will confirm availability, final rates, and delivery schedule on WhatsApp or phone.
            </div>

            <button
              type="button"
              disabled={sending}
              onClick={handleSendWhatsApp}
              className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#D4FF3F] text-slate-950 text-sm font-bold flex items-center justify-center gap-2 hover:brightness-95 active:scale-[0.99] transition cursor-pointer"
            >
              <MessageCircle className="w-5 h-5" />
              <span>
                {sending ? 'Preparing Enquiry...' : 'Send Enquiry on WhatsApp'}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Past Enquiries Log */}
      {pastEnquiries.length > 0 && (
        <section className="bg-white border border-slate-200 rounded-2xl p-5">
          <h2 className="font-display text-base font-bold text-slate-950 mb-3">
            Recent Enquiries Sent
          </h2>
          <div className="divide-y divide-slate-100 text-xs sm:text-sm">
            {pastEnquiries.slice(0, 5).map((enq) => (
              <div
                key={enq.id}
                className="py-2.5 flex items-center justify-between gap-4"
              >
                <div>
                  <div className="font-semibold text-slate-900">
                    {enq.itemCount} {enq.itemCount === 1 ? 'medicine' : 'medicines'}
                    {enq.notes ? ` — ${enq.notes}` : ''}
                  </div>
                  <div className="text-xs font-mono text-slate-500">
                    {formatDateTimeIST(enq.createdAt)}
                  </div>
                </div>
                <div className="font-mono font-bold text-slate-950 tabular-nums">
                  {formatINR(enq.estimatedTotal)}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
