import React, { useState } from 'react';
import { CheckCircle2, KeyRound, Lock, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AccountPasswordModalProps {
  open: boolean;
  onClose: () => void;
}

export const AccountPasswordModal: React.FC<AccountPasswordModalProps> = ({
  open,
  onClose,
}) => {
  const {
    retailer,
    adminAccount,
    isAdmin,
    changeRetailerPassword,
    changeAdminPassword,
  } = useAuth();
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!open || (!retailer && !adminAccount)) return null;

  const isAdminSession = isAdmin && !!adminAccount;
  const lockedId = isAdminSession
    ? adminAccount.adminId
    : retailer?.retailerId || '';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    if (newPw.length < 6) {
      setError('New password must be at least 6 characters.');
      return;
    }
    if (newPw !== confirmPw) {
      setError('New password and confirmation do not match.');
      return;
    }

    setSaving(true);
    try {
      if (isAdminSession) {
        await changeAdminPassword(currentPw, newPw);
      } else {
        await changeRetailerPassword(currentPw, newPw);
      }
      setSuccess(true);
      setCurrentPw('');
      setNewPw('');
      setConfirmPw('');
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to update password.'
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Account & Password"
    >
      <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-slate-900" />
            <h2 className="font-display text-lg font-bold text-slate-950">
              {isAdminSession
                ? 'Admin Account & Password'
                : 'Account & Password'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4">
          {/* Immutable Account ID Display */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-600">
                {isAdminSession
                  ? 'Assigned Admin ID (Permanent)'
                  : 'Assigned Retailer ID (Permanent)'}
              </span>
              <Lock className="w-3.5 h-3.5 text-slate-500" />
            </div>
            <div className="font-mono text-base font-bold text-slate-950">
              {lockedId}
            </div>
            <p className="text-[11px] text-slate-500">
              {isAdminSession
                ? 'Administrator ID cannot be changed.'
                : 'Assigned by Tara Medical Agency. Retailer ID cannot be changed.'}
            </p>
          </div>

          {!isAdminSession && retailer && (
            <div className="text-xs text-slate-600 space-y-0.5">
              <div className="font-bold text-slate-900">{retailer.shopName}</div>
              <div>
                {retailer.ownerName} · {retailer.phone}
              </div>
              {retailer.drugLicenseNo && (
                <div className="font-mono">DL: {retailer.drugLicenseNo}</div>
              )}
            </div>
          )}

          <form
            onSubmit={handleSubmit}
            className="pt-3 border-t border-slate-200 space-y-3"
          >
            <h3 className="text-xs font-bold text-slate-900">
              Change Password
            </h3>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Current Password
              </label>
              <input
                type="password"
                required
                value={currentPw}
                onChange={(e) => setCurrentPw(e.target.value)}
                className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                New Password (min 6 characters)
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={newPw}
                onChange={(e) => setNewPw(e.target.value)}
                className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Confirm New Password
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={confirmPw}
                onChange={(e) => setConfirmPw(e.target.value)}
                className="w-full min-h-[42px] px-3 py-1.5 rounded-lg border border-slate-300 text-sm"
              />
            </div>

            {error && (
              <p className="text-xs font-semibold text-[#B91C1C] bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                {error}
              </p>
            )}
            {success && (
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Password updated successfully.</span>
              </div>
            )}

            <button
              type="submit"
              disabled={saving}
              className="w-full min-h-[44px] px-4 py-2 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 disabled:opacity-60 cursor-pointer"
            >
              {saving ? 'Updating Password...' : 'Update Password'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
