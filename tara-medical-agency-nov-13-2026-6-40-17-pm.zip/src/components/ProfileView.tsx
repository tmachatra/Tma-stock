import React from 'react';
import {
  Building2,
  FileBadge2,
  KeyRound,
  Lock,
  LogOut,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  Tag,
  User,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AGENCY_DISPLAY_PHONE, AGENCY_WHATSAPP_NUMBER } from '../lib/firebase';
import { PWAInstallButton } from './PWAInstallButton';

interface ProfileViewProps {
  onOpenPasswordModal: () => void;
}

const PRICE_TIER_LABELS: Record<string, string> = {
  standard: 'Standard Wholesale Tier',
  tier_a: 'Tier A (Volume Account)',
  tier_b: 'Tier B (Key Account)',
};

export const ProfileView: React.FC<ProfileViewProps> = ({
  onOpenPasswordModal,
}) => {
  const { user, retailer, adminAccount, isAdmin, signOutUser } = useAuth();

  const isAdminSession = isAdmin && !!adminAccount;
  const accountId = isAdminSession
    ? adminAccount.adminId
    : retailer?.retailerId || user?.idCode || '—';

  return (
    <div className="space-y-5 pb-24 md:pb-12 max-w-3xl mx-auto">
      {/* Header Identity Card */}
      <section className="bg-slate-900 text-white rounded-2xl p-5 sm:p-7">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5 min-w-0">
            <div className="w-12 h-12 rounded-xl bg-[#D4FF3F] text-slate-950 flex items-center justify-center shrink-0">
              {isAdminSession ? (
                <ShieldCheck className="w-6 h-6" />
              ) : (
                <User className="w-6 h-6" />
              )}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-semibold text-[#CBB3E8]">
                {isAdminSession ? 'Administrator Profile' : 'Retailer Profile'}
              </div>
              <h1 className="mt-0.5 font-display text-xl sm:text-2xl font-bold text-white truncate">
                {isAdminSession
                  ? adminAccount.displayName
                  : retailer?.shopName || user?.displayName || 'Approved Retailer'}
              </h1>
              <div className="mt-1.5 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-xs font-mono text-[#D4FF3F]">
                <Lock className="w-3 h-3 shrink-0" />
                <span>ID: {accountId}</span>
              </div>
            </div>
          </div>

          {!isAdminSession && retailer && (
            <span
              className={`self-start sm:self-center px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wide ${
                retailer.status === 'active'
                  ? 'bg-[#D4FF3F] text-slate-950'
                  : 'bg-red-500/20 text-red-200 border border-red-400/40'
              }`}
            >
              {retailer.status}
            </span>
          )}
        </div>
      </section>

      {/* Customer / Account Details */}
      <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <h2 className="font-display text-base sm:text-lg font-bold text-slate-950">
            {isAdminSession ? 'Administrator Details' : 'Customer & Pharmacy Details'}
          </h2>
          <span className="text-[11px] font-medium text-slate-500">
            Verified by Tara Medical Agency
          </span>
        </div>

        {isAdminSession ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="text-xs text-slate-500">Admin ID (Permanent)</div>
              <div className="mt-1 font-mono font-bold text-slate-950">
                {adminAccount.adminId}
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="text-xs text-slate-500">Display Name</div>
              <div className="mt-1 font-semibold text-slate-950">
                {adminAccount.displayName}
              </div>
            </div>
          </div>
        ) : retailer ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-sm">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Building2 className="w-3.5 h-3.5" />
                <span>Pharmacy / Clinic Name</span>
              </div>
              <div className="mt-1 font-bold text-slate-950">
                {retailer.shopName}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <User className="w-3.5 h-3.5" />
                <span>Proprietor / Contact Name</span>
              </div>
              <div className="mt-1 font-semibold text-slate-950">
                {retailer.ownerName || 'Not specified'}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Phone className="w-3.5 h-3.5" />
                <span>Registered Mobile / WhatsApp</span>
              </div>
              <div className="mt-1 font-mono font-semibold text-slate-950">
                {retailer.phone || 'Not specified'}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <FileBadge2 className="w-3.5 h-3.5" />
                <span>Drug License No.</span>
              </div>
              <div className="mt-1 font-mono font-semibold text-slate-950">
                {retailer.drugLicenseNo || 'Not provided'}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <MapPin className="w-3.5 h-3.5" />
                <span>Town / Address</span>
              </div>
              <div className="mt-1 font-medium text-slate-900">
                {retailer.address
                  ? `${retailer.address}${retailer.city ? `, ${retailer.city}` : ''}`
                  : retailer.city || 'Chatra'}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Tag className="w-3.5 h-3.5" />
                <span>Wholesale Pricing Tier</span>
              </div>
              <div className="mt-1 font-semibold text-slate-950">
                {PRICE_TIER_LABELS[retailer.priceTier] || retailer.priceTier}
                {retailer.customDiscountBonus > 0 && (
                  <span className="ml-2 inline-block px-1.5 py-0.5 rounded bg-[#D4FF3F]/60 text-slate-950 font-mono text-xs font-bold">
                    +{retailer.customDiscountBonus}% Extra
                  </span>
                )}
              </div>
            </div>
          </div>
        ) : (
          <p className="text-sm text-slate-600">
            Account details are currently unavailable.
          </p>
        )}
      </section>

      {/* Account Actions & Support */}
      <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
        <h2 className="font-display text-base font-bold text-slate-950">
          Account Security &amp; Support
        </h2>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onOpenPasswordModal}
            className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-xl bg-slate-900 text-white text-xs sm:text-sm font-bold hover:bg-slate-800 cursor-pointer"
          >
            <KeyRound className="w-4 h-4 text-[#CBB3E8]" />
            <span>{isAdminSession ? 'Admin Password' : 'Change Password'}</span>
          </button>

          <PWAInstallButton variant="compact" />

          <a
            href={`https://wa.me/${AGENCY_WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 text-xs sm:text-sm font-semibold hover:bg-slate-50"
          >
            <MessageCircle className="w-4 h-4 text-emerald-700" />
            <span>Agency WhatsApp ({AGENCY_DISPLAY_PHONE})</span>
          </a>
        </div>

        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <p className="text-xs text-slate-500">
            Tara Medical Agency · Jatrahibag, Chatra · DL: JH-CHA-162713/162714
          </p>

          <button
            type="button"
            onClick={signOutUser}
            className="inline-flex items-center justify-center gap-2 min-h-[44px] px-5 py-2 rounded-xl border border-red-300 bg-red-50 text-[#B91C1C] text-sm font-bold hover:bg-red-100 transition cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </section>
    </div>
  );
};
