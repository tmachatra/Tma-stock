import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-20 md:bottom-4 left-4 right-4 md:left-auto md:right-4 z-50 flex items-center gap-2 rounded-lg bg-slate-900 text-white px-3.5 py-2 text-xs font-medium border border-slate-700 shadow-lg"
    >
      <WifiOff className="w-4 h-4 text-[#E34234] shrink-0" />
      <span>Offline Mode — Showing last synced catalog data.</span>
    </div>
  );
};
