import React, { useMemo, useState } from 'react';
import { GitCompareArrows, Plus, Search, Trash2, X } from 'lucide-react';
import {
  formatINR,
  formatSchemeOfferLabel,
  fuzzySearchProducts,
  getActiveSchemeInfo,
} from '../lib/pharmaUtils';
import type { ProductWithBatches } from '../types/pharma';
import { StatusTag } from './StatusTag';

interface CompareViewProps {
  products: ProductWithBatches[];
  compareIds: string[];
  onToggleCompare: (productId: string) => void;
  onClearCompare: () => void;
  onAddToCart: (item: ProductWithBatches) => void;
}

export const CompareView: React.FC<CompareViewProps> = ({
  products,
  compareIds,
  onToggleCompare,
  onClearCompare,
  onAddToCart,
}) => {
  const [pickerQuery, setPickerQuery] = useState('');

  const comparedItems = useMemo(
    () =>
      compareIds
        .map((id) => products.find((p) => p.product.id === id))
        .filter((x): x is ProductWithBatches => !!x),
    [compareIds, products]
  );

  const pickerMatches = useMemo(() => {
    if (!pickerQuery.trim()) return [];
    return fuzzySearchProducts(products, pickerQuery)
      .map((h) => h.item)
      .filter((i) => !compareIds.includes(i.product.id))
      .slice(0, 6);
  }, [products, pickerQuery, compareIds]);

  const lowestRate = useMemo(() => {
    const rates = comparedItems
      .map((i) => i.effectiveWholesaleRate)
      .filter((r) => r > 0);
    return rates.length > 0 ? Math.min(...rates) : null;
  }, [comparedItems]);

  return (
    <div className="space-y-5 pb-24 md:pb-12">
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-950 flex items-center gap-2.5">
            <GitCompareArrows className="w-6 h-6" />
            <span>Product Comparison</span>
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Compare brands or same-salt alternatives by wholesale rate, discount, scheme, pack size, and expiry.
          </p>
        </div>

        {comparedItems.length > 0 && (
          <button
            type="button"
            onClick={onClearCompare}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>
        )}
      </div>

      {/* Add Medicine Picker */}
      {comparedItems.length < 4 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 relative">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={pickerQuery}
              onChange={(e) => setPickerQuery(e.target.value)}
              placeholder={`Add medicine to compare (${comparedItems.length}/4 selected) — search by brand or salt...`}
              className="w-full min-h-[44px] pl-10 pr-4 py-2 rounded-xl border border-slate-300 bg-slate-50 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#CBB3E8] focus:bg-white"
            />
          </div>
          {pickerMatches.length > 0 && (
            <div className="mt-2 border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden">
              {pickerMatches.map((item) => (
                <button
                  key={item.product.id}
                  type="button"
                  onClick={() => {
                    onToggleCompare(item.product.id);
                    setPickerQuery('');
                  }}
                  className="w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center justify-between gap-3 cursor-pointer"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-slate-900">
                      {item.product.name} ({item.product.packSize})
                    </div>
                    <div className="text-xs text-slate-600 truncate">
                      {item.product.genericName} · {item.product.manufacturer}
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#D4FF3F] text-slate-950 text-xs font-bold shrink-0">
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {comparedItems.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center">
          <p className="text-base font-bold text-slate-900">
            No medicines selected for comparison
          </p>
          <p className="mt-1 text-sm text-slate-600">
            Search above or tap &ldquo;Compare&rdquo; on any medicine card to compare up to 4 products side by side.
          </p>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm min-w-[640px]">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50">
                <th className="py-3.5 px-4 text-xs font-bold text-slate-600 w-44">
                  Attribute
                </th>
                {comparedItems.map((item) => (
                  <th key={item.product.id} className="py-3.5 px-4 align-top">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5">
                        {item.product.imageUrl && (
                          <img
                            src={item.product.imageUrl}
                            alt={item.product.name}
                            className="w-11 h-11 rounded-lg border border-slate-200 bg-white object-contain shrink-0"
                          />
                        )}
                        <div>
                          <div className="font-display font-bold text-slate-950">
                            {item.product.name}
                          </div>
                          <div className="text-xs font-normal text-slate-500">
                            {item.product.manufacturer}
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onToggleCompare(item.product.id)}
                        className="p-1 rounded-md text-slate-400 hover:text-slate-900 hover:bg-slate-200 cursor-pointer"
                        aria-label={`Remove ${item.product.name}`}
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">Brand</td>
                {comparedItems.map((i) => (
                  <td key={i.product.id} className="py-3 px-4 font-medium text-slate-900">
                    {i.product.brandName}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">
                  Generic / Composition
                </td>
                {comparedItems.map((i) => (
                  <td key={i.product.id} className="py-3 px-4 text-slate-700">
                    <div className="font-semibold text-slate-900">
                      {i.product.genericName || '—'}
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {i.product.composition}
                    </div>
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">Manufacturer</td>
                {comparedItems.map((i) => (
                  <td key={i.product.id} className="py-3 px-4 text-slate-800">
                    {i.product.manufacturer}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">Pack Size</td>
                {comparedItems.map((i) => (
                  <td key={i.product.id} className="py-3 px-4 font-mono text-slate-900">
                    {i.product.packSize}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">
                  Wholesale Buying Rate
                </td>
                {comparedItems.map((i) => {
                  const isLowest =
                    lowestRate !== null && i.effectiveWholesaleRate === lowestRate;
                  return (
                    <td key={i.product.id} className="py-3 px-4">
                      <span
                        className={`font-mono text-base font-bold tabular-nums ${
                          isLowest
                            ? 'bg-[#D4FF3F]/60 px-2 py-0.5 rounded text-slate-950'
                            : 'text-slate-950'
                        }`}
                      >
                        {i.effectiveWholesaleRate > 0
                          ? formatINR(i.effectiveWholesaleRate)
                          : 'Confirm'}
                      </span>
                      {i.dealRateAdjustable && i.effectiveUnitAfterScheme ? (
                        <div className="text-[11px] font-mono text-emerald-800 font-semibold mt-1 tabular-nums">
                          Adj. Net w/ deal: {formatINR(i.effectiveUnitAfterScheme)}
                        </div>
                      ) : getActiveSchemeInfo(i).schemeDetails &&
                        !getActiveSchemeInfo(i).dealRateAdjustable ? (
                        <div className="text-[11px] text-[#B91C1C] font-semibold mt-1">
                          Fixed rate (slab only)
                        </div>
                      ) : null}
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">
                  Retail MRP &amp; Discount
                </td>
                {comparedItems.map((i) => (
                  <td key={i.product.id} className="py-3 px-4 font-mono tabular-nums text-slate-800">
                    {i.mrp > 0 ? formatINR(i.mrp) : '—'} ({i.discountPercent}% off)
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">Scheme / Deal</td>
                {comparedItems.map((i) => {
                  const info = getActiveSchemeInfo(i);
                  return (
                    <td key={i.product.id} className="py-3 px-4 text-slate-900">
                      {info.schemeDetails ? (
                        <div className="space-y-1">
                          <div className="font-mono font-bold">
                            {info.schemeDetails}{' '}
                            <span className="font-sans text-xs font-medium text-slate-600">
                              ({formatSchemeOfferLabel(info.schemeDetails)})
                            </span>
                          </div>
                          <span
                            className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                              info.dealRateAdjustable
                                ? 'bg-[#D4FF3F]/45 text-slate-950 border-lime-500/60'
                                : 'bg-red-50 text-[#B91C1C] border-red-200'
                            }`}
                          >
                            {info.dealRateAdjustable
                              ? 'Adjustable in Rate'
                              : 'Not Adjustable in Rate'}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400">No scheme</span>
                      )}
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">
                  Earliest Valid Expiry
                </td>
                {comparedItems.map((i) => (
                  <td key={i.product.id} className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                    {i.earliestExpiryDisplay}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">Availability</td>
                {comparedItems.map((i) => (
                  <td key={i.product.id} className="py-3 px-4">
                    <StatusTag status={i.availabilityStatus} compact />
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-600">Action</td>
                {comparedItems.map((i) => (
                  <td key={i.product.id} className="py-3 px-4">
                    <button
                      type="button"
                      onClick={() => onAddToCart(i)}
                      className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-[#D4FF3F] text-slate-950 text-xs font-bold hover:brightness-95 cursor-pointer whitespace-nowrap"
                    >
                      + Add to Enquiry
                    </button>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
