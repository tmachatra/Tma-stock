import React, { Component, useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowRight, ClipboardList, GitCompareArrows, X } from 'lucide-react';
import { AccountPasswordModal } from './components/AccountPasswordModal';
import { AuthScreen } from './components/AuthScreen';
import { CatalogSearchView } from './components/CatalogSearchView';
import { CompaniesView } from './components/CompaniesView';
import { CompareView } from './components/CompareView';
import { EnquiryListView } from './components/EnquiryListView';
import { HeaderNav } from './components/HeaderNav';
import { HomeDashboard } from './components/HomeDashboard';
import { OfflineIndicator } from './components/OfflineIndicator';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ProfileView } from './components/ProfileView';
import { AdminAnalyticsView } from './components/admin/AdminAnalyticsView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminEnquiriesView } from './components/admin/AdminEnquiriesView';
import { AdminProductCatalogWorkspace } from './components/admin/AdminProductCatalogWorkspace';
import { AuthProvider, useAuth } from './context/AuthContext';
import { computeProductView, formatINR, isDealRateAdjustable } from './lib/pharmaUtils';
import {
  fetchEnquiryItemsByIds,
  seedInitialCatalog,
  subscribeAdminBatchCosts,
  subscribeAllEnquiries,
  subscribeBatches,
  subscribeCompanies,
  subscribeCustomerEvents,
  subscribeImportLogs,
  subscribeMyEnquiries,
  subscribeProducts,
  subscribeRetailers,
  trackCustomerActivity,
} from './services/catalogService';
import type {
  AdminBatchCost,
  AdminSubTab,
  AppScreen,
  CartEnquiryItem,
  CustomerActivityEvent,
  CustomerActivityEventType,
  EnquiryItem,
  ExcelImportLog,
  MedicineBatch,
  MedicineProduct,
  PharmaCompany,
  ProductWithBatches,
  RetailerAccount,
  RetailerEnquiry,
} from './types/pharma';

class AppErrorBoundary extends Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-white border border-slate-200 rounded-2xl p-6 space-y-3">
            <h1 className="font-display text-lg font-bold text-[#B91C1C]">
              Something went wrong
            </h1>
            <p className="text-xs font-mono text-slate-600 break-words bg-slate-50 p-3 rounded-lg border border-slate-200">
              {this.state.error.message}
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="min-h-[42px] px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-bold cursor-pointer"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const CART_STORAGE_KEY = 'tara_medical_enquiry_cart_v1';
const SEED_FLAG_KEY = 'tara_medical_seeded_v1';

const MainWorkspace: React.FC = () => {
  const { user, retailer, isAdmin, isApprovedRetailer, authLoading, viewMode, setViewMode } =
    useAuth();

  const [activeScreen, setActiveScreen] = useState<AppScreen>(() => {
    const param = new URLSearchParams(window.location.search).get('screen');
    if (
      param === 'search' ||
      param === 'companies' ||
      param === 'compare' ||
      param === 'enquiry'
    ) {
      return param;
    }
    if (param === 'deals') {
      return 'search';
    }
    return 'home';
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [dealsOnlyFilter, setDealsOnlyFilter] = useState<boolean>(() => {
    const param = new URLSearchParams(window.location.search).get('screen');
    return param === 'deals';
  });
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(
    null
  );
  const [detailProductId, setDetailProductId] = useState<string | null>(null);
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [compareFlashSeq, setCompareFlashSeq] = useState(0);
  const [compareFlash, setCompareFlash] = useState(false);
  const [enquiryFlashSeq, setEnquiryFlashSeq] = useState(0);
  const [enquiryFlash, setEnquiryFlash] = useState(false);
  const [enquiryPopupDismissed, setEnquiryPopupDismissed] = useState(false);
  const [showAccountModal, setShowAccountModal] = useState(false);

  // Firestore synced state
  const [companies, setCompanies] = useState<PharmaCompany[]>([]);
  const [rawProducts, setRawProducts] = useState<MedicineProduct[]>([]);
  const [batches, setBatches] = useState<MedicineBatch[]>([]);
  const [batchCosts, setBatchCosts] = useState<Record<string, AdminBatchCost>>(
    {}
  );
  const [retailers, setRetailers] = useState<RetailerAccount[]>([]);
  const [importLogs, setImportLogs] = useState<ExcelImportLog[]>([]);
  const [pastEnquiries, setPastEnquiries] = useState<RetailerEnquiry[]>([]);
  const [allEnquiries, setAllEnquiries] = useState<RetailerEnquiry[]>([]);
  const [enquiryItems, setEnquiryItems] = useState<
    Array<EnquiryItem & { enquiryId: string }>
  >([]);
  const [customerEvents, setCustomerEvents] = useState<CustomerActivityEvent[]>([]);
  const [adminRequestedTab, setAdminRequestedTab] = useState<AdminSubTab | null>(
    null
  );
  const [catalogLoading, setCatalogLoading] = useState(true);
  const [catalogError, setCatalogError] = useState<string | null>(null);

  const [cartItems, setCartItems] = useState<CartEnquiryItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CartEnquiryItem[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartItems));
    } catch {
      // Ignore storage quota errors
    }
  }, [cartItems]);

  useEffect(() => {
    if (!user) {
      setActiveScreen('home');
    }
  }, [user]);

  useEffect(() => {
    if (compareIds.length === 0) {
      setCompareFlash(false);
      return;
    }
    if (compareFlashSeq === 0) return;
    setCompareFlash(true);
    const timer = setTimeout(() => setCompareFlash(false), 2800);
    return () => clearTimeout(timer);
  }, [compareFlashSeq, compareIds.length]);

  useEffect(() => {
    if (cartItems.length === 0) {
      setEnquiryFlash(false);
      setEnquiryPopupDismissed(false);
      return;
    }
    if (enquiryFlashSeq === 0) return;
    setEnquiryFlash(true);
    const timer = setTimeout(() => setEnquiryFlash(false), 3200);
    return () => clearTimeout(timer);
  }, [enquiryFlashSeq, cartItems.length]);

  useEffect(() => {
    if (!user || !isApprovedRetailer) {
      setCompanies([]);
      setRawProducts([]);
      setBatches([]);
      setCatalogLoading(false);
      return;
    }

    setCatalogLoading(true);
    setCatalogError(null);

    let gotProducts = false;
    let gotBatches = false;

    const checkLoaded = () => {
      if (gotProducts && gotBatches) setCatalogLoading(false);
    };

    const unsubCompanies = subscribeCompanies(
      (list) => setCompanies(list),
      (err) => setCatalogError(err.message)
    );
    const unsubProducts = subscribeProducts(
      (list) => {
        setRawProducts(list);
        gotProducts = true;
        checkLoaded();
      },
      (err) => {
        setCatalogError(err.message);
        setCatalogLoading(false);
      }
    );
    const unsubBatches = subscribeBatches(
      (list) => {
        setBatches(list);
        gotBatches = true;
        checkLoaded();
      },
      (err) => {
        setCatalogError(err.message);
        setCatalogLoading(false);
      }
    );
    const unsubEnquiries = subscribeMyEnquiries(user.uid, (list) =>
      setPastEnquiries(list)
    );

    let unsubCosts: (() => void) | null = null;
    let unsubRetailers: (() => void) | null = null;
    let unsubImportLogs: (() => void) | null = null;
    let unsubAllEnquiries: (() => void) | null = null;
    let unsubCustomerEvents: (() => void) | null = null;

    if (isAdmin) {
      unsubCosts = subscribeAdminBatchCosts((map) => setBatchCosts(map));
      unsubRetailers = subscribeRetailers((list) => setRetailers(list));
      unsubImportLogs = subscribeImportLogs((list) => setImportLogs(list));
      unsubAllEnquiries = subscribeAllEnquiries((list) => setAllEnquiries(list));
      unsubCustomerEvents = subscribeCustomerEvents((list) =>
        setCustomerEvents(list)
      );
    }

    return () => {
      unsubCompanies();
      unsubProducts();
      unsubBatches();
      unsubEnquiries();
      if (unsubCosts) unsubCosts();
      if (unsubRetailers) unsubRetailers();
      if (unsubImportLogs) unsubImportLogs();
      if (unsubAllEnquiries) unsubAllEnquiries();
      if (unsubCustomerEvents) unsubCustomerEvents();
    };
  }, [user, isApprovedRetailer, isAdmin]);

  useEffect(() => {
    if (!isAdmin || allEnquiries.length === 0) {
      setEnquiryItems([]);
      return;
    }
    let cancelled = false;
    void fetchEnquiryItemsByIds(allEnquiries.map((e) => e.id)).then((items) => {
      if (!cancelled) setEnquiryItems(items);
    });
    return () => {
      cancelled = true;
    };
  }, [isAdmin, allEnquiries]);

  // First-run auto-seed when Admin logs in and catalog is empty
  useEffect(() => {
    if (
      isAdmin &&
      !catalogLoading &&
      rawProducts.length === 0 &&
      !localStorage.getItem(SEED_FLAG_KEY)
    ) {
      localStorage.setItem(SEED_FLAG_KEY, '1');
      void seedInitialCatalog();
    }
  }, [isAdmin, catalogLoading, rawProducts.length]);

  const productsWithBatches = useMemo<ProductWithBatches[]>(() => {
    return rawProducts.map((p) => computeProductView(p, batches, retailer));
  }, [rawProducts, batches, retailer]);

  const detailItem = useMemo(
    () =>
      detailProductId
        ? productsWithBatches.find((p) => p.product.id === detailProductId) ||
          null
        : null,
    [detailProductId, productsWithBatches]
  );

  const cartQuantities = useMemo(() => {
    const map: Record<string, number> = {};
    for (const c of cartItems) {
      map[c.productId] = (map[c.productId] || 0) + c.qty;
    }
    return map;
  }, [cartItems]);

  const cartEstimatedTotal = useMemo(
    () => cartItems.reduce((sum, item) => sum + item.wholesaleRate * item.qty, 0),
    [cartItems]
  );

  const logCustomerEvent = useCallback(
    (payload: {
      eventType: CustomerActivityEventType;
      productId?: string;
      productName?: string;
      companyId?: string;
      companyName?: string;
      searchQuery?: string;
      qty?: number;
      estimatedValue?: number;
      resultCount?: number;
    }) => {
      if (!retailer || isAdmin) return;
      void trackCustomerActivity({
        retailerUid: retailer.uid,
        retailerId: retailer.retailerId,
        shopName: retailer.shopName || retailer.ownerName,
        city: retailer.city || '',
        ...payload,
      });
    },
    [retailer, isAdmin]
  );

  const handleOpenProductDetails = (item: ProductWithBatches) => {
    setDetailProductId(item.product.id);
    logCustomerEvent({
      eventType: 'product_view',
      productId: item.product.id,
      productName: item.product.name,
      companyId: item.product.companyId,
      companyName: item.product.manufacturer,
    });
  };

  const handleAddBatchToCart = (
    item: ProductWithBatches,
    batch: MedicineBatch | null
  ) => {
    const targetBatchId = batch?.id || 'auto';
    const rate = batch ? batch.wholesaleRate : item.effectiveWholesaleRate;
    const scheme = batch ? batch.schemeDetails : item.schemeDetails;
    const expiry = batch ? batch.expiryDisplay : item.earliestExpiryDisplay;
    const mrp = batch ? batch.mrp : item.mrp;
    const discount = batch ? batch.discountPercent : item.discountPercent;
    const rateAdjustable = batch
      ? isDealRateAdjustable(batch, item.product)
      : item.dealRateAdjustable;

    setCartItems((prev) => {
      const idx = prev.findIndex(
        (x) =>
          x.productId === item.product.id && x.batchId === targetBatchId
      );
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], qty: copy[idx].qty + 1 };
        return copy;
      }
      return [
        ...prev,
        {
          productId: item.product.id,
          batchId: targetBatchId,
          productName: item.product.name,
          brandName: item.product.brandName,
          manufacturer: item.product.manufacturer,
          packSize: item.product.packSize,
          qty: 1,
          wholesaleRate: rate,
          mrp,
          discountPercent: discount,
          schemeDetails: scheme,
          dealRateAdjustable: rateAdjustable,
          expiryDisplay: expiry,
          availabilityStatus: item.availabilityStatus,
        },
      ];
    });

    setEnquiryPopupDismissed(false);
    setEnquiryFlashSeq((n) => n + 1);

    logCustomerEvent({
      eventType: 'cart_add',
      productId: item.product.id,
      productName: item.product.name,
      companyId: item.product.companyId,
      companyName: item.product.manufacturer,
      qty: 1,
      estimatedValue: rate,
    });
  };

  const handleUpdateCartQty = (
    productId: string,
    batchId: string,
    qty: number
  ) => {
    if (qty <= 0) {
      setCartItems((prev) =>
        prev.filter(
          (x) => !(x.productId === productId && x.batchId === batchId)
        )
      );
      return;
    }
    setCartItems((prev) =>
      prev.map((x) =>
        x.productId === productId && x.batchId === batchId
          ? { ...x, qty }
          : x
      )
    );
  };

  const handleRemoveCartItem = (productId: string, batchId: string) => {
    setCartItems((prev) =>
      prev.filter(
        (x) => !(x.productId === productId && x.batchId === batchId)
      )
    );
  };

  const handleToggleCompare = (productId: string) => {
    const isAdding = !compareIds.includes(productId);
    setCompareIds((prev) => {
      if (prev.includes(productId)) {
        return prev.filter((id) => id !== productId);
      }
      if (prev.length >= 4) {
        return [...prev.slice(1), productId];
      }
      return [...prev, productId];
    });
    if (isAdding) {
      setCompareFlashSeq((n) => n + 1);
      const target = productsWithBatches.find((p) => p.product.id === productId);
      logCustomerEvent({
        eventType: 'compare_add',
        productId,
        productName: target?.product.name || '',
        companyId: target?.product.companyId || '',
        companyName: target?.product.manufacturer || '',
      });
    }
  };

  const handleCompareSameSalt = (item: ProductWithBatches) => {
    const salt = item.product.genericName.toLowerCase().trim();
    const firstWord = salt.split(/[\s+/]+/)[0] || '';
    const matches = productsWithBatches
      .filter((p) => {
        if (p.product.id === item.product.id) return false;
        const g = p.product.genericName.toLowerCase();
        return (
          (salt && g.includes(salt)) ||
          (firstWord.length >= 4 && g.includes(firstWord))
        );
      })
      .slice(0, 3)
      .map((p) => p.product.id);

    setCompareIds([item.product.id, ...matches]);
    setViewMode('retailer');
    setActiveScreen('compare');
  };

  if (authLoading || !user || !isApprovedRetailer) {
    return (
      <>
        <AuthScreen />
        <OfflineIndicator />
      </>
    );
  }

  const showingAdmin = isAdmin;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <HeaderNav
        activeScreen={activeScreen}
        onNavigate={(screen) => {
          setActiveScreen(screen);
          if (screen === 'companies') setSelectedCompanyId(null);
          if (screen === 'search') setDealsOnlyFilter(false);
        }}
        enquiryCount={isAdmin ? allEnquiries.length : cartItems.length}
        compareCount={compareIds.length}
        compareFlash={compareFlash}
        enquiryFlash={enquiryFlash}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-5 sm:pt-7">
        {catalogError && (
          <div className="mb-5 p-4 rounded-xl bg-red-50 border border-red-200 text-xs font-semibold text-[#B91C1C]">
            {catalogError}
          </div>
        )}

        {showingAdmin ? (
          activeScreen === 'analytics' ? (
            <AdminAnalyticsView
              products={productsWithBatches}
              batches={batches}
              batchCosts={batchCosts}
              companies={companies}
              retailers={retailers}
              allEnquiries={allEnquiries}
              enquiryItems={enquiryItems}
              customerEvents={customerEvents}
              onJumpToAdminTab={(tab) => {
                setAdminRequestedTab(tab);
                setViewMode('admin');
                setActiveScreen('admin');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          ) : activeScreen === 'enquiry' ? (
            <AdminEnquiriesView
              enquiries={allEnquiries}
              enquiryItems={enquiryItems}
              retailers={retailers}
            />
          ) : activeScreen === 'products' ? (
            <AdminProductCatalogWorkspace
              products={productsWithBatches}
              rawProducts={rawProducts}
              batches={batches}
              batchCosts={batchCosts}
              companies={companies}
              importLogs={importLogs}
            />
          ) : activeScreen === 'profile' ? (
            <ProfileView
              onOpenPasswordModal={() => setShowAccountModal(true)}
            />
          ) : (
            <AdminDashboard
              products={productsWithBatches}
              rawProducts={rawProducts}
              batches={batches}
              batchCosts={batchCosts}
              companies={companies}
              retailers={retailers}
              importLogs={importLogs}
              requestedTab={adminRequestedTab}
              onRequestedTabHandled={() => setAdminRequestedTab(null)}
              onOpenAnalytics={() => {
                setViewMode('admin');
                setActiveScreen('analytics');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onOpenAdminPasswordModal={() => setShowAccountModal(true)}
            />
          )
        ) : (
          <>
            {activeScreen !== 'search' &&
              activeScreen !== 'companies' &&
              activeScreen !== 'compare' &&
              activeScreen !== 'enquiry' &&
              activeScreen !== 'profile' && (
              <HomeDashboard
                products={productsWithBatches}
                companies={companies}
                loading={catalogLoading}
                cartQuantities={cartQuantities}
                compareIds={compareIds}
                onSearchSubmit={(q) => {
                  setSearchQuery(q);
                  setDealsOnlyFilter(false);
                  setActiveScreen('search');
                }}
                onNavigate={(s) => {
                  if (s === 'search') setDealsOnlyFilter(false);
                  if (s === 'companies') setSelectedCompanyId(null);
                  setActiveScreen(s);
                }}
                onOpenDeals={() => {
                  setSearchQuery('');
                  setDealsOnlyFilter(true);
                  setActiveScreen('search');
                  logCustomerEvent({ eventType: 'deal_filter' });
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onSelectCompany={(compId) => {
                  setSelectedCompanyId(compId);
                  setActiveScreen('companies');
                  const comp = companies.find((c) => c.id === compId);
                  logCustomerEvent({
                    eventType: 'company_view',
                    companyId: compId,
                    companyName: comp?.name || '',
                  });
                }}
                onAddToCart={(item) =>
                  handleAddBatchToCart(item, item.earliestValidBatch)
                }
                onUpdateCartQty={handleUpdateCartQty}
                onToggleCompare={handleToggleCompare}
                onOpenDetails={handleOpenProductDetails}
                onOpenAccountSettings={() => setShowAccountModal(true)}
              />
            )}

            {activeScreen === 'search' && (
              <CatalogSearchView
                products={productsWithBatches}
                initialQuery={searchQuery}
                onQueryChange={setSearchQuery}
                dealsOnly={dealsOnlyFilter}
                onDealsOnlyChange={setDealsOnlyFilter}
                cartQuantities={cartQuantities}
                compareIds={compareIds}
                onAddToCart={(item) =>
                  handleAddBatchToCart(item, item.earliestValidBatch)
                }
                onUpdateCartQty={handleUpdateCartQty}
                onToggleCompare={handleToggleCompare}
                onOpenDetails={handleOpenProductDetails}
                onSearchTracked={(q, count) => {
                  logCustomerEvent({
                    eventType: count === 0 ? 'zero_result_search' : 'search',
                    searchQuery: q,
                    resultCount: count,
                  });
                }}
              />
            )}

            {activeScreen === 'companies' && (
              <CompaniesView
                companies={companies}
                products={productsWithBatches}
                selectedCompanyId={selectedCompanyId}
                onSelectCompany={(compId) => {
                  setSelectedCompanyId(compId);
                  if (compId) {
                    const comp = companies.find((c) => c.id === compId);
                    logCustomerEvent({
                      eventType: 'company_view',
                      companyId: compId,
                      companyName: comp?.name || '',
                    });
                  }
                }}
                cartQuantities={cartQuantities}
                compareIds={compareIds}
                onAddToCart={(item) =>
                  handleAddBatchToCart(item, item.earliestValidBatch)
                }
                onUpdateCartQty={handleUpdateCartQty}
                onToggleCompare={handleToggleCompare}
                onOpenDetails={handleOpenProductDetails}
              />
            )}

            {activeScreen === 'compare' && (
              <CompareView
                products={productsWithBatches}
                compareIds={compareIds}
                onToggleCompare={handleToggleCompare}
                onClearCompare={() => setCompareIds([])}
                onAddToCart={(item) =>
                  handleAddBatchToCart(item, item.earliestValidBatch)
                }
              />
            )}

            {activeScreen === 'enquiry' && (
              <EnquiryListView
                items={cartItems}
                pastEnquiries={pastEnquiries}
                onUpdateQty={handleUpdateCartQty}
                onRemoveItem={handleRemoveCartItem}
                onClearList={() => setCartItems([])}
                onBrowseCatalog={() => setActiveScreen('search')}
                onEnquirySubmitted={(submittedItems, total) => {
                  logCustomerEvent({
                    eventType: 'enquiry_submit',
                    qty: submittedItems.reduce((s, x) => s + x.qty, 0),
                    estimatedValue: total,
                  });
                }}
              />
            )}

            {activeScreen === 'profile' && (
              <ProfileView
                onOpenPasswordModal={() => setShowAccountModal(true)}
              />
            )}
          </>
        )}
      </main>

      {/* Floating quick-action popups for Enquiry & Compare */}
      {!showingAdmin &&
        ((!isAdmin && activeScreen !== 'enquiry' && cartItems.length > 0 && !enquiryPopupDismissed) ||
          (activeScreen !== 'compare' && compareIds.length > 0)) && (
          <div className="fixed bottom-16 left-3 right-3 md:left-auto md:right-6 md:bottom-6 z-40 flex flex-col items-center md:items-end gap-2 pointer-events-none">
            {!isAdmin &&
              activeScreen !== 'enquiry' &&
              cartItems.length > 0 &&
              !enquiryPopupDismissed && (
                <div
                  className={`pointer-events-auto flex items-center gap-2 rounded-xl p-1.5 shadow-xl border transition-all ${
                    enquiryFlash
                      ? 'bg-[#D4FF3F] text-slate-950 border-slate-950 ring-4 ring-[#CBB3E8] animate-bounce'
                      : 'bg-slate-900 text-white border-slate-700'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setViewMode('retailer');
                      setActiveScreen('enquiry');
                      setEnquiryFlash(false);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-2 min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold cursor-pointer"
                  >
                    <ClipboardList
                      className={`w-4 h-4 shrink-0 ${
                        enquiryFlash ? 'text-slate-950' : 'text-[#D4FF3F]'
                      }`}
                    />
                    <span className="tabular-nums">
                      {enquiryFlash
                        ? `Added to Enquiry (${cartItems.length}) · ${formatINR(cartEstimatedTotal)} — Send Now`
                        : `Send Enquiry (${cartItems.length} · ${formatINR(cartEstimatedTotal)})`}
                    </span>
                    <ArrowRight className="w-4 h-4 shrink-0" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEnquiryPopupDismissed(true);
                      setEnquiryFlash(false);
                    }}
                    aria-label="Dismiss quick enquiry popup"
                    className={`min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg cursor-pointer ${
                      enquiryFlash
                        ? 'text-slate-900 hover:bg-slate-950/10'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

            {activeScreen !== 'compare' && compareIds.length > 0 && (
              <div
                className={`pointer-events-auto flex items-center gap-2 rounded-xl p-1.5 shadow-xl border transition-all ${
                  compareFlash
                    ? 'bg-[#D4FF3F] text-slate-950 border-slate-950 ring-4 ring-[#CBB3E8] animate-bounce'
                    : 'bg-slate-900 text-white border-slate-700'
                }`}
              >
                <button
                  type="button"
                  onClick={() => {
                    setViewMode('retailer');
                    setActiveScreen('compare');
                    setCompareFlash(false);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold cursor-pointer"
                >
                  <GitCompareArrows
                    className={`w-4 h-4 shrink-0 ${
                      compareFlash ? 'text-slate-950' : 'text-[#D4FF3F]'
                    }`}
                  />
                  <span>
                    {compareFlash
                      ? `Added to Compare (${compareIds.length}) — Tap to View`
                      : `Compare (${compareIds.length})`}
                  </span>
                  <ArrowRight className="w-4 h-4 shrink-0" />
                </button>
                <button
                  type="button"
                  onClick={() => setCompareIds([])}
                  aria-label="Clear compare list"
                  className={`min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg cursor-pointer ${
                    compareFlash
                      ? 'text-slate-900 hover:bg-slate-950/10'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

      <ProductDetailModal
        item={detailItem}
        onClose={() => setDetailProductId(null)}
        onAddBatchToEnquiry={handleAddBatchToCart}
        onCompareSameSalt={handleCompareSameSalt}
      />

      <AccountPasswordModal
        open={showAccountModal}
        onClose={() => setShowAccountModal(false)}
      />

      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <AppErrorBoundary>
      <AuthProvider>
        <MainWorkspace />
      </AuthProvider>
    </AppErrorBoundary>
  );
}
