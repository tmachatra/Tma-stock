import { initializeApp } from 'firebase/app';
import { doc, getDocFromServer, getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export const DEFAULT_ADMIN_ID = 'TMA-ADMIN';
export const DEFAULT_ADMIN_DOC_ID = 'adm_tma-admin';
export const DEFAULT_ADMIN_INITIAL_PASSWORD = 'Tara@1234';

export const AGENCY_WHATSAPP_NUMBER = '917004417714';
export const AGENCY_DISPLAY_PHONE = '+91 70044 17714';

export function normalizeCodeId(raw: string): string {
  return raw
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_-]/g, '');
}

export const normalizeRetailerId = normalizeCodeId;

export function retailerDocIdFromCode(retailerId: string): string {
  const norm = normalizeCodeId(retailerId);
  return `ret_${norm.toLowerCase()}`;
}

export function adminDocIdFromCode(adminId: string): string {
  const norm = normalizeCodeId(adminId);
  return `adm_${norm.toLowerCase()}`;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
}

export function logFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): FirestoreErrorInfo {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo;
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo = logFirestoreError(error, operationType, path);
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes('the client is offline')
    ) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

void testConnection();
