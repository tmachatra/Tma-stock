export const MAX_PRODUCT_IMAGE_CHARS = 145000;

export function isValidProductImageUrl(value: string): boolean {
  const trimmed = value.trim();
  if (!trimmed) return true;
  if (trimmed.length > MAX_PRODUCT_IMAGE_CHARS) return false;
  return (
    trimmed.startsWith('https://') ||
    trimmed.startsWith('http://') ||
    trimmed.startsWith('data:image/') ||
    trimmed.startsWith('/')
  );
}

/**
 * Compresses an uploaded image file (camera photo or gallery image) into a
 * crisp JPEG data URI under MAX_PRODUCT_IMAGE_CHARS so it fits cleanly inside
 * Firestore documents and loads offline/online with zero external CORS issues.
 */
export async function compressProductImageFile(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Please choose a valid image file (JPG, PNG, or WebP).');
  }

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Could not read selected image file.'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read selected image file.'));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error('Selected file could not be decoded as an image.'));
    el.src = dataUrl;
  });

  const maxSides = [480, 360, 280];
  const qualities = [0.78, 0.65, 0.52];

  for (const maxSide of maxSides) {
    const scale = Math.min(1, maxSide / Math.max(img.width, img.height, 1));
    const width = Math.max(1, Math.round(img.width * scale));
    const height = Math.max(1, Math.round(img.height * scale));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Canvas image processing is unavailable in this browser.');
    }
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);

    for (const q of qualities) {
      const encoded = canvas.toDataURL('image/jpeg', q);
      if (encoded.length <= MAX_PRODUCT_IMAGE_CHARS) {
        return encoded;
      }
    }
  }

  throw new Error(
    'Image is too large even after compression. Please select a smaller photo or paste an image URL.'
  );
}
