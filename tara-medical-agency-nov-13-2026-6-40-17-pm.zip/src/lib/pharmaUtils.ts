import type { Timestamp } from 'firebase/firestore';
import type {
  AvailabilityStatus,
  CartEnquiryItem,
  MedicineBatch,
  MedicineProduct,
  ProductWithBatches,
  RetailerAccount,
} from '../types/pharma';

export function slugId(prefix: string, raw: string): string {
  const clean = raw
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 48);
  return `${prefix}_${clean || 'item'}`;
}

export function toDateSafe(ts: Timestamp | Date | null | undefined): Date | null {
  if (!ts) return null;
  if (ts instanceof Date) return ts;
  if (typeof (ts as Timestamp).toDate === 'function') {
    return (ts as Timestamp).toDate();
  }
  return null;
}

export function formatDateTimeIST(ts: Timestamp | Date | null | undefined): string {
  const d = toDateSafe(ts);
  if (!d) return 'Not recorded';
  try {
    return new Intl.DateTimeFormat('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }).format(d);
  } catch {
    return d.toLocaleString();
  }
}

export function formatINR(value: number): string {
  if (!Number.isFinite(value)) return '₹0.00';
  return `₹${value.toFixed(2)}`;
}

export function parseExpiryToIso(raw: unknown): {
  expiryDate: string;
  expiryDisplay: string;
} {
  if (raw === null || raw === undefined) {
    return { expiryDate: '', expiryDisplay: 'Missing' };
  }

  // Handle Excel serial date numbers
  if (typeof raw === 'number' && raw > 20000 && raw < 80000) {
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const dt = new Date(excelEpoch.getTime() + raw * 86400000);
    const yyyy = dt.getUTCFullYear();
    const mm = String(dt.getUTCMonth() + 1).padStart(2, '0');
    return { expiryDate: `${yyyy}-${mm}`, expiryDisplay: `${mm}/${yyyy}` };
  }

  const s = String(raw).trim();
  if (!s || /^missing$/i.test(s) || s === '-') {
    return { expiryDate: '', expiryDisplay: 'Missing' };
  }

  // YYYY-MM or YYYY/MM or YYYY-MM-DD
  const isoMatch = s.match(/^(\d{4})[-/](\d{1,2})(?:[-/]\d{1,2})?$/);
  if (isoMatch) {
    const yyyy = isoMatch[1];
    const mmNum = Number(isoMatch[2]);
    if (mmNum >= 1 && mmNum <= 12) {
      const mm = String(mmNum).padStart(2, '0');
      return { expiryDate: `${yyyy}-${mm}`, expiryDisplay: `${mm}/${yyyy}` };
    }
  }

  // MM/YY or M/YY or MM/YYYY or MM-YY or MM-YYYY
  const mmyyMatch = s.match(/^(\d{1,2})[-/](\d{2,4})$/);
  if (mmyyMatch) {
    const mmNum = Number(mmyyMatch[1]);
    let yyyy = mmyyMatch[2];
    if (yyyy.length === 2) {
      yyyy = `20${yyyy}`;
    }
    if (mmNum >= 1 && mmNum <= 12) {
      const mm = String(mmNum).padStart(2, '0');
      return { expiryDate: `${yyyy}-${mm}`, expiryDisplay: `${mm}/${yyyy}` };
    }
  }

  // Month name like "Jan-29" or "Jun 2028"
  const months: Record<string, string> = {
    jan: '01',
    feb: '02',
    mar: '03',
    apr: '04',
    may: '05',
    jun: '06',
    jul: '07',
    aug: '08',
    sep: '09',
    oct: '10',
    nov: '11',
    dec: '12',
  };
  const namedMatch = s.match(/^([a-zA-Z]{3})[a-zA-Z]*[-\s/]+(\d{2,4})$/);
  if (namedMatch) {
    const mKey = namedMatch[1].toLowerCase();
    const mm = months[mKey];
    let yyyy = namedMatch[2];
    if (yyyy.length === 2) yyyy = `20${yyyy}`;
    if (mm) {
      return { expiryDate: `${yyyy}-${mm}`, expiryDisplay: `${mm}/${yyyy}` };
    }
  }

  return { expiryDate: '', expiryDisplay: 'Invalid' };
}

export function currentYearMonth(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

export function isBatchExpired(expiryDate: string): boolean {
  if (!expiryDate || expiryDate.length < 7) return false;
  return expiryDate < currentYearMonth();
}

export function monthsUntilExpiry(expiryDate: string): number | null {
  if (!expiryDate || !/^\d{4}-\d{2}$/.test(expiryDate)) return null;
  const [y, m] = expiryDate.split('-').map(Number);
  const now = new Date();
  return (y - now.getFullYear()) * 12 + (m - (now.getMonth() + 1));
}

export function isExpiringSoon(expiryDate: string, thresholdMonths = 4): boolean {
  const diff = monthsUntilExpiry(expiryDate);
  return diff !== null && diff >= 0 && diff <= thresholdMonths;
}

export function computeBatchAvailability(
  batch: MedicineBatch,
  minStockLevel: number,
  confirmAvailabilityOnly: boolean
): AvailabilityStatus {
  if (confirmAvailabilityOnly || batch.availabilityOverride === 'CONFIRM_AVAILABILITY') {
    return 'CONFIRM AVAILABILITY';
  }
  if (batch.availabilityOverride === 'OUT_OF_STOCK') {
    return 'OUT OF STOCK';
  }
  if (batch.availabilityOverride === 'LOW_STOCK') {
    return 'LOW STOCK';
  }
  if (batch.availabilityOverride === 'IN_STOCK') {
    return 'IN STOCK';
  }

  if (isBatchExpired(batch.expiryDate)) {
    return 'OUT OF STOCK';
  }
  if (batch.availableQty <= 0) {
    return 'OUT OF STOCK';
  }
  if (batch.availableQty <= Math.max(1, minStockLevel)) {
    return 'LOW STOCK';
  }
  return 'IN STOCK';
}

export function computeEffectiveSchemeRate(
  wholesaleRate: number,
  schemeDetails: string
): number | null {
  if (!schemeDetails || wholesaleRate <= 0) return null;
  const dealMatch = schemeDetails.match(/(\d+)\s*\+\s*(\d+)/);
  if (!dealMatch) return null;
  const paid = Number(dealMatch[1]);
  const free = Number(dealMatch[2]);
  if (paid <= 0 || free <= 0) return null;
  return Number(((wholesaleRate * paid) / (paid + free)).toFixed(2));
}

const LEGACY_RATE_ADJUSTABLE_KEYWORDS = [
  'monocef',
  'avomine',
  'dolonex',
  'norflox',
  'pan 40 inj',
  'pan_40_inj',
  'clavam',
];

export function isDealRateAdjustable(
  batch:
    | Pick<MedicineBatch, 'productId' | 'schemeDetails' | 'dealRateAdjustable'>
    | null
    | undefined,
  product?: Pick<MedicineProduct, 'id' | 'name' | 'brandName'> | null
): boolean {
  if (!batch || !batch.schemeDetails || !batch.schemeDetails.trim()) {
    return false;
  }
  if (typeof batch.dealRateAdjustable === 'boolean') {
    return batch.dealRateAdjustable;
  }
  const haystack = `${batch.productId || ''} ${product?.id || ''} ${product?.name || ''} ${product?.brandName || ''}`.toLowerCase();
  if (haystack.includes('panderm')) {
    return false;
  }
  return LEGACY_RATE_ADJUSTABLE_KEYWORDS.some((kw) => haystack.includes(kw));
}

export function getActiveSchemeInfo(item: ProductWithBatches): {
  schemeDetails: string;
  dealRateAdjustable: boolean;
} {
  if (item.schemeDetails && item.schemeDetails.trim()) {
    return {
      schemeDetails: item.schemeDetails.trim(),
      dealRateAdjustable: item.dealRateAdjustable,
    };
  }
  const batchWithScheme = item.batches.find(
    (b) => b.isActive && b.schemeDetails && b.schemeDetails.trim()
  );
  if (!batchWithScheme) {
    return { schemeDetails: '', dealRateAdjustable: false };
  }
  return {
    schemeDetails: batchWithScheme.schemeDetails.trim(),
    dealRateAdjustable: isDealRateAdjustable(batchWithScheme, item.product),
  };
}

export function getActiveSchemeText(item: ProductWithBatches): string {
  return getActiveSchemeInfo(item).schemeDetails;
}

export function hasActiveDealOrScheme(item: ProductWithBatches): boolean {
  return !!getActiveSchemeText(item);
}

export function formatSchemeOfferLabel(schemeDetails: string): string {
  const clean = schemeDetails.trim();
  if (!clean) return '';
  const match = clean.match(/^(\d+)\s*\+\s*(\d+)$/);
  if (match) {
    return `Buy ${match[1]} + ${match[2]} Free`;
  }
  return clean;
}

export function computeProductView(
  product: MedicineProduct,
  allBatches: MedicineBatch[],
  retailer?: RetailerAccount | null
): ProductWithBatches {
  const productBatches = allBatches
    .filter((b) => b.productId === product.id && b.isActive)
    .sort((a, b) => {
      const expA = a.expiryDate || '9999-99';
      const expB = b.expiryDate || '9999-99';
      return expA.localeCompare(expB);
    });

  const validInStockBatches = productBatches.filter(
    (b) => !isBatchExpired(b.expiryDate) && b.availableQty > 0
  );

  // Earliest valid expiry with available stock (FIFO)
  const earliestValidBatch =
    validInStockBatches[0] ||
    productBatches.find((b) => !isBatchExpired(b.expiryDate)) ||
    productBatches[0] ||
    null;

  const totalAvailableQty = validInStockBatches.reduce(
    (sum, b) => sum + b.availableQty,
    0
  );

  let availabilityStatus: AvailabilityStatus = 'CONFIRM AVAILABILITY';
  if (product.confirmAvailabilityOnly) {
    availabilityStatus = 'CONFIRM AVAILABILITY';
  } else if (productBatches.length === 0) {
    availabilityStatus = 'CONFIRM AVAILABILITY';
  } else if (earliestValidBatch?.availabilityOverride === 'CONFIRM_AVAILABILITY') {
    availabilityStatus = 'CONFIRM AVAILABILITY';
  } else if (validInStockBatches.length === 0) {
    // Check if any batch explicitly says CONFIRM_AVAILABILITY
    const hasConfirmOverride = productBatches.some(
      (b) => b.availabilityOverride === 'CONFIRM_AVAILABILITY'
    );
    availabilityStatus = hasConfirmOverride ? 'CONFIRM AVAILABILITY' : 'OUT OF STOCK';
  } else if (totalAvailableQty <= Math.max(1, product.minStockLevel)) {
    availabilityStatus = 'LOW STOCK';
  } else {
    availabilityStatus = 'IN STOCK';
  }

  // Apply retailer custom discount bonus if configured (future-ready retailer-specific pricing)
  const baseRate = earliestValidBatch ? earliestValidBatch.wholesaleRate : 0;
  const bonusPct = retailer?.customDiscountBonus || 0;
  const effectiveWholesaleRate =
    bonusPct > 0 && baseRate > 0
      ? Number((baseRate * (1 - bonusPct / 100)).toFixed(2))
      : baseRate;

  const baseDiscount = earliestValidBatch ? earliestValidBatch.discountPercent : 0;
  const discountPercent = Number((baseDiscount + bonusPct).toFixed(2));
  const schemeDetails = earliestValidBatch ? earliestValidBatch.schemeDetails : '';
  const dealRateAdjustable = isDealRateAdjustable(earliestValidBatch, product);

  const effectiveUnitAfterScheme = dealRateAdjustable
    ? computeEffectiveSchemeRate(effectiveWholesaleRate, schemeDetails)
    : null;

  const missingReasons: string[] = [];
  if (!(product.name || '').trim()) missingReasons.push('Missing product name');
  if (!(product.genericName || '').trim() && !(product.composition || '').trim()) {
    missingReasons.push('Missing salt/composition');
  }
  if (!earliestValidBatch) {
    missingReasons.push('No batch record');
  } else {
    if (earliestValidBatch.wholesaleRate <= 0) missingReasons.push('Missing wholesale rate');
    if (earliestValidBatch.mrp <= 0) missingReasons.push('Missing MRP');
    if (!earliestValidBatch.expiryDate) missingReasons.push('Missing expiry date');
  }

  // Latest update timestamp across product and its batches
  const candidateDates: Date[] = [];
  const pDate = toDateSafe(product.updatedAt);
  if (pDate) candidateDates.push(pDate);
  for (const b of productBatches) {
    const bDate = toDateSafe(b.updatedAt);
    if (bDate) candidateDates.push(bDate);
  }
  candidateDates.sort((a, b) => b.getTime() - a.getTime());

  return {
    product,
    batches: productBatches,
    validInStockBatches,
    earliestValidBatch,
    primaryBatch: earliestValidBatch,
    totalAvailableQty,
    availabilityStatus,
    effectiveWholesaleRate,
    effectiveUnitAfterScheme,
    mrp: earliestValidBatch ? earliestValidBatch.mrp : 0,
    discountPercent,
    schemeDetails,
    dealRateAdjustable,
    earliestExpiryDisplay: earliestValidBatch ? earliestValidBatch.expiryDisplay : 'Not set',
    earliestExpiryIso: earliestValidBatch ? earliestValidBatch.expiryDate : '',
    hasMissingInfo: missingReasons.length > 0,
    missingReasons,
    latestUpdatedAt: candidateDates[0] || null,
  };
}

// Phonetic & common medicine spelling normalization for typo-tolerant search
function normalizePharmaText(input: string): string {
  return input
    .toLowerCase()
    .replace(/ph/g, 'f')
    .replace(/th/g, 't')
    .replace(/y/g, 'i')
    .replace(/z/g, 's')
    .replace(/c([ei])/g, 's$1')
    .replace(/c/g, 'k')
    .replace(/(.)\1+/g, '$1')
    .replace(/[^a-z0-9]/g, '');
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const maxLen = Math.max(a.length, b.length);
  if (Math.abs(a.length - b.length) > 3 && maxLen > 6) return 99;

  const prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  const curr = new Array<number>(b.length + 1);
  for (let i = 1; i <= a.length; i++) {
    curr[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= b.length; j++) prev[j] = curr[j];
  }
  return prev[b.length];
}

export interface SearchHit {
  item: ProductWithBatches;
  score: number;
  matchedField: string;
}

export function fuzzySearchProducts(
  items: ProductWithBatches[],
  rawQuery: string
): SearchHit[] {
  const q = rawQuery.trim().toLowerCase();
  if (!q) {
    return items.map((item) => ({ item, score: 1, matchedField: '' }));
  }

  const tokens = q.split(/\s+/).filter(Boolean);
  const normQ = normalizePharmaText(q);
  const hits: SearchHit[] = [];

  for (const item of items) {
    const p = item.product;
    const fields = [
      { key: 'Brand', val: (p.name || '').toLowerCase(), weight: 10 },
      { key: 'Brand', val: (p.brandName || '').toLowerCase(), weight: 9 },
      { key: 'Salt', val: (p.genericName || '').toLowerCase(), weight: 8 },
      { key: 'Composition', val: (p.composition || '').toLowerCase(), weight: 7 },
      { key: 'Company', val: (p.manufacturer || '').toLowerCase(), weight: 6 },
      { key: 'Code', val: (p.productCode || '').toLowerCase(), weight: 8 },
      { key: 'HSN', val: (p.hsnCode || '').toLowerCase(), weight: 5 },
    ];

    let bestScore = 0;
    let matchedField = '';

    // 1. Direct substring & multi-token match
    const combinedText = fields.map((f) => f.val).join(' ');
    const allTokensMatch = tokens.every((tok) => combinedText.includes(tok));
    if (allTokensMatch) {
      for (const f of fields) {
        if (f.val.startsWith(q)) {
          bestScore = Math.max(bestScore, f.weight * 12);
          matchedField = f.key;
        } else if (f.val.includes(q)) {
          bestScore = Math.max(bestScore, f.weight * 8);
          matchedField = matchedField || f.key;
        } else if (tokens.some((t) => f.val.includes(t))) {
          bestScore = Math.max(bestScore, f.weight * 4);
          matchedField = matchedField || f.key;
        }
      }
    }

    // 2. Phonetic & typo-tolerant fuzzy match
    if (bestScore === 0 && normQ.length >= 3) {
      for (const f of fields) {
        if (!f.val) continue;
        const words = f.val.split(/[\s/+(),-]+/).filter((w) => w.length >= 3);
        const normFull = normalizePharmaText(f.val);
        if (normFull.includes(normQ)) {
          bestScore = Math.max(bestScore, f.weight * 5);
          matchedField = f.key;
          continue;
        }
        for (const w of words) {
          const normW = normalizePharmaText(w);
          const dist = levenshtein(normQ, normW.slice(0, Math.max(normQ.length, normW.length)));
          const maxAllowed = normQ.length <= 4 ? 1 : 2;
          if (dist <= maxAllowed) {
            bestScore = Math.max(bestScore, f.weight * (4 - dist));
            matchedField = f.key;
          } else {
            const distRaw = levenshtein(q, w);
            if (distRaw <= maxAllowed) {
              bestScore = Math.max(bestScore, f.weight * (3 - distRaw));
              matchedField = f.key;
            }
          }
        }
      }
    }

    if (bestScore > 0) {
      hits.push({ item, score: bestScore, matchedField });
    }
  }

  return hits.sort((a, b) => b.score - a.score || a.item.product.name.localeCompare(b.item.product.name));
}

export function buildWhatsAppEnquiryMessage(
  items: CartEnquiryItem[],
  retailer: RetailerAccount | null,
  notes: string
): string {
  const lines: string[] = [];
  lines.push('*TARA MEDICAL AGENCY — PRODUCT ENQUIRY*');
  lines.push(`Date: ${formatDateTimeIST(new Date())}`);
  if (retailer) {
    lines.push(`Retailer: *${retailer.shopName || retailer.ownerName}*`);
    if (retailer.ownerName) lines.push(`Contact: ${retailer.ownerName}`);
    if (retailer.phone) lines.push(`Phone: ${retailer.phone}`);
    if (retailer.city) lines.push(`Area: ${retailer.city}`);
    if (retailer.drugLicenseNo) lines.push(`DL No: ${retailer.drugLicenseNo}`);
  }
  lines.push('');
  lines.push('*Requested Medicines:*');

  let estimatedSubtotal = 0;
  items.forEach((item, idx) => {
    const lineTotal = item.wholesaleRate * item.qty;
    estimatedSubtotal += lineTotal;
    const dealPart = item.schemeDetails
      ? ` | Deal: ${item.schemeDetails} (${
          item.dealRateAdjustable ? 'Adjustable in Rate' : 'Not Adjustable in Rate'
        })`
      : '';
    const expPart =
      item.expiryDisplay && item.expiryDisplay !== 'Missing'
        ? ` | Exp: ${item.expiryDisplay}`
        : '';
    lines.push(
      `${idx + 1}. *${item.productName}* (${item.packSize}) — Qty: *${item.qty}*` +
        `\n   Rate: ${formatINR(item.wholesaleRate)}${dealPart}${expPart} | Est: ${formatINR(lineTotal)}`
    );
  });

  lines.push('');
  lines.push(`*Estimated Subtotal (Excl. GST): ${formatINR(estimatedSubtotal)}*`);
  if (notes.trim()) {
    lines.push(`Notes: ${notes.trim()}`);
  }
  lines.push('');
  lines.push('Please confirm current stock availability, final billing rate & delivery schedule.');
  return lines.join('\n');
}
