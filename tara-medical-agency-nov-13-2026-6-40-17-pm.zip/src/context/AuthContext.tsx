import React, { createContext, useContext, useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  ensureDefaultAdminExists,
  updateAdminPassword,
  updateRetailerPassword,
  verifyAdminLogin,
  verifyRetailerLogin,
} from '../services/catalogService';
import type {
  AdminAccount,
  RetailerAccount,
  SessionUser,
  UserRole,
} from '../types/pharma';

const SESSION_STORAGE_KEY = 'tara_medical_session_v2';

interface StoredSession {
  role: UserRole;
  uid: string;
}

interface AuthContextValue {
  user: SessionUser | null;
  adminAccount: AdminAccount | null;
  retailer: RetailerAccount | null;
  isAdmin: boolean;
  isApprovedRetailer: boolean;
  authLoading: boolean;
  authError: string | null;
  viewMode: 'retailer' | 'admin';
  setViewMode: (mode: 'retailer' | 'admin') => void;
  signInAdminWithIdPassword: (adminId: string, password: string) => Promise<void>;
  signInRetailerWithIdPassword: (
    retailerId: string,
    password: string
  ) => Promise<void>;
  changeRetailerPassword: (
    currentPassword: string,
    newPassword: string
  ) => Promise<void>;
  changeAdminPassword: (
    currentPassword: string,
    newPassword: string
  ) => Promise<void>;
  signOutUser: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function readStoredSession(): StoredSession | null {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<StoredSession>;
    if (
      (parsed.role === 'admin' || parsed.role === 'retailer') &&
      typeof parsed.uid === 'string' &&
      parsed.uid.length > 0
    ) {
      return { role: parsed.role, uid: parsed.uid };
    }
    return null;
  } catch {
    return null;
  }
}

function saveStoredSession(session: StoredSession | null) {
  try {
    if (!session) {
      localStorage.removeItem(SESSION_STORAGE_KEY);
    } else {
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    }
  } catch {
    // Ignore storage errors
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [session, setSession] = useState<StoredSession | null>(() =>
    readStoredSession()
  );
  const [adminAccount, setAdminAccount] = useState<AdminAccount | null>(null);
  const [retailer, setRetailer] = useState<RetailerAccount | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(
    () => readStoredSession() !== null
  );
  const [authError, setAuthError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'retailer' | 'admin'>(() =>
    readStoredSession()?.role === 'admin' ? 'admin' : 'retailer'
  );

  // Ensure default Admin ID+Password record is seeded once in Firestore
  useEffect(() => {
    void ensureDefaultAdminExists().catch(() => {
      // Handled when login is attempted if offline at boot
    });
  }, []);

  // Subscribe to active account doc in Firestore
  useEffect(() => {
    if (!session) {
      setAdminAccount(null);
      setRetailer(null);
      setAuthLoading(false);
      return;
    }

    setAuthLoading(true);
    if (session.role === 'admin') {
      const ref = doc(db, 'admins', session.uid);
      const unsub = onSnapshot(
        ref,
        (snap) => {
          if (snap.exists()) {
            setAdminAccount(snap.data() as AdminAccount);
            setRetailer(null);
          } else {
            setAdminAccount(null);
            setSession(null);
            saveStoredSession(null);
          }
          setAuthLoading(false);
        },
        () => {
          setAuthLoading(false);
        }
      );
      return () => unsub();
    }

    const ref = doc(db, 'retailers', session.uid);
    const unsub = onSnapshot(
      ref,
      (snap) => {
        if (snap.exists()) {
          setRetailer(snap.data() as RetailerAccount);
          setAdminAccount(null);
        } else {
          setRetailer(null);
          setSession(null);
          saveStoredSession(null);
        }
        setAuthLoading(false);
      },
      () => {
        setAuthLoading(false);
      }
    );
    return () => unsub();
  }, [session]);

  const isAdmin = !!adminAccount && session?.role === 'admin';
  const isApprovedRetailer = isAdmin || retailer?.status === 'active';

  const user: SessionUser | null = isAdmin && adminAccount
    ? {
        uid: adminAccount.uid,
        idCode: adminAccount.adminId,
        displayName: adminAccount.displayName,
        role: 'admin',
      }
    : retailer
    ? {
        uid: retailer.uid,
        idCode: retailer.retailerId,
        displayName: retailer.shopName || retailer.ownerName,
        role: 'retailer',
      }
    : null;

  const signInAdminWithIdPassword = async (
    adminId: string,
    password: string
  ) => {
    setAuthError(null);
    try {
      const admin = await verifyAdminLogin(adminId, password);
      const nextSession: StoredSession = { role: 'admin', uid: admin.uid };
      saveStoredSession(nextSession);
      setAdminAccount(admin);
      setRetailer(null);
      setViewMode('admin');
      setSession(nextSession);
    } catch (err) {
      setAuthError(
        err instanceof Error ? err.message : 'Admin sign-in failed.'
      );
    }
  };

  const signInRetailerWithIdPassword = async (
    retailerId: string,
    password: string
  ) => {
    setAuthError(null);
    try {
      const ret = await verifyRetailerLogin(retailerId, password);
      const nextSession: StoredSession = { role: 'retailer', uid: ret.uid };
      saveStoredSession(nextSession);
      setRetailer(ret);
      setAdminAccount(null);
      setViewMode('retailer');
      setSession(nextSession);
    } catch (err) {
      setAuthError(
        err instanceof Error ? err.message : 'Retailer sign-in failed.'
      );
    }
  };

  const changeRetailerPassword = async (
    currentPassword: string,
    newPassword: string
  ) => {
    if (!retailer) {
      throw new Error('No signed-in retailer session found.');
    }
    await updateRetailerPassword(retailer.uid, currentPassword, newPassword);
  };

  const changeAdminPassword = async (
    currentPassword: string,
    newPassword: string
  ) => {
    if (!adminAccount) {
      throw new Error('No signed-in administrator session found.');
    }
    await updateAdminPassword(adminAccount.uid, currentPassword, newPassword);
  };

  const signOutUser = () => {
    saveStoredSession(null);
    setSession(null);
    setAdminAccount(null);
    setRetailer(null);
    setAuthError(null);
    setViewMode('retailer');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        adminAccount,
        retailer,
        isAdmin,
        isApprovedRetailer,
        authLoading,
        authError,
        viewMode,
        setViewMode,
        signInAdminWithIdPassword,
        signInRetailerWithIdPassword,
        changeRetailerPassword,
        changeAdminPassword,
        signOutUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
