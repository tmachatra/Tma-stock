import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { SEED_COMPANIES, SEED_PRODUCTS } from '../data/seedCatalog';
import {
  generateSaltHex,
  hashPasswordPBKDF2,
  verifyPasswordPBKDF2,
} from '../lib/authCrypto';
import {
  adminDocIdFromCode,
  db,
  DEFAULT_ADMIN_DOC_ID,
  DEFAULT_ADMIN_ID,
  DEFAULT_ADMIN_INITIAL_PASSWORD,
  handleFirestoreError,
  logFirestoreError,
  normalizeCodeId,
  OperationType,
  retailerDocIdFromCode,
} from '../lib/firebase';
import { parseExpiryToIso, slugId } from '../lib/pharmaUtils';
import type {
  AdminAccount,
  AdminBatchCost,
  AvailabilityOverride,
  CartEnquiryItem,
  CustomerActivityEvent,
  CustomerActivityEventType,
  EnquiryItem,
  ExcelImportLog,
  MedicineBatch,
  MedicineProduct,
  PharmaCompany,
  PriceTier,
  RetailerAccount,
  RetailerEnquiry,
} from '../types/pharma';

export function subscribeCompanies(
  onData: (companies: PharmaCompany[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'companies'), orderBy('name', 'asc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as PharmaCompany);
      onData(list);
    },
    (err) => {
      if (onError) onError(err);
      logFirestoreError(err, OperationType.LIST, 'companies');
    }
  );
}

export function subscribeProducts(
  onData: (products: MedicineProduct[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'products'), orderBy('name', 'asc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as MedicineProduct);
      onData(list);
    },
    (err) => {
      if (onError) onError(err);
      logFirestoreError(err, OperationType.LIST, 'products');
    }
  );
}

export function subscribeBatches(
  onData: (batches: MedicineBatch[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'batches'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as MedicineBatch);
      onData(list);
    },
    (err) => {
      if (onError) onError(err);
      logFirestoreError(err, OperationType.LIST, 'batches');
    }
  );
}

export function subscribeAdminBatchCosts(
  onData: (costs: Record<string, AdminBatchCost>) => void
) {
  const q = query(collection(db, 'admin_batch_costs'));
  return onSnapshot(
    q,
    (snap) => {
      const map: Record<string, AdminBatchCost> = {};
      for (const d of snap.docs) {
        const item = d.data() as AdminBatchCost;
        map[item.batchId] = item;
      }
      onData(map);
    },
    (err) => {
      logFirestoreError(err, OperationType.LIST, 'admin_batch_costs');
    }
  );
}

export function subscribeRetailers(
  onData: (retailers: RetailerAccount[]) => void
) {
  const q = query(collection(db, 'retailers'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as RetailerAccount));
    },
    (err) => {
      logFirestoreError(err, OperationType.LIST, 'retailers');
    }
  );
}

export function subscribeImportLogs(
  onData: (logs: ExcelImportLog[]) => void
) {
  const q = query(collection(db, 'import_logs'), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as ExcelImportLog));
    },
    (err) => {
      logFirestoreError(err, OperationType.LIST, 'import_logs');
    }
  );
}

export function subscribeMyEnquiries(
  uid: string,
  onData: (enquiries: RetailerEnquiry[]) => void
) {
  const q = query(
    collection(db, 'enquiries'),
    where('retailerUid', '==', uid),
    orderBy('createdAt', 'desc')
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as RetailerEnquiry));
    },
    (err) => {
      logFirestoreError(err, OperationType.LIST, 'enquiries');
    }
  );
}

export function subscribeAllEnquiries(
  onData: (enquiries: RetailerEnquiry[]) => void
) {
  const q = query(
    collection(db, 'enquiries'),
    orderBy('createdAt', 'desc'),
    limit(200)
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as RetailerEnquiry));
    },
    (err) => {
      logFirestoreError(err, OperationType.LIST, 'enquiries');
    }
  );
}

export async function fetchEnquiryItemsByIds(
  enquiryIds: string[]
): Promise<Array<EnquiryItem & { enquiryId: string }>> {
  const targetIds = enquiryIds.slice(0, 40);
  if (targetIds.length === 0) return [];
  const results = await Promise.all(
    targetIds.map(async (enquiryId) => {
      try {
        const snap = await getDocs(collection(db, 'enquiries', enquiryId, 'items'));
        return snap.docs.map((d) => ({
          ...(d.data() as EnquiryItem),
          enquiryId,
        }));
      } catch (err) {
        logFirestoreError(err, OperationType.LIST, `enquiries/${enquiryId}/items`);
        return [];
      }
    })
  );
  return results.flat();
}

export async function fetchSingleEnquiryItems(
  enquiryId: string
): Promise<Array<EnquiryItem & { enquiryId: string }>> {
  try {
    const snap = await getDocs(collection(db, 'enquiries', enquiryId, 'items'));
    return snap.docs.map((d) => ({
      ...(d.data() as EnquiryItem),
      enquiryId,
    }));
  } catch (err) {
    logFirestoreError(err, OperationType.LIST, `enquiries/${enquiryId}/items`);
    return [];
  }
}

export function subscribeCustomerEvents(
  onData: (events: CustomerActivityEvent[]) => void
) {
  const q = query(
    collection(db, 'customer_events'),
    orderBy('createdAt', 'desc'),
    limit(500)
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as CustomerActivityEvent));
    },
    (err) => {
      logFirestoreError(err, OperationType.LIST, 'customer_events');
    }
  );
}

export async function trackCustomerActivity(input: {
  retailerUid: string;
  retailerId: string;
  shopName: string;
  city: string;
  eventType: CustomerActivityEventType;
  productId?: string;
  productName?: string;
  companyId?: string;
  companyName?: string;
  searchQuery?: string;
  qty?: number;
  estimatedValue?: number;
  resultCount?: number;
}): Promise<void> {
  if (!input.retailerUid) return;
  const eventId = `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const payload: Record<string, unknown> = {
    id: eventId,
    retailerUid: input.retailerUid.slice(0, 128),
    retailerId: (input.retailerId || '').slice(0, 32),
    shopName: (input.shopName || 'Retailer').slice(0, 160),
    city: (input.city || '').slice(0, 80),
    eventType: input.eventType,
    createdAt: serverTimestamp(),
  };

  if (input.productId) payload.productId = input.productId.slice(0, 64);
  if (input.productName) payload.productName = input.productName.slice(0, 180);
  if (input.companyId) payload.companyId = input.companyId.slice(0, 64);
  if (input.companyName) payload.companyName = input.companyName.slice(0, 120);
  if (input.searchQuery) payload.searchQuery = input.searchQuery.trim().slice(0, 120);
  if (typeof input.qty === 'number' && Number.isFinite(input.qty) && input.qty >= 0) {
    payload.qty = input.qty;
  }
  if (
    typeof input.estimatedValue === 'number' &&
    Number.isFinite(input.estimatedValue) &&
    input.estimatedValue >= 0
  ) {
    payload.estimatedValue = Number(input.estimatedValue.toFixed(2));
  }
  if (
    typeof input.resultCount === 'number' &&
    Number.isFinite(input.resultCount) &&
    input.resultCount >= 0
  ) {
    payload.resultCount = Math.floor(input.resultCount);
  }

  try {
    await setDoc(doc(db, 'customer_events', eventId), payload);
  } catch (err) {
    logFirestoreError(err, OperationType.CREATE, `customer_events/${eventId}`);
  }
}

export async function seedInitialCatalog(): Promise<{ productsCount: number; batchesCount: number }> {
  const batch = writeBatch(db);
  let batchesCount = 0;

  for (const c of SEED_COMPANIES) {
    batch.set(doc(db, 'companies', c.id), {
      id: c.id,
      name: c.name,
      shortCode: c.shortCode,
      active: true,
      updatedAt: serverTimestamp(),
    });
  }

  for (const p of SEED_PRODUCTS) {
    batch.set(doc(db, 'products', p.id), {
      id: p.id,
      productCode: p.productCode,
      name: p.name,
      brandName: p.brandName,
      genericName: p.genericName,
      composition: p.composition,
      companyId: p.companyId,
      manufacturer: p.manufacturer,
      category: p.category,
      packSize: p.packSize,
      hsnCode: p.hsnCode,
      minStockLevel: p.minStockLevel,
      confirmAvailabilityOnly: !!p.confirmAvailabilityOnly,
      updatedAt: serverTimestamp(),
    });

    for (const b of p.batches) {
      const batchId = slugId('bat', `${p.id}_${b.batchNumber}`);
      const parsedExp = parseExpiryToIso(b.expiryRaw);
      batch.set(doc(db, 'batches', batchId), {
        id: batchId,
        productId: p.id,
        batchNumber: b.batchNumber,
        expiryDate: parsedExp.expiryDate,
        expiryDisplay: parsedExp.expiryDisplay,
        mrp: b.mrp,
        wholesaleRate: b.wholesaleRate,
        discountPercent: b.discountPercent,
        schemeDetails: b.schemeDetails,
        dealRateAdjustable: !!b.dealRateAdjustable,
        availableQty: b.availableQty,
        availabilityOverride: b.availabilityOverride || 'AUTO',
        isActive: true,
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'admin_batch_costs', batchId), {
        batchId,
        productId: p.id,
        purchaseRate: b.purchaseRate,
        updatedAt: serverTimestamp(),
      });
      batchesCount += 1;
    }
  }

  try {
    await batch.commit();
    return { productsCount: SEED_PRODUCTS.length, batchesCount };
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'products');
  }
}

export async function upsertCompany(company: {
  id?: string;
  name: string;
  shortCode: string;
  active: boolean;
}): Promise<string> {
  const id = company.id || slugId('comp', company.name);
  try {
    await setDoc(doc(db, 'companies', id), {
      id,
      name: company.name.trim().slice(0, 120),
      shortCode: (company.shortCode || company.name.slice(0, 8)).toUpperCase().trim().slice(0, 32),
      active: company.active,
      updatedAt: serverTimestamp(),
    });
    return id;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `companies/${id}`);
  }
}

export async function deleteCompany(companyId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'companies', companyId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `companies/${companyId}`);
  }
}

export async function upsertProduct(
  product: Omit<MedicineProduct, 'updatedAt'>
): Promise<void> {
  const id = product.id || slugId('prod', `${product.name}_${product.packSize}`);
  const cleanImageUrl = (product.imageUrl || '').trim().slice(0, 150000);
  try {
    await setDoc(doc(db, 'products', id), {
      ...product,
      id,
      imageUrl: cleanImageUrl,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `products/${id}`);
  }
}

export async function deleteProductAndBatches(
  productId: string,
  batchIds: string[]
): Promise<void> {
  const wb = writeBatch(db);
  wb.delete(doc(db, 'products', productId));
  for (const bId of batchIds) {
    wb.delete(doc(db, 'batches', bId));
    wb.delete(doc(db, 'admin_batch_costs', bId));
  }
  try {
    await wb.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `products/${productId}`);
  }
}

export async function upsertBatchWithCost(
  batchData: Omit<MedicineBatch, 'updatedAt'>,
  purchaseRate?: number
): Promise<void> {
  const wb = writeBatch(db);
  wb.set(doc(db, 'batches', batchData.id), {
    ...batchData,
    updatedAt: serverTimestamp(),
  });
  if (typeof purchaseRate === 'number' && Number.isFinite(purchaseRate)) {
    wb.set(doc(db, 'admin_batch_costs', batchData.id), {
      batchId: batchData.id,
      productId: batchData.productId,
      purchaseRate: Math.max(0, purchaseRate),
      updatedAt: serverTimestamp(),
    });
  }
  try {
    await wb.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `batches/${batchData.id}`);
  }
}

export async function deleteBatchAndCost(batchId: string): Promise<void> {
  const wb = writeBatch(db);
  wb.delete(doc(db, 'batches', batchId));
  wb.delete(doc(db, 'admin_batch_costs', batchId));
  try {
    await wb.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `batches/${batchId}`);
  }
}

export async function bulkUpdateBatches(
  batches: MedicineBatch[],
  patch: {
    rateDeltaPercent?: number;
    setDiscountPercent?: number;
    setSchemeDetails?: string;
    setDealRateAdjustable?: boolean;
    stockDelta?: number;
    setStockExact?: number;
    setExpiryRaw?: string;
    setAvailabilityOverride?: AvailabilityOverride;
  }
): Promise<number> {
  if (batches.length === 0) return 0;

  // Firestore writeBatch supports up to 500 ops per commit
  const chunkSize = 400;
  let updated = 0;

  for (let i = 0; i < batches.length; i += chunkSize) {
    const chunk = batches.slice(i, i + chunkSize);
    const wb = writeBatch(db);
    for (const b of chunk) {
      let nextRate = b.wholesaleRate;
      if (typeof patch.rateDeltaPercent === 'number' && patch.rateDeltaPercent !== 0) {
        nextRate = Number((b.wholesaleRate * (1 + patch.rateDeltaPercent / 100)).toFixed(2));
      }
      const nextDiscount =
        typeof patch.setDiscountPercent === 'number'
          ? Math.min(100, Math.max(0, patch.setDiscountPercent))
          : b.discountPercent;
      const nextScheme =
        typeof patch.setSchemeDetails === 'string'
          ? patch.setSchemeDetails
          : b.schemeDetails;
      let nextQty = b.availableQty;
      if (typeof patch.setStockExact === 'number') {
        nextQty = Math.max(0, patch.setStockExact);
      } else if (typeof patch.stockDelta === 'number') {
        nextQty = Math.max(0, b.availableQty + patch.stockDelta);
      }
      let nextExpiryDate = b.expiryDate;
      let nextExpiryDisplay = b.expiryDisplay;
      if (patch.setExpiryRaw) {
        const parsed = parseExpiryToIso(patch.setExpiryRaw);
        nextExpiryDate = parsed.expiryDate;
        nextExpiryDisplay = parsed.expiryDisplay;
      }
      const nextOverride = patch.setAvailabilityOverride || b.availabilityOverride;
      const nextDealAdjustable =
        typeof patch.setDealRateAdjustable === 'boolean'
          ? patch.setDealRateAdjustable
          : !!b.dealRateAdjustable;

      wb.update(doc(db, 'batches', b.id), {
        wholesaleRate: nextRate,
        discountPercent: nextDiscount,
        schemeDetails: nextScheme,
        dealRateAdjustable: nextDealAdjustable,
        availableQty: nextQty,
        expiryDate: nextExpiryDate,
        expiryDisplay: nextExpiryDisplay,
        availabilityOverride: nextOverride,
        updatedAt: serverTimestamp(),
      });
      updated += 1;
    }
    try {
      await wb.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'batches');
    }
  }
  return updated;
}

export async function ensureDefaultAdminExists(): Promise<void> {
  const adminRef = doc(db, 'admins', DEFAULT_ADMIN_DOC_ID);
  try {
    const snap = await getDoc(adminRef);
    if (!snap.exists()) {
      const salt = generateSaltHex();
      const hash = await hashPasswordPBKDF2(
        DEFAULT_ADMIN_INITIAL_PASSWORD,
        salt
      );
      await setDoc(adminRef, {
        uid: DEFAULT_ADMIN_DOC_ID,
        adminId: DEFAULT_ADMIN_ID,
        displayName: 'Tara Medical Agency Admin',
        passwordSalt: salt,
        passwordHash: hash,
        mustChangePassword: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `admins/${DEFAULT_ADMIN_DOC_ID}`);
  }
}

export async function verifyAdminLogin(
  adminIdInput: string,
  password: string
): Promise<AdminAccount> {
  const norm = normalizeCodeId(adminIdInput);
  if (norm.length < 3) {
    throw new Error('Please enter a valid Admin ID (e.g. TMA-ADMIN).');
  }
  if (!password) {
    throw new Error('Please enter your password.');
  }

  const targetDocId =
    norm === 'ADMIN' ? DEFAULT_ADMIN_DOC_ID : adminDocIdFromCode(norm);

  if (targetDocId === DEFAULT_ADMIN_DOC_ID) {
    await ensureDefaultAdminExists();
  }

  let snap;
  try {
    snap = await getDoc(doc(db, 'admins', targetDocId));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `admins/${targetDocId}`);
  }

  if (!snap.exists()) {
    throw new Error('Invalid Admin ID or Password.');
  }

  const admin = snap.data() as AdminAccount;
  const ok = await verifyPasswordPBKDF2(
    password,
    admin.passwordSalt,
    admin.passwordHash
  );
  if (!ok) {
    throw new Error('Invalid Admin ID or Password.');
  }
  return admin;
}

export async function updateAdminPassword(
  adminUid: string,
  currentPassword: string,
  newPassword: string
): Promise<void> {
  if (newPassword.length < 6) {
    throw new Error('New password must be at least 6 characters.');
  }
  let snap;
  try {
    snap = await getDoc(doc(db, 'admins', adminUid));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `admins/${adminUid}`);
  }
  if (!snap.exists()) {
    throw new Error('Administrator account not found.');
  }
  const admin = snap.data() as AdminAccount;
  const ok = await verifyPasswordPBKDF2(
    currentPassword,
    admin.passwordSalt,
    admin.passwordHash
  );
  if (!ok) {
    throw new Error('Current password is incorrect.');
  }

  const newSalt = generateSaltHex();
  const newHash = await hashPasswordPBKDF2(newPassword, newSalt);
  try {
    await updateDoc(doc(db, 'admins', adminUid), {
      passwordSalt: newSalt,
      passwordHash: newHash,
      mustChangePassword: false,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `admins/${adminUid}`);
  }
}

export async function verifyRetailerLogin(
  retailerIdInput: string,
  password: string
): Promise<RetailerAccount> {
  const normId = normalizeCodeId(retailerIdInput);
  if (normId.length < 3) {
    throw new Error('Please enter a valid Retailer ID (e.g. TMA-101).');
  }
  if (!password) {
    throw new Error('Please enter your password.');
  }

  const deterministicUid = retailerDocIdFromCode(normId);
  let retailer: RetailerAccount | null = null;

  try {
    const directSnap = await getDoc(doc(db, 'retailers', deterministicUid));
    if (directSnap.exists()) {
      retailer = directSnap.data() as RetailerAccount;
    } else {
      const q = query(
        collection(db, 'retailers'),
        where('retailerId', '==', normId),
        limit(1)
      );
      const qSnap = await getDocs(q);
      if (!qSnap.empty) {
        retailer = qSnap.docs[0].data() as RetailerAccount;
      }
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `retailers/${deterministicUid}`);
  }

  if (!retailer || !retailer.passwordSalt || !retailer.passwordHash) {
    throw new Error(
      'Invalid Retailer ID or Password. Please check your credentials or contact Tara Medical Agency.'
    );
  }

  const ok = await verifyPasswordPBKDF2(
    password,
    retailer.passwordSalt,
    retailer.passwordHash
  );
  if (!ok) {
    throw new Error(
      'Invalid Retailer ID or Password. Please check your credentials or contact Tara Medical Agency.'
    );
  }

  return retailer;
}

export async function createRetailerByAdmin(input: {
  retailerId: string;
  initialPassword: string;
  ownerName: string;
  shopName: string;
  phone: string;
  drugLicenseNo: string;
  city: string;
  address: string;
  priceTier: PriceTier;
  customDiscountBonus: number;
}): Promise<{ uid: string; retailerId: string }> {
  const normalizedId = normalizeCodeId(input.retailerId);
  if (normalizedId.length < 3 || normalizedId.length > 32) {
    throw new Error(
      'Retailer ID must be 3–32 characters using letters, numbers, "-" or "_".'
    );
  }
  if (input.initialPassword.length < 6) {
    throw new Error('Initial password must be at least 6 characters.');
  }

  const uid = retailerDocIdFromCode(normalizedId);

  try {
    const existingSnap = await getDoc(doc(db, 'retailers', uid));
    if (existingSnap.exists()) {
      throw new Error(
        `Retailer ID "${normalizedId}" is already assigned. Choose another unique Retailer ID.`
      );
    }

    const salt = generateSaltHex();
    const hash = await hashPasswordPBKDF2(input.initialPassword, salt);

    await setDoc(doc(db, 'retailers', uid), {
      uid,
      retailerId: normalizedId,
      passwordSalt: salt,
      passwordHash: hash,
      ownerName: input.ownerName.trim().slice(0, 120),
      shopName: input.shopName.trim().slice(0, 160),
      phone: input.phone.trim().slice(0, 20),
      drugLicenseNo: input.drugLicenseNo.trim().slice(0, 80),
      city: input.city.trim().slice(0, 80),
      address: input.address.trim().slice(0, 300),
      role: 'retailer',
      status: 'active',
      priceTier: input.priceTier,
      customDiscountBonus: Math.min(100, Math.max(0, input.customDiscountBonus || 0)),
      mustChangePassword: true,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return { uid, retailerId: normalizedId };
  } catch (err) {
    if (err instanceof Error && err.message.includes('already assigned')) {
      throw err;
    }
    handleFirestoreError(err, OperationType.CREATE, `retailers/${uid}`);
  }
}

export async function updateRetailerAdmin(
  uid: string,
  updates: {
    status?: 'pending' | 'active' | 'deactivated';
    priceTier?: PriceTier;
    customDiscountBonus?: number;
    ownerName?: string;
    shopName?: string;
    phone?: string;
    drugLicenseNo?: string;
    city?: string;
    address?: string;
  }
): Promise<void> {
  try {
    await updateDoc(doc(db, 'retailers', uid), {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `retailers/${uid}`);
  }
}

export async function resetRetailerPasswordByAdmin(
  uid: string,
  newTemporaryPassword: string
): Promise<void> {
  if (newTemporaryPassword.length < 6) {
    throw new Error('New password must be at least 6 characters.');
  }
  const newSalt = generateSaltHex();
  const newHash = await hashPasswordPBKDF2(newTemporaryPassword, newSalt);
  try {
    await updateDoc(doc(db, 'retailers', uid), {
      passwordSalt: newSalt,
      passwordHash: newHash,
      mustChangePassword: true,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `retailers/${uid}`);
  }
}

export async function updateRetailerPassword(
  uid: string,
  currentPassword: string,
  newPassword: string
): Promise<void> {
  if (newPassword.length < 6) {
    throw new Error('New password must be at least 6 characters.');
  }
  let snap;
  try {
    snap = await getDoc(doc(db, 'retailers', uid));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `retailers/${uid}`);
  }
  if (!snap.exists()) {
    throw new Error('Retailer account not found.');
  }
  const retailer = snap.data() as RetailerAccount;
  const ok = await verifyPasswordPBKDF2(
    currentPassword,
    retailer.passwordSalt || '',
    retailer.passwordHash || ''
  );
  if (!ok) {
    throw new Error('Current password is incorrect.');
  }

  const newSalt = generateSaltHex();
  const newHash = await hashPasswordPBKDF2(newPassword, newSalt);
  try {
    await updateDoc(doc(db, 'retailers', uid), {
      passwordSalt: newSalt,
      passwordHash: newHash,
      mustChangePassword: false,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `retailers/${uid}`);
  }
}

export async function saveRetailerEnquiry(
  retailer: RetailerAccount,
  items: CartEnquiryItem[],
  notes: string,
  status: 'draft' | 'sent_whatsapp'
): Promise<string> {
  const enquiryId = `enq_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const estimatedTotal = items.reduce(
    (sum, item) => sum + item.wholesaleRate * item.qty,
    0
  );

  const wb = writeBatch(db);
  wb.set(doc(db, 'enquiries', enquiryId), {
    id: enquiryId,
    retailerUid: retailer.uid,
    retailerShopName: (retailer.shopName || retailer.ownerName).slice(0, 160),
    retailerPhone: (retailer.phone || '').slice(0, 20),
    notes: notes.trim().slice(0, 500),
    itemCount: items.length,
    estimatedTotal: Number(estimatedTotal.toFixed(2)),
    status,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  items.forEach((item, idx) => {
    const itemId = `item_${idx + 1}_${slugId('p', item.productId).slice(0, 24)}`;
    wb.set(doc(db, 'enquiries', enquiryId, 'items', itemId), {
      id: itemId,
      productId: item.productId,
      batchId: item.batchId || 'auto',
      productName: item.productName.slice(0, 180),
      packSize: item.packSize.slice(0, 40),
      qty: item.qty,
      wholesaleRate: item.wholesaleRate,
      schemeDetails: (item.schemeDetails || '').slice(0, 80),
      expiryDisplay: (item.expiryDisplay || '').slice(0, 16),
      lineTotal: Number((item.wholesaleRate * item.qty).toFixed(2)),
    });
  });

  try {
    await wb.commit();
    return enquiryId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `enquiries/${enquiryId}`);
  }
}

export async function recordImportLog(
  log: Omit<ExcelImportLog, 'createdAt'>
): Promise<void> {
  try {
    await setDoc(doc(db, 'import_logs', log.id), {
      ...log,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `import_logs/${log.id}`);
  }
}
