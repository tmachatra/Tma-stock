import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

if (import.meta.env.PROD) {
  registerSW({immediate: true});
} else if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  void navigator.serviceWorker
    .getRegistrations()
    .then(async (regs) => {
      const devRegs = regs.filter((r) => {
        const scriptUrl =
          r.active?.scriptURL ||
          r.installing?.scriptURL ||
          r.waiting?.scriptURL ||
          '';
        return scriptUrl.includes('dev-sw') || scriptUrl.includes('/sw.js');
      });
      if (devRegs.length === 0) return;
      await Promise.all(devRegs.map((r) => r.unregister()));
      if ('caches' in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map((k) => caches.delete(k)));
      }
      const reloadKey = 'tara_dev_sw_cleaned_v1';
      if (!sessionStorage.getItem(reloadKey)) {
        sessionStorage.setItem(reloadKey, '1');
        window.location.reload();
      }
    })
    .catch(() => {
      // Ignore cleanup errors
    });
}

createRoot(document.getElementById('root')!).render(<App />);
